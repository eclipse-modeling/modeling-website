# Note that this is just an example.
# You will likely have different paths or plugin versions than those listed below.
# Make sure that you own this file and that it has execute permission (chmod 755 run.sh)

/opt/ibm-java2-ws-sdk-pj9xia32142-20050609/bin/javaw -Xj9 -classpath \
/home/user/CASCON2005/workspace/Exercises/bin:/home/ibm/workspace2/com.example.po/bin:\
/home/user/CASCON2005/eclipse/eclipse3.2M2/eclipse/plugins/org.eclipse.core.runtime_3.1.0.jar:\
/home/user/CASCON2005/eclipse/eclipse3.2M2/eclipse/plugins/org.eclipse.osgi_3.2.0.jar:\
/home/user/CASCON2005/eclipse/emf2.2M2/eclipse/plugins/org.eclipse.emf.common_2.2.0.jar:\
/home/user/CASCON2005/eclipse/emf2.2M2/eclipse/plugins/org.eclipse.emf.ecore_2.1.0.jar:\
/home/user/CASCON2005/eclipse/emf2.2M2/eclipse/plugins/org.eclipse.emf.ecore.xmi_2.2.0.jar \
exercises.Exercise2