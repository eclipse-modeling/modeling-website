package exercises;


import java.io.File;
import java.io.IOException;
import java.util.Iterator;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xml.type.XMLTypeFactory;
import org.eclipse.emf.ecore.xml.type.XMLTypePackage;

import com.example.po.DocumentRoot;
import com.example.po.Item;
import com.example.po.POFactory;
import com.example.po.PurchaseOrder;
import com.example.po.USAddress;
import com.example.po.util.POResourceFactoryImpl;

/** CreatePOInstance builds an instance of the purchse order
 *  and serializes it, to produce file data/po.xml.
 */
public class CreatePOInstance
{
  public static void main(String[] args) throws IOException
  {
    // Create a purchase order instance using the generated API.
    //
    PurchaseOrder po = POFactory.eINSTANCE.createPurchaseOrder();
    po.setComment("For Scarlet's Birthday");
    po.setOrderDate(createDate("2005-08-10"));

    USAddress billTo = POFactory.eINSTANCE.createUSAddress();
    billTo.setName("Rhett Butler");
    billTo.setStreet("123 Iditarod Lane");
    billTo.setCity("Nome");
    billTo.setState("AK");
    billTo.setZip(34582);
    po.setBillTo(billTo);

    USAddress shipTo = POFactory.eINSTANCE.createUSAddress();
    shipTo.setName("Scarlet O'Hara");
    shipTo.setStreet("321 Backwoods Lane");
    shipTo.setCity("Louisville");
    shipTo.setState("AL");
    shipTo.setZip(67655);
    po.setShipTo(shipTo);

    Item item1 = POFactory.eINSTANCE.createItem();
    item1.setProductName("Wireless Headphones");
    item1.setQuantity(2);
    item1.setPrice(75);
    item1.setComment("Backordered");
    item1.setShipDate(createDate("2005-08-17"));
    item1.setPartNum("SWH123456");
    po.getItems().add(item1);

    Item item2 = POFactory.eINSTANCE.createItem();
    item2.setProductName("Plasma Television");
    item2.setQuantity(1);
    item2.setPrice(499);
    item2.setComment("Fragile");
    item2.setShipDate(createDate("2005-08-17"));
    item2.setPartNum("STV999876");
    po.getItems().add(item2);

    DocumentRoot document = POFactory.eINSTANCE.createDocumentRoot();
    document.setOrder(po);

    printPOData(document);
    savePOData(document);
  }

  // Use the XML type factory to parse a date string of the form "YYYY-MM-DD".
  //
  private static Object createDate(String date)
  {
    return XMLTypeFactory.eINSTANCE.createFromString(XMLTypePackage.eINSTANCE.getDate(), date);
  }

  public static void printPOData(DocumentRoot document)
  {
    System.out.println("XML Document data for 'order'");
    PurchaseOrder po = document.getOrder();
    System.out.println("  Order Comment: " + po.getComment());
    System.out.println("  Order Date: " + po.getOrderDate());
    System.out.println("  Bill To: " + makeMultiLineString(po.getBillTo(), new String []{ ", ", "\\(" }));
    System.out.println("  Ship To: " + makeMultiLineString(po.getShipTo(), new String []{ ", ", "\\(" }));
    int i = 0;
    for (Iterator iter = po.getItems().iterator(); iter.hasNext();)
    {
      Item item = (Item)iter.next();
      System.out.println("  Item " + (++i) + ": " + makeMultiLineString(item, new String []{ ", ", "\\(" }));
    }
    System.out.println("");
  }

  // Given a long string, break it into multiple lines.
  //
  private static String makeMultiLineString(Object in, String[] seps)
  {
    if (in != null)
    {
      String out = in.toString();
      for (int i = 0; i < seps.length; i++)
      {
        out = out.replaceAll(seps[i], seps[i] + "\n" + "   ");
      }
      return out;
    }
    else
    {
      return "[NONE]";
    }
  }

  public static void savePOData(DocumentRoot document) throws IOException
  {
    // Create a resource set to hold the resources.
    //
    ResourceSet resourceSet = new ResourceSetImpl();

    // Register the appropriate resource factory to handle all file extentions.
    //
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
      Resource.Factory.Registry.DEFAULT_EXTENSION,
      new POResourceFactoryImpl());

    // Create a resource and save the data in it.
    //
    URI uri = URI.createFileURI(new File("data/po.xml").getAbsolutePath());
    Resource resource = resourceSet.createResource(uri);
    resource.getContents().add(document);
    resource.save(null);
  }
}
