/**
 * <copyright>
 * </copyright>
 *
 * $Id: Item.java,v 1.1 2005/10/05 15:38:28 nickb Exp $
 */
package com.example.po;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Item</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.example.po.Item#getProductName <em>Product Name</em>}</li>
 *   <li>{@link com.example.po.Item#getQuantity <em>Quantity</em>}</li>
 *   <li>{@link com.example.po.Item#getPrice <em>Price</em>}</li>
 *   <li>{@link com.example.po.Item#getComment <em>Comment</em>}</li>
 *   <li>{@link com.example.po.Item#getShipDate <em>Ship Date</em>}</li>
 *   <li>{@link com.example.po.Item#getPartNum <em>Part Num</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.example.po.POPackage#getItem()
 * @model extendedMetaData="name='Item' kind='elementOnly'"
 * @generated
 */
public interface Item extends EObject
{
  /**
   * Returns the value of the '<em><b>Product Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Product Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Product Name</em>' attribute.
   * @see #setProductName(String)
   * @see com.example.po.POPackage#getItem_ProductName()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String" required="true"
   *        extendedMetaData="kind='element' name='productName'"
   * @generated
   */
  String getProductName();

  /**
   * Sets the value of the '{@link com.example.po.Item#getProductName <em>Product Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Product Name</em>' attribute.
   * @see #getProductName()
   * @generated
   */
  void setProductName(String value);

  /**
   * Returns the value of the '<em><b>Quantity</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Quantity</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Quantity</em>' attribute.
   * @see #isSetQuantity()
   * @see #unsetQuantity()
   * @see #setQuantity(int)
   * @see com.example.po.POPackage#getItem_Quantity()
   * @model unique="false" unsettable="true" dataType="com.example.po.QuantityType" required="true"
   *        extendedMetaData="kind='element' name='quantity'"
   * @generated
   */
  int getQuantity();

  /**
   * Sets the value of the '{@link com.example.po.Item#getQuantity <em>Quantity</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Quantity</em>' attribute.
   * @see #isSetQuantity()
   * @see #unsetQuantity()
   * @see #getQuantity()
   * @generated
   */
  void setQuantity(int value);

  /**
   * Unsets the value of the '{@link com.example.po.Item#getQuantity <em>Quantity</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetQuantity()
   * @see #getQuantity()
   * @see #setQuantity(int)
   * @generated
   */
  void unsetQuantity();

  /**
   * Returns whether the value of the '{@link com.example.po.Item#getQuantity <em>Quantity</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Quantity</em>' attribute is set.
   * @see #unsetQuantity()
   * @see #getQuantity()
   * @see #setQuantity(int)
   * @generated
   */
  boolean isSetQuantity();

  /**
   * Returns the value of the '<em><b>Price</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Price</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Price</em>' attribute.
   * @see #isSetPrice()
   * @see #unsetPrice()
   * @see #setPrice(float)
   * @see com.example.po.POPackage#getItem_Price()
   * @model unique="false" unsettable="true" dataType="org.eclipse.emf.ecore.xml.type.Float" required="true"
   *        extendedMetaData="kind='element' name='price'"
   * @generated
   */
  float getPrice();

  /**
   * Sets the value of the '{@link com.example.po.Item#getPrice <em>Price</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Price</em>' attribute.
   * @see #isSetPrice()
   * @see #unsetPrice()
   * @see #getPrice()
   * @generated
   */
  void setPrice(float value);

  /**
   * Unsets the value of the '{@link com.example.po.Item#getPrice <em>Price</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isSetPrice()
   * @see #getPrice()
   * @see #setPrice(float)
   * @generated
   */
  void unsetPrice();

  /**
   * Returns whether the value of the '{@link com.example.po.Item#getPrice <em>Price</em>}' attribute is set.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return whether the value of the '<em>Price</em>' attribute is set.
   * @see #unsetPrice()
   * @see #getPrice()
   * @see #setPrice(float)
   * @generated
   */
  boolean isSetPrice();

  /**
   * Returns the value of the '<em><b>Comment</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Comment</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Comment</em>' attribute.
   * @see #setComment(String)
   * @see com.example.po.POPackage#getItem_Comment()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   *        extendedMetaData="kind='element' name='comment' namespace='##targetNamespace'"
   * @generated
   */
  String getComment();

  /**
   * Sets the value of the '{@link com.example.po.Item#getComment <em>Comment</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Comment</em>' attribute.
   * @see #getComment()
   * @generated
   */
  void setComment(String value);

  /**
   * Returns the value of the '<em><b>Ship Date</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ship Date</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ship Date</em>' attribute.
   * @see #setShipDate(Object)
   * @see com.example.po.POPackage#getItem_ShipDate()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.Date"
   *        extendedMetaData="kind='element' name='shipDate'"
   * @generated
   */
  Object getShipDate();

  /**
   * Sets the value of the '{@link com.example.po.Item#getShipDate <em>Ship Date</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ship Date</em>' attribute.
   * @see #getShipDate()
   * @generated
   */
  void setShipDate(Object value);

  /**
   * Returns the value of the '<em><b>Part Num</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Part Num</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Part Num</em>' attribute.
   * @see #setPartNum(String)
   * @see com.example.po.POPackage#getItem_PartNum()
   * @model unique="false" dataType="com.example.po.SKU" required="true"
   *        extendedMetaData="kind='attribute' name='partNum'"
   * @generated
   */
  String getPartNum();

  /**
   * Sets the value of the '{@link com.example.po.Item#getPartNum <em>Part Num</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Part Num</em>' attribute.
   * @see #getPartNum()
   * @generated
   */
  void setPartNum(String value);

} // Item
