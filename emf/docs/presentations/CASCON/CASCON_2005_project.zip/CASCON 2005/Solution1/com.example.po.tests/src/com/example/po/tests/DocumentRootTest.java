/**
 * <copyright>
 * </copyright>
 *
 * $Id: DocumentRootTest.java,v 1.1 2005/10/05 15:38:28 nickb Exp $
 */
package com.example.po.tests;

import com.example.po.DocumentRoot;
import com.example.po.POFactory;

import junit.framework.TestCase;

import junit.textui.TestRunner;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Document Root</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are tested:
 * <ul>
 *   <li>{@link com.example.po.DocumentRoot#getComment() <em>Comment</em>}</li>
 *   <li>{@link com.example.po.DocumentRoot#getOrder() <em>Order</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public class DocumentRootTest extends TestCase
{

  /**
   * The fixture for this Document Root test case.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected DocumentRoot fixture = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static void main(String[] args)
  {
    TestRunner.run(DocumentRootTest.class);
  }

  /**
   * Constructs a new Document Root test case with the given name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public DocumentRootTest(String name)
  {
    super(name);
  }

  /**
   * Sets the fixture for this Document Root test case.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void setFixture(DocumentRoot fixture)
  {
    this.fixture = fixture;
  }

  /**
   * Returns the fixture for this Document Root test case.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private DocumentRoot getFixture()
  {
    return fixture;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see junit.framework.TestCase#setUp()
   * @generated
   */
  protected void setUp() throws Exception
  {
    setFixture(POFactory.eINSTANCE.createDocumentRoot());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see junit.framework.TestCase#tearDown()
   * @generated
   */
  protected void tearDown() throws Exception
  {
    setFixture(null);
  }

  /**
   * Tests the '{@link com.example.po.DocumentRoot#getComment() <em>Comment</em>}' feature getter.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.example.po.DocumentRoot#getComment()
   * @generated
   */
  public void testGetComment()
  {
    // TODO: implement this feature getter test method
    // Ensure that you remove @generated or mark it @generated NOT
    fail();
  }

  /**
   * Tests the '{@link com.example.po.DocumentRoot#setComment(java.lang.String) <em>Comment</em>}' feature setter.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.example.po.DocumentRoot#setComment(java.lang.String)
   * @generated
   */
  public void testSetComment()
  {
    // TODO: implement this feature setter test method
    // Ensure that you remove @generated or mark it @generated NOT
    fail();
  }

  /**
   * Tests the '{@link com.example.po.DocumentRoot#getOrder() <em>Order</em>}' feature getter.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.example.po.DocumentRoot#getOrder()
   * @generated
   */
  public void testGetOrder()
  {
    // TODO: implement this feature getter test method
    // Ensure that you remove @generated or mark it @generated NOT
    fail();
  }

  /**
   * Tests the '{@link com.example.po.DocumentRoot#setOrder(com.example.po.PurchaseOrder) <em>Order</em>}' feature setter.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see com.example.po.DocumentRoot#setOrder(com.example.po.PurchaseOrder)
   * @generated
   */
  public void testSetOrder()
  {
    // TODO: implement this feature setter test method
    // Ensure that you remove @generated or mark it @generated NOT
    fail();
  }

} //DocumentRootTest
