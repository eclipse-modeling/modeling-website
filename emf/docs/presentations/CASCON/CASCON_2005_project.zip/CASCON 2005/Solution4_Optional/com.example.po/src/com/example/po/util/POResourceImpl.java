/**
 * <copyright>
 * </copyright>
 *
 * $Id: POResourceImpl.java,v 1.1 2005/09/23 17:54:18 davidms Exp $
 */
package com.example.po.util;

import org.eclipse.emf.common.util.URI;

import org.eclipse.emf.ecore.xmi.impl.XMLResourceImpl;

/**
 * <!-- begin-user-doc -->
 * The <b>Resource </b> associated with the package.
 * <!-- end-user-doc -->
 * @see com.example.po.util.POResourceFactoryImpl
 * @generated
 */
public class POResourceImpl extends XMLResourceImpl
{
  /**
   * Creates an instance of the resource.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param uri the URI of the new resource.
   * @generated
   */
  public POResourceImpl(URI uri)
  {
    super(uri);
  }

} //POResourceImpl
