package exercises;


import java.io.File;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.XMLResourceFactoryImpl;
import org.eclipse.xsd.ecore.XSDEcoreBuilder;
import org.eclipse.xsd.util.XSDResourceFactoryImpl;


public class XMLSchemaDynamicProcessing
{

  /**
   * Before 2.2M1, to dynamicaly process an XML schema and then use it to load subsequently XML documents,
   * you needed to implement the following.
   */
  public static void main(String[] args) throws Exception
  {
    // 1. Register appropriate resource factory for .xsd and .ecore extensions.
    //
    Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("xsd", new XSDResourceFactoryImpl());
    Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("ecore", new EcoreResourceFactoryImpl());

    // 2. If Loading XML, register an XML resource factory.
    //
    Resource.Factory.Registry.INSTANCE.getExtensionToFactoryMap().put("*", new XMLResourceFactoryImpl());

    // 3. Instantiate XSDEcoreBuilder, the class that builds an Ecore model corresponding to a given schema.
    //
    XSDEcoreBuilder xsdEcoreBuilder = new XSDEcoreBuilder();

    // 4. Create Ecore, retrieving the list of EPackages.
    //
    Collection packageList = xsdEcoreBuilder.generate(URI.createFileURI(new File("data/PurchaseOrder.xsd").getAbsolutePath()));

    // 5. Create a resource set and register generated package(s) in it.
    //
    ResourceSet resourceSet = new ResourceSetImpl();
    EPackage.Registry registry = resourceSet.getPackageRegistry();
    for (Iterator packageIterator = packageList.iterator(); packageIterator.hasNext();)
    {
      EPackage epackage = (EPackage)packageIterator.next();
      registry.put(epackage.getNsURI(), epackage);
    }

    // 6. Create a resource to load instance document.
    //
    Resource resource = resourceSet.createResource(URI.createFileURI(new File("data/po.xml").getAbsolutePath()));

    // Since XML Schema is richer than EMF Ecore, EMF uses ExtendedMetaData to record (as Ecore annotations), 
    // and later recognize, XML Schema constructs that can't be directly represented in Ecore. 
    // Therefore before loading any XML resource, you need to set ExtendedMetaData as an option for loading (and saving).
    // This wasn't necessary when using a generated resource factory implementation, as it was done automatically.
    //
    // 7. Specify ExtendedMetaData as an option
    //
    HashMap options = new HashMap();
    options.put(XMLResource.OPTION_EXTENDED_META_DATA, Boolean.TRUE);

    // Load an XML file.
    //
    resource.load(options);

    // Save the model instance back to the console.
    //
    resource.save(System.out, options);
  }
}
