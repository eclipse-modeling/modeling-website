/**
 * <copyright>
 * </copyright>
 *
 * $Id: POValidator.java,v 1.1 2006/08/23 19:06:54 marcelop Exp $
 */
package com.example.po.util;

import com.example.po.*;

import java.util.Map;

import org.eclipse.emf.common.util.DiagnosticChain;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.util.EObjectValidator;

import org.eclipse.emf.ecore.xml.type.util.XMLTypeUtil;
import org.eclipse.emf.ecore.xml.type.util.XMLTypeValidator;

/**
 * <!-- begin-user-doc -->
 * The <b>Validator</b> for the model.
 * <!-- end-user-doc -->
 * @see com.example.po.POPackage
 * @generated
 */
public class POValidator extends EObjectValidator
{
  /**
   * The cached model package
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static final POValidator INSTANCE = new POValidator();

  /**
   * A constant for the {@link org.eclipse.emf.common.util.Diagnostic#getSource() source} of diagnostic {@link org.eclipse.emf.common.util.Diagnostic#getCode() codes} from this package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.common.util.Diagnostic#getSource()
   * @see org.eclipse.emf.common.util.Diagnostic#getCode()
   * @generated
   */
  public static final String DIAGNOSTIC_SOURCE = "com.example.po";

  /**
   * A constant with a fixed name that can be used as the base value for additional hand written constants.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private static final int GENERATED_DIAGNOSTIC_CODE_COUNT = 0;

  /**
   * A constant with a fixed name that can be used as the base value for additional hand written constants in a derived class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected static final int DIAGNOSTIC_CODE_COUNT = GENERATED_DIAGNOSTIC_CODE_COUNT;

  /**
   * The cached base package validator.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected XMLTypeValidator xmlTypeValidator;

  /**
   * Creates an instance of the switch.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public POValidator()
  {
    super();
    xmlTypeValidator = XMLTypeValidator.INSTANCE;
  }

  /**
   * Returns the package of this validator switch.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EPackage getEPackage()
  {
    return POPackage.eINSTANCE;
  }

  /**
   * Calls <code>validateXXX</code> for the corresonding classifier of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected boolean validate(int classifierID, Object value, DiagnosticChain diagnostics, Map context)
  {
    switch (classifierID)
    {
      case POPackage.DOCUMENT_ROOT:
        return validateDocumentRoot((DocumentRoot)value, diagnostics, context);
      case POPackage.ITEM:
        return validateItem((Item)value, diagnostics, context);
      case POPackage.PURCHASE_ORDER:
        return validatePurchaseOrder((PurchaseOrder)value, diagnostics, context);
      case POPackage.US_ADDRESS:
        return validateUSAddress((USAddress)value, diagnostics, context);
      case POPackage.QUANTITY_TYPE:
        return validateQuantityType(((Integer)value).intValue(), diagnostics, context);
      case POPackage.QUANTITY_TYPE_OBJECT:
        return validateQuantityTypeObject((Integer)value, diagnostics, context);
      case POPackage.SKU:
        return validateSKU((String)value, diagnostics, context);
      default: 
        return true;
    }
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateDocumentRoot(DocumentRoot documentRoot, DiagnosticChain diagnostics, Map context)
  {
    return validate_EveryDefaultConstraint(documentRoot, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateItem(Item item, DiagnosticChain diagnostics, Map context)
  {
    return validate_EveryDefaultConstraint(item, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validatePurchaseOrder(PurchaseOrder purchaseOrder, DiagnosticChain diagnostics, Map context)
  {
    return validate_EveryDefaultConstraint(purchaseOrder, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateUSAddress(USAddress usAddress, DiagnosticChain diagnostics, Map context)
  {
    return validate_EveryDefaultConstraint(usAddress, diagnostics, context);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateQuantityType(int quantityType, DiagnosticChain diagnostics, Map context)
  {
    boolean result = validateQuantityType_Min(quantityType, diagnostics, context);
    if (result || diagnostics != null) result &= validateQuantityType_Max(quantityType, diagnostics, context);
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @see #validateQuantityType_Min
   */
  public static final int QUANTITY_TYPE__MIN__VALUE = 0;

  /**
   * Validates the Min constraint of '<em>Quantity Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateQuantityType_Min(int quantityType, DiagnosticChain diagnostics, Map context)
  {
    boolean result = quantityType >= QUANTITY_TYPE__MIN__VALUE;
    if (!result && diagnostics != null) 
      reportMinViolation(POPackage.eINSTANCE.getQuantityType(), new Integer(quantityType), new Integer(QUANTITY_TYPE__MIN__VALUE), true, diagnostics, context);
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @see #validateQuantityType_Max
   */
  public static final int QUANTITY_TYPE__MAX__VALUE = 100;

  /**
   * Validates the Max constraint of '<em>Quantity Type</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateQuantityType_Max(int quantityType, DiagnosticChain diagnostics, Map context)
  {
    boolean result = quantityType < QUANTITY_TYPE__MAX__VALUE;
    if (!result && diagnostics != null) 
      reportMaxViolation(POPackage.eINSTANCE.getQuantityType(), new Integer(quantityType), new Integer(QUANTITY_TYPE__MAX__VALUE), false, diagnostics, context);
    return result; 
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateQuantityTypeObject(Integer quantityTypeObject, DiagnosticChain diagnostics, Map context)
  {
    boolean result = validateQuantityType_Min(quantityTypeObject.intValue(), diagnostics, context);
    if (result || diagnostics != null) result &= validateQuantityType_Max(quantityTypeObject.intValue(), diagnostics, context);
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSKU(String sku, DiagnosticChain diagnostics, Map context)
  {
    boolean result = validateSKU_Pattern(sku, diagnostics, context);
    return result;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @see #validateSKU_Pattern
   */
  public static final  PatternMatcher [][] SKU__PATTERN__VALUES =
    new PatternMatcher [][] 
    {
      new PatternMatcher [] 
      {
        XMLTypeUtil.createPatternMatcher("\\d{3}-[A-Z]{2}")
      }
    };

  /**
   * Validates the Pattern constraint of '<em>SKU</em>'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean validateSKU_Pattern(String sku, DiagnosticChain diagnostics, Map context)
  {
    return validatePattern(POPackage.eINSTANCE.getSKU(), sku, SKU__PATTERN__VALUES, diagnostics, context);
  }

} //POValidator
