/**
 * <copyright>
 * </copyright>
 *
 * $Id: PurchaseOrder.java,v 1.1 2006/08/23 19:06:54 marcelop Exp $
 */
package com.example.po;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Purchase Order</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link com.example.po.PurchaseOrder#getShipTo <em>Ship To</em>}</li>
 *   <li>{@link com.example.po.PurchaseOrder#getBillTo <em>Bill To</em>}</li>
 *   <li>{@link com.example.po.PurchaseOrder#getComment <em>Comment</em>}</li>
 *   <li>{@link com.example.po.PurchaseOrder#getItems <em>Items</em>}</li>
 *   <li>{@link com.example.po.PurchaseOrder#getOrderDate <em>Order Date</em>}</li>
 *   <li>{@link com.example.po.PurchaseOrder#getPreviousOrder <em>Previous Order</em>}</li>
 * </ul>
 * </p>
 *
 * @see com.example.po.POPackage#getPurchaseOrder()
 * @model extendedMetaData="name='PurchaseOrder' kind='elementOnly'"
 * @generated
 */
public interface PurchaseOrder extends EObject
{
  /**
   * Returns the value of the '<em><b>Ship To</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Ship To</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Ship To</em>' containment reference.
   * @see #setShipTo(USAddress)
   * @see com.example.po.POPackage#getPurchaseOrder_ShipTo()
   * @model containment="true" resolveProxies="false"
   *        extendedMetaData="kind='element' name='shipTo'"
   * @generated
   */
  USAddress getShipTo();

  /**
   * Sets the value of the '{@link com.example.po.PurchaseOrder#getShipTo <em>Ship To</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Ship To</em>' containment reference.
   * @see #getShipTo()
   * @generated
   */
  void setShipTo(USAddress value);

  /**
   * Returns the value of the '<em><b>Bill To</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Bill To</em>' containment reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Bill To</em>' containment reference.
   * @see #setBillTo(USAddress)
   * @see com.example.po.POPackage#getPurchaseOrder_BillTo()
   * @model containment="true" resolveProxies="false" required="true"
   *        extendedMetaData="kind='element' name='billTo'"
   * @generated
   */
  USAddress getBillTo();

  /**
   * Sets the value of the '{@link com.example.po.PurchaseOrder#getBillTo <em>Bill To</em>}' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Bill To</em>' containment reference.
   * @see #getBillTo()
   * @generated
   */
  void setBillTo(USAddress value);

  /**
   * Returns the value of the '<em><b>Comment</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Comment</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Comment</em>' attribute.
   * @see #setComment(String)
   * @see com.example.po.POPackage#getPurchaseOrder_Comment()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.String"
   *        extendedMetaData="kind='element' name='comment' namespace='##targetNamespace'"
   * @generated
   */
  String getComment();

  /**
   * Sets the value of the '{@link com.example.po.PurchaseOrder#getComment <em>Comment</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Comment</em>' attribute.
   * @see #getComment()
   * @generated
   */
  void setComment(String value);

  /**
   * Returns the value of the '<em><b>Items</b></em>' containment reference list.
   * The list contents are of type {@link com.example.po.Item}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Items</em>' containment reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Items</em>' containment reference list.
   * @see com.example.po.POPackage#getPurchaseOrder_Items()
   * @model type="com.example.po.Item" containment="true" resolveProxies="false"
   *        extendedMetaData="kind='element' name='items'"
   * @generated
   */
  EList getItems();

  /**
   * Returns the value of the '<em><b>Order Date</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Order Date</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Order Date</em>' attribute.
   * @see #setOrderDate(Object)
   * @see com.example.po.POPackage#getPurchaseOrder_OrderDate()
   * @model unique="false" dataType="org.eclipse.emf.ecore.xml.type.Date"
   *        extendedMetaData="kind='attribute' name='orderDate'"
   * @generated
   */
  Object getOrderDate();

  /**
   * Sets the value of the '{@link com.example.po.PurchaseOrder#getOrderDate <em>Order Date</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Order Date</em>' attribute.
   * @see #getOrderDate()
   * @generated
   */
  void setOrderDate(Object value);

  /**
   * Returns the value of the '<em><b>Previous Order</b></em>' reference.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Previous Order</em>' reference isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Previous Order</em>' reference.
   * @see #setPreviousOrder(PurchaseOrder)
   * @see com.example.po.POPackage#getPurchaseOrder_PreviousOrder()
   * @model extendedMetaData="kind='attribute' name='previousOrder'"
   * @generated
   */
  PurchaseOrder getPreviousOrder();

  /**
   * Sets the value of the '{@link com.example.po.PurchaseOrder#getPreviousOrder <em>Previous Order</em>}' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Previous Order</em>' reference.
   * @see #getPreviousOrder()
   * @generated
   */
  void setPreviousOrder(PurchaseOrder value);

} // PurchaseOrder
