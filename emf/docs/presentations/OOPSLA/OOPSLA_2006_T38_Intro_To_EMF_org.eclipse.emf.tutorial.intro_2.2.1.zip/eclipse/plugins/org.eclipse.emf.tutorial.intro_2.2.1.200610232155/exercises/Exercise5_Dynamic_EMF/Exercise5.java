package exercises;


/** 
 * This exercise demonstrates that by using the XMLProcessor API you can easily register
 * a schema and subsequently load XML documents that conform to that schema.
 **/
public class Exercise5
{
  public static void main(String[] args) throws Exception
  {
    // TODO: Dynamically load the PurchaseOrder schema using an XMLProcessor.
    // This results in automatic schema to Ecore conversion and registration
    // of the generated package(s).
    //


    // TODO: Using the XMLProcessor API, load an XML instance document.
    //


    // TODO: Using reflective EObject and Ecore APIs, retrieve the value of the "order" EStructuralFeature.
    //


    // TODO: Retrieve the shipTo address from the order and print out the address data.
    //


    // TODO: Save the resource to the console.
    //

  }
}
