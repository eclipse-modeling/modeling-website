package exercises;


import java.io.File;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.util.ExtendedMetaData;
import org.eclipse.emf.ecore.xmi.util.XMLProcessor;


/** 
 * This exercise demonstrates that by using the XMLProcessor API you can easily register
 * a schema and subsequently load XML documents that conform to that schema.
 **/
public class Exercise5
{
  public static void main(String[] args) throws Exception
  {
    // Dynamically load the PurchaseOrder schema using an XMLProcessor.
    // This results in automatic schema to Ecore conversion and registration
    // of the generated package(s).
    //
    XMLProcessor processor = new XMLProcessor(URI.createFileURI(new File("data/PurchaseOrder.xsd").getAbsolutePath()));

    // Using the XMLProcessor API, load an XML instance document.
    //
    Resource resource = processor.load(new File("data/po.xml").getAbsolutePath(), null);

    // Using reflective EObject and Ecore APIs, retrieve the value of the "order" EStructuralFeature.
    //
    EObject document = (EObject)resource.getContents().get(0);
    EObject order = (EObject)document.eGet(document.eClass().getEStructuralFeature("order"));

    // Retrieve the shipTo address from the order and print out the address data.
    //
    EObject shipTo = (EObject)order.eGet(order.eClass().getEStructuralFeature("shipTo"));

    EClass shipToEClass = shipTo.eClass();
    System.out.println("name: " + shipTo.eGet(shipToEClass.getEStructuralFeature("name")));
    System.out.println("street: " + shipTo.eGet(shipToEClass.getEStructuralFeature("street")));
    System.out.println("city: " + shipTo.eGet(shipToEClass.getEStructuralFeature("city")));
    System.out.println("state: " + shipTo.eGet(shipToEClass.getEStructuralFeature("state")));
    System.out.println("zip: "+ shipTo.eGet(shipToEClass.getEStructuralFeature("zip")));

    System.out.println("---");

    // Alternatively, obtain the ExtendedMetaData from the XML processor, and use it
    // to get the above features from their corresponding XML elements and attributes.
    // Use them to print out the same information.
    // 
    ExtendedMetaData extendedMetaData = processor.getExtendedMetaData();
    order = (EObject)document.eGet(extendedMetaData.getElement("http://www.example.com/po", "order"));
    shipTo = (EObject)order.eGet(extendedMetaData.getElement(order.eClass(), null, "shipTo"));
    System.out.println("name: " + shipTo.eGet(extendedMetaData.getElement(shipToEClass, null, "name")));
    System.out.println("street: " + shipTo.eGet(extendedMetaData.getElement(shipToEClass, null, "street")));
    System.out.println("city: " + shipTo.eGet(extendedMetaData.getElement(shipToEClass, null, "city")));
    System.out.println("state: " + shipTo.eGet(extendedMetaData.getElement(shipToEClass, null, "state")));
    System.out.println("zip: " + shipTo.eGet(extendedMetaData.getElement(shipToEClass, null, "zip")));
    System.out.println("---");

    // Save the resource to the console.
    //
    processor.save(System.out, resource, null);
  }
}
