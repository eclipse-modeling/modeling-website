# Note that this is just an example.
# You will likely have different paths or plugin versions than those listed below.
# Make sure that you own this file and that it has execute permission (chmod 755 run.sh)

/opt/ibm-java2-142sr4-1/bin/javaw -Xj9 -classpath \
/home/user/EMF_Workshop_Root/workspace/Exercises/bin:/home/user/workspace/com.example.po/bin:\
/home/user/EMF_Workshop_Root/eclipse3.2M5/eclipse/plugins/org.eclipse.core.runtime_3.2.0.jar:\
/home/user/EMF_Workshop_Root/eclipse3.2M5/eclipse/plugins/org.eclipse.osgi_3.2.0.jar:\
/home/user/EMF_Workshop_Root/emf2.2M5/eclipse/plugins/org.eclipse.emf.common_2.2.0.jar:\
/home/user/EMF_Workshop_Root/emf2.2M5/eclipse/plugins/org.eclipse.emf.ecore_2.2.0.jar:\
/home/user/EMF_Workshop_Root/emf2.2M5/eclipse/plugins/org.eclipse.emf.ecore.xmi_2.2.0.jar \
exercises.Exercise2