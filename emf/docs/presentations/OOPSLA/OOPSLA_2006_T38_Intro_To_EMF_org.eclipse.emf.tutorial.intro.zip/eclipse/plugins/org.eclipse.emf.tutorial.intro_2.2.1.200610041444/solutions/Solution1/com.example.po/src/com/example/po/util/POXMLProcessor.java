/**
 * <copyright>
 * </copyright>
 *
 * $Id: POXMLProcessor.java,v 1.1 2006/08/23 19:06:54 marcelop Exp $
 */
package com.example.po.util;

import com.example.po.POPackage;

import java.util.Map;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.xmi.util.XMLProcessor;

/**
 * This class contains helper methods to serialize and deserialize XML documents
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class POXMLProcessor extends XMLProcessor
{

  /**
   * Public constructor to instantiate the helper.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public POXMLProcessor()
  {
    super((EPackage.Registry.INSTANCE));
    POPackage.eINSTANCE.eClass();
  }
  
  /**
   * Register for "*" and "xml" file extensions the POResourceFactoryImpl factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Map getRegistrations()
  {
    if (registrations == null)
    {
      super.getRegistrations();
      registrations.put(XML_EXTENSION, new POResourceFactoryImpl());
      registrations.put(STAR_EXTENSION, new POResourceFactoryImpl());
    }
    return registrations;
  }

} //POXMLProcessor
