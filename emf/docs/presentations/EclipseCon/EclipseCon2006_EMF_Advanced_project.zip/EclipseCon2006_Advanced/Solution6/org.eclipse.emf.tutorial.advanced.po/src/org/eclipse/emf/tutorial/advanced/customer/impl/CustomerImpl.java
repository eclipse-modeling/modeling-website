/**
 * <copyright>
 * </copyright>
 *
 * $Id: CustomerImpl.java,v 1.1 2006/03/28 22:06:00 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.customer.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.emf.tutorial.advanced.customer.Customer;
import org.eclipse.emf.tutorial.advanced.customer.CustomerPackage;
import org.eclipse.emf.tutorial.advanced.customer.PaymentMethod;

import org.eclipse.emf.tutorial.advanced.po.POPackage;
import org.eclipse.emf.tutorial.advanced.po.PurchaseOrder;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Customer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl#getPurchaseOrders <em>Purchase Orders</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl#getIdentifier <em>Identifier</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl#isVIP <em>VIP</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl#getPreferredPaymentMethod <em>Preferred Payment Method</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CustomerImpl extends PersonImpl implements Customer
{
  /**
   * The cached value of the '{@link #getPurchaseOrders() <em>Purchase Orders</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPurchaseOrders()
   * @generated
   * @ordered
   */
  protected EList purchaseOrders = null;

  /**
   * The default value of the '{@link #getIdentifier() <em>Identifier</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIdentifier()
   * @generated
   * @ordered
   */
  protected static final String IDENTIFIER_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getIdentifier() <em>Identifier</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getIdentifier()
   * @generated
   * @ordered
   */
  protected String identifier = IDENTIFIER_EDEFAULT;

  /**
   * The default value of the '{@link #isVIP() <em>VIP</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isVIP()
   * @generated
   * @ordered
   */
  protected static final boolean VIP_EDEFAULT = false;

  /**
   * The cached value of the '{@link #isVIP() <em>VIP</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isVIP()
   * @generated
   * @ordered
   */
  protected boolean vIP = VIP_EDEFAULT;

  /**
   * The default value of the '{@link #getPreferredPaymentMethod() <em>Preferred Payment Method</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPreferredPaymentMethod()
   * @generated
   * @ordered
   */
  protected static final PaymentMethod PREFERRED_PAYMENT_METHOD_EDEFAULT = PaymentMethod.CREDIT_CARD_LITERAL;

  /**
   * The cached value of the '{@link #getPreferredPaymentMethod() <em>Preferred Payment Method</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPreferredPaymentMethod()
   * @generated
   * @ordered
   */
  protected PaymentMethod preferredPaymentMethod = PREFERRED_PAYMENT_METHOD_EDEFAULT;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected CustomerImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return CustomerPackage.Literals.CUSTOMER;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getPurchaseOrders()
  {
    if (purchaseOrders == null)
    {
      purchaseOrders = new EObjectWithInverseResolvingEList(PurchaseOrder.class, this, CustomerPackage.CUSTOMER__PURCHASE_ORDERS, POPackage.PURCHASE_ORDER__CUSTOMER);
    }
    return purchaseOrders;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getIdentifier()
  {
    return identifier;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setIdentifier(String newIdentifier)
  {
    String oldIdentifier = identifier;
    identifier = newIdentifier;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, CustomerPackage.CUSTOMER__IDENTIFIER, oldIdentifier, identifier));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isVIP()
  {
    return vIP;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setVIP(boolean newVIP)
  {
    boolean oldVIP = vIP;
    vIP = newVIP;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, CustomerPackage.CUSTOMER__VIP, oldVIP, vIP));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PaymentMethod getPreferredPaymentMethod()
  {
    return preferredPaymentMethod;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPreferredPaymentMethod(PaymentMethod newPreferredPaymentMethod)
  {
    PaymentMethod oldPreferredPaymentMethod = preferredPaymentMethod;
    preferredPaymentMethod = newPreferredPaymentMethod == null ? PREFERRED_PAYMENT_METHOD_EDEFAULT : newPreferredPaymentMethod;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD, oldPreferredPaymentMethod, preferredPaymentMethod));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        return ((InternalEList)getPurchaseOrders()).basicAdd(otherEnd, msgs);
    }
    return super.eInverseAdd(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        return ((InternalEList)getPurchaseOrders()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        return getPurchaseOrders();
      case CustomerPackage.CUSTOMER__IDENTIFIER:
        return getIdentifier();
      case CustomerPackage.CUSTOMER__VIP:
        return isVIP() ? Boolean.TRUE : Boolean.FALSE;
      case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
        return getPreferredPaymentMethod();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        getPurchaseOrders().clear();
        getPurchaseOrders().addAll((Collection)newValue);
        return;
      case CustomerPackage.CUSTOMER__IDENTIFIER:
        setIdentifier((String)newValue);
        return;
      case CustomerPackage.CUSTOMER__VIP:
        setVIP(((Boolean)newValue).booleanValue());
        return;
      case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
        setPreferredPaymentMethod((PaymentMethod)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        getPurchaseOrders().clear();
        return;
      case CustomerPackage.CUSTOMER__IDENTIFIER:
        setIdentifier(IDENTIFIER_EDEFAULT);
        return;
      case CustomerPackage.CUSTOMER__VIP:
        setVIP(VIP_EDEFAULT);
        return;
      case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
        setPreferredPaymentMethod(PREFERRED_PAYMENT_METHOD_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        return purchaseOrders != null && !purchaseOrders.isEmpty();
      case CustomerPackage.CUSTOMER__IDENTIFIER:
        return IDENTIFIER_EDEFAULT == null ? identifier != null : !IDENTIFIER_EDEFAULT.equals(identifier);
      case CustomerPackage.CUSTOMER__VIP:
        return vIP != VIP_EDEFAULT;
      case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
        return preferredPaymentMethod != PREFERRED_PAYMENT_METHOD_EDEFAULT;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (identifier: ");
    result.append(identifier);
    result.append(", vIP: ");
    result.append(vIP);
    result.append(", preferredPaymentMethod: ");
    result.append(preferredPaymentMethod);
    result.append(')');
    return result.toString();
  }

} //CustomerImpl