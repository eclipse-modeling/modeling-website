/**
 * <copyright>
 * </copyright>
 *
 * $Id: CustomerResourceFactoryImpl.java,v 1.1 2006/03/28 22:06:00 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.customer.util;

import org.eclipse.emf.common.util.URI;

import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.impl.EPackageRegistryImpl;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;

import org.eclipse.emf.ecore.resource.impl.ResourceFactoryImpl;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.mapping.ecore2xml.Ecore2XMLPackage;
import org.eclipse.emf.mapping.ecore2xml.Ecore2XMLRegistry;
import org.eclipse.emf.mapping.ecore2xml.impl.Ecore2XMLRegistryImpl;
import org.eclipse.emf.mapping.ecore2xml.util.Ecore2XMLExtendedMetaData;
import org.eclipse.emf.tutorial.advanced.customer.CustomerPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Resource Factory</b> associated with the package.
 * <!-- end-user-doc -->
 * @see org.eclipse.emf.tutorial.advanced.customer.util.CustomerResourceImpl
 * @generated
 */
public class CustomerResourceFactoryImpl extends ResourceFactoryImpl
{
  /**
   * Creates an instance of the resource factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public CustomerResourceFactoryImpl()
  {
    super();
  }

  /**
   * Creates an instance of the resource.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Resource createResourceGen(URI uri)
  {
    Resource result = new CustomerResourceImpl(uri);
    return result;
  }

  public Resource createResource(URI uri)
  {
    XMLResource result = (XMLResource)createResourceGen(uri);

    // register the new schema against the old namespace URI
    String oldNamespaceURI = "http://www.eclipse.org/emf/tutorial/advanced/2006/Customer";
    EPackage.Registry ePackageRegistry = new EPackageRegistryImpl(EPackage.Registry.INSTANCE);
    ePackageRegistry.put(oldNamespaceURI, CustomerPackage.eINSTANCE);

    // register the new schema against the customer.ecore file referenced by the mapping
    ePackageRegistry.put("platform:/plugin/org.eclipse.emf.tutorial.advanced.po/model/customer.ecore", CustomerPackage.eINSTANCE);

    // set the package registry for the resource set
    ResourceSet resourceSet = new ResourceSetImpl();
    resourceSet.setPackageRegistry(ePackageRegistry);

    // register the mapping with the ecore2xml registry
    Ecore2XMLRegistry ecore2xmlRegistry = new Ecore2XMLRegistryImpl(Ecore2XMLRegistry.INSTANCE);
    ecore2xmlRegistry.put(oldNamespaceURI, EcoreUtil.getObjectByType(resourceSet.getResource(
      URI.createURI("platform:/plugin/org.eclipse.emf.tutorial.advanced.po/model/customer2006_2_customer.ecore2xml"),
      true).getContents(), Ecore2XMLPackage.Literals.XML_MAP));

    // specify an ecore2xml extended metadata as a load option
    result.getDefaultLoadOptions().put(
      XMLResource.OPTION_EXTENDED_META_DATA,
      new Ecore2XMLExtendedMetaData(ePackageRegistry, ecore2xmlRegistry));

    return result;
  }

} //CustomerResourceFactoryImpl
