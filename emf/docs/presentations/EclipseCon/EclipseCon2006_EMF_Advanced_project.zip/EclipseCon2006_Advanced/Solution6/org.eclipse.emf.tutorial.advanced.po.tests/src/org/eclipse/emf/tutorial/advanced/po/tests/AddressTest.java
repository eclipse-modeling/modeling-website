/**
 * <copyright>
 * </copyright>
 *
 * $Id: AddressTest.java,v 1.1 2006/03/28 22:06:00 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.po.tests;

import junit.framework.TestCase;

import junit.textui.TestRunner;

import org.eclipse.emf.tutorial.advanced.po.Address;
import org.eclipse.emf.tutorial.advanced.po.POFactory;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Address</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public class AddressTest extends TestCase
{

  /**
   * The fixture for this Address test case.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Address fixture = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public static void main(String[] args)
  {
    TestRunner.run(AddressTest.class);
  }

  /**
   * Constructs a new Address test case with the given name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public AddressTest(String name)
  {
    super(name);
  }

  /**
   * Sets the fixture for this Address test case.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected void setFixture(Address fixture)
  {
    this.fixture = fixture;
  }

  /**
   * Returns the fixture for this Address test case.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  private Address getFixture()
  {
    return fixture;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see junit.framework.TestCase#setUp()
   * @generated
   */
  protected void setUp() throws Exception
  {
    setFixture(POFactory.eINSTANCE.createAddress());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see junit.framework.TestCase#tearDown()
   * @generated
   */
  protected void tearDown() throws Exception
  {
    setFixture(null);
  }

} //AddressTest
