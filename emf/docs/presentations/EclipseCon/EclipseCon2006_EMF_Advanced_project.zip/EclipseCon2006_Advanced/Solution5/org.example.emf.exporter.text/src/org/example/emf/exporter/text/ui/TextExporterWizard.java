package org.example.emf.exporter.text.ui;

import org.eclipse.emf.converter.ModelConverter;
import org.eclipse.emf.exporter.ui.contribution.base.ModelExporterDirectoryURIPage;
import org.eclipse.emf.exporter.ui.contribution.base.ModelExporterOptionsPage;
import org.eclipse.emf.exporter.ui.contribution.base.ModelExporterPackagePage;
import org.eclipse.emf.exporter.ui.contribution.base.ModelExporterWizard;
import org.example.emf.exporter.text.TextExporter;
import org.example.emf.exporter.text.TextExporterPlugin;

public class TextExporterWizard extends ModelExporterWizard
{
  protected ModelConverter createModelConverter()
  {
    return new TextExporter();
  }
  
  public void addPages()
  {
    ModelExporterDirectoryURIPage directoryURIPage = new ModelExporterDirectoryURIPage(getModelExporter(), "TextExporterBaseLocationPage");
    directoryURIPage.setTitle(TextExporterPlugin.INSTANCE.getString("_UI_TextImport_title"));
    addPage(directoryURIPage);
    
    ModelExporterPackagePage packagePage = new ModelExporterPackagePage(getModelExporter(), "TextExporterGenModelDetailPage");
    packagePage.setTitle(TextExporterPlugin.INSTANCE.getString("_UI_TextImport_title"));
    packagePage.setShowReferencedGenModels(true);
    addPage(packagePage);
    
    ModelExporterOptionsPage optionsPage = new ModelExporterOptionsPage(getModelExporter(), "TextExporterOptionsPage");
    optionsPage.setTitle(TextExporterPlugin.INSTANCE.getString("_UI_TextImport_title"));
    addPage(optionsPage);
  }  
}
