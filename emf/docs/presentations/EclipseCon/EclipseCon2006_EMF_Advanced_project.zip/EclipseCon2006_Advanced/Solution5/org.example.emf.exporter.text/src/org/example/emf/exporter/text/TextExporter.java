package org.example.emf.exporter.text;

import java.io.OutputStream;
import java.util.Iterator;
import java.util.Map;

import org.eclipse.emf.codegen.ecore.genmodel.GenPackage;
import org.eclipse.emf.common.util.Monitor;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EEnumLiteral;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.resource.URIConverter;
import org.eclipse.emf.ecore.resource.impl.URIConverterImpl;
import org.eclipse.emf.exporter.ModelExporter;

public class TextExporter extends ModelExporter
{
  public String getID()
  {
    return "org.example.emf.exporter.text";
  }

  protected String getDefaultArtifactLocation(EPackage ePackage)
  {
    return getDefaultArtifactFileName(ePackage) + ".txt";
  }

  protected String doCheckEPackageArtifactLocation(String location, String packageName)
  {
    if (!location.endsWith(".txt"))
    {
      return TextExporterPlugin.INSTANCE.getString("_UI_InvalidArtifactFileNameExtension_message");
    }
    return super.doCheckEPackageArtifactLocation(location, packageName);
  }

  protected void doExport(Monitor monitor, ExportData exportData) throws Exception
  {
    for (Iterator i = exportData.genPackageToArtifactURI.entrySet().iterator(); i.hasNext();)
    {
      Map.Entry entry = (Map.Entry)i.next();      
      GenPackage genPackage = (GenPackage)entry.getKey();
      URI exportedArtifactURI = (URI)entry.getValue();
      
      String content = toString(genPackage);
      save(exportedArtifactURI, content);
    }
  }
  
  private String toString(GenPackage genPackage)
  {
    StringBuffer sb = new StringBuffer();
    sb.append("Package: ").append(genPackage.getQualifiedPackageName());

    sb.append("\n");
    EPackage ePackage = genPackage.getEcorePackage();    
    sb.append("\n").append("Ecore URI: ").append(ePackage.eResource().getURI().toString());
    sb.append("\n").append("GenModel URI: ").append(genPackage.eResource().getURI().toString());
    
    for (Iterator i = ePackage.getEClassifiers().iterator(); i.hasNext();)
    {
      sb.append("\n");
      
      EClassifier eClassifier = (EClassifier)i.next();
      if (eClassifier instanceof EClass)
      {
        EClass eClass = (EClass)eClassifier;
        sb.append("\n").append("Class: ").append(eClass.getName());
        
        if (!eClass.getEAttributes().isEmpty())
        {
          sb.append("\n\t").append("Attributes: ");
          for (Iterator j = eClass.getEAttributes().iterator(); j.hasNext();)
          {
            EAttribute eAttribute = (EAttribute)j.next();
            sb.append(eAttribute.getName());
            if (j.hasNext()) sb.append(", ");
          }
        }
      }
      else if (eClassifier instanceof EEnum)
      {
        EEnum eEnum = (EEnum)eClassifier;
        sb.append("\n").append("Enumeration: ").append(eEnum.getName());
        if (!eEnum.getELiterals().isEmpty())
        {
          sb.append("\n\t").append("Literals: ");
          for (Iterator j = eEnum.getELiterals().iterator(); j.hasNext();)
          {
            EEnumLiteral enumLiteral = (EEnumLiteral)j.next();
            sb.append(enumLiteral.getName());
            if (j.hasNext()) sb.append(", ");
          }
        }
      }
      else if (eClassifier instanceof EDataType)
      {
        EDataType eDataType = (EDataType)eClassifier;
        sb.append("\n").append("Data Type: ").append(eDataType.getName());
      }
    }
    
    return sb.toString();
  }
  
  private void save(URI uri, String content) throws Exception
  {
    URIConverter uriConverter = new URIConverterImpl();
    OutputStream outputStream = uriConverter.createOutputStream(uri);
    outputStream.write(content.getBytes("UTF-8"));
    outputStream.close();
  }
}
