/*
 * Copyright (c) 2006 My Company and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 */
package org.eclipse.emf.tutorial.advanced.customer;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.eclipse.emf.common.util.AbstractEnumerator;

/**
 * <!-- begin-user-doc -->
 * A representation of the literals of the enumeration '<em><b>Payment Method</b></em>',
 * and utility methods for working with them.
 * <!-- end-user-doc -->
 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getPaymentMethod()
 * @model
 * @generated
 */
public final class PaymentMethod extends AbstractEnumerator {
	/**
	 * The '<em><b>Credit Card</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Credit Card</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CREDIT_CARD_LITERAL
	 * @model name="CreditCard"
	 * @generated
	 * @ordered
	 */
	public static final int CREDIT_CARD = 0;

	/**
	 * The '<em><b>Debit Card</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Debit Card</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #DEBIT_CARD_LITERAL
	 * @model name="DebitCard"
	 * @generated
	 * @ordered
	 */
	public static final int DEBIT_CARD = 1;

	/**
	 * The '<em><b>Cheque</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Cheque</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #CHEQUE_LITERAL
	 * @model name="Cheque"
	 * @generated
	 * @ordered
	 */
	public static final int CHEQUE = 2;

	/**
	 * The '<em><b>Money Order</b></em>' literal value.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of '<em><b>Money Order</b></em>' literal object isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @see #MONEY_ORDER_LITERAL
	 * @model name="MoneyOrder"
	 * @generated
	 * @ordered
	 */
	public static final int MONEY_ORDER = 3;

	/**
	 * The '<em><b>Credit Card</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CREDIT_CARD
	 * @generated
	 * @ordered
	 */
	public static final PaymentMethod CREDIT_CARD_LITERAL = new PaymentMethod(CREDIT_CARD, "CreditCard", "CreditCard");

	/**
	 * The '<em><b>Debit Card</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #DEBIT_CARD
	 * @generated
	 * @ordered
	 */
	public static final PaymentMethod DEBIT_CARD_LITERAL = new PaymentMethod(DEBIT_CARD, "DebitCard", "DebitCard");

	/**
	 * The '<em><b>Cheque</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #CHEQUE
	 * @generated
	 * @ordered
	 */
	public static final PaymentMethod CHEQUE_LITERAL = new PaymentMethod(CHEQUE, "Cheque", "Cheque");

	/**
	 * The '<em><b>Money Order</b></em>' literal object.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #MONEY_ORDER
	 * @generated
	 * @ordered
	 */
	public static final PaymentMethod MONEY_ORDER_LITERAL = new PaymentMethod(MONEY_ORDER, "MoneyOrder", "MoneyOrder");

	/**
	 * An array of all the '<em><b>Payment Method</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static final PaymentMethod[] VALUES_ARRAY =
		new PaymentMethod[] {
			CREDIT_CARD_LITERAL,
			DEBIT_CARD_LITERAL,
			CHEQUE_LITERAL,
			MONEY_ORDER_LITERAL,
		};

	/**
	 * A public read-only list of all the '<em><b>Payment Method</b></em>' enumerators.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final List VALUES = Collections.unmodifiableList(Arrays.asList(VALUES_ARRAY));

	/**
	 * Returns the '<em><b>Payment Method</b></em>' literal with the specified literal value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PaymentMethod get(String literal) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			PaymentMethod result = VALUES_ARRAY[i];
			if (result.toString().equals(literal)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Payment Method</b></em>' literal with the specified name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PaymentMethod getByName(String name) {
		for (int i = 0; i < VALUES_ARRAY.length; ++i) {
			PaymentMethod result = VALUES_ARRAY[i];
			if (result.getName().equals(name)) {
				return result;
			}
		}
		return null;
	}

	/**
	 * Returns the '<em><b>Payment Method</b></em>' literal with the specified integer value.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static PaymentMethod get(int value) {
		switch (value) {
			case CREDIT_CARD: return CREDIT_CARD_LITERAL;
			case DEBIT_CARD: return DEBIT_CARD_LITERAL;
			case CHEQUE: return CHEQUE_LITERAL;
			case MONEY_ORDER: return MONEY_ORDER_LITERAL;
		}
		return null;	
	}

	/**
	 * Only this class can construct instances.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private PaymentMethod(int value, String name, String literal) {
		super(value, name, literal);
	}

} //PaymentMethod
