/*
 * Copyright (c) 2006 My Company and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 */
package org.eclipse.emf.tutorial.advanced.customer;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EFactory;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

import org.eclipse.emf.ecore.impl.EPackageImpl;

import org.eclipse.emf.tutorial.advanced.datatype.DataTypePackage;

import org.eclipse.emf.tutorial.advanced.po.POPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerFactory
 * @model kind="package"
 * @generated
 */
public class CustomerPackage extends EPackageImpl {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String eNAME = "customer";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String eNS_URI = "http://www.eclipse.org/emf/tutorial/advanced/2006/Customer";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final String eNS_PREFIX = "customer";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static final CustomerPackage eINSTANCE = org.eclipse.emf.tutorial.advanced.customer.CustomerPackage.init();

	/**
	 * The meta object id for the '{@link org.eclipse.emf.tutorial.advanced.customer.Person <em>Person</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.tutorial.advanced.customer.Person
	 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getPerson()
	 * @generated
	 */
	public static final int PERSON = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int PERSON__NAME = 0;

	/**
	 * The feature id for the '<em><b>Birthday</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int PERSON__BIRTHDAY = 1;

	/**
	 * The number of structural features of the '<em>Person</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int PERSON_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer <em>Customer</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer
	 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer()
	 * @generated
	 */
	public static final int CUSTOMER = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CUSTOMER__NAME = PERSON__NAME;

	/**
	 * The feature id for the '<em><b>Birthday</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CUSTOMER__BIRTHDAY = PERSON__BIRTHDAY;

	/**
	 * The feature id for the '<em><b>Purchase Orders</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CUSTOMER__PURCHASE_ORDERS = PERSON_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CUSTOMER__ID = PERSON_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>Vip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CUSTOMER__VIP = PERSON_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Preferred Payment Method</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CUSTOMER__PREFERRED_PAYMENT_METHOD = PERSON_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Customer</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	public static final int CUSTOMER_FEATURE_COUNT = PERSON_FEATURE_COUNT + 4;

	/**
	 * The meta object id for the '{@link org.eclipse.emf.tutorial.advanced.customer.PaymentMethod <em>Payment Method</em>}' enum.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
	 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getPaymentMethod()
	 * @generated
	 */
	public static final int PAYMENT_METHOD = 2;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass personEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EClass customerEClass = null;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private EEnum paymentMethodEEnum = null;

	/**
	 * Creates an instance of the model <b>Package</b>, registered with
	 * {@link org.eclipse.emf.ecore.EPackage.Registry EPackage.Registry} by the package
	 * package URI value.
	 * <p>Note: the correct way to create the package is via the static
	 * factory method {@link #init init()}, which also performs
	 * initialization of the package, or returns the registered package,
	 * if one already exists.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.ecore.EPackage.Registry
	 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#eNS_URI
	 * @see #init()
	 * @generated
	 */
	private CustomerPackage() {
		super(eNS_URI, ((EFactory)CustomerFactory.INSTANCE));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private static boolean isInited = false;

	/**
	 * Creates, registers, and initializes the <b>Package</b> for this
	 * model, and for any others upon which it depends.  Simple
	 * dependencies are satisfied by calling this method on all
	 * dependent packages before doing anything else.  This method drives
	 * initialization for interdependent packages directly, in parallel
	 * with this package, itself.
	 * <p>Of this package and its interdependencies, all packages which
	 * have not yet been registered by their URI values are first created
	 * and registered.  The packages are then initialized in two steps:
	 * meta-model objects for all of the packages are created before any
	 * are initialized, since one package's meta-model objects may refer to
	 * those of another.
	 * <p>Invocation of this method will not affect any packages that have
	 * already been initialized.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #eNS_URI
	 * @see #createPackageContents()
	 * @see #initializePackageContents()
	 * @generated
	 */
	public static CustomerPackage init() {
		if (isInited) return (CustomerPackage)EPackage.Registry.INSTANCE.getEPackage(CustomerPackage.eNS_URI);

		// Obtain or create and register package
		CustomerPackage theCustomerPackage = (CustomerPackage)(EPackage.Registry.INSTANCE.getEPackage(eNS_URI) instanceof CustomerPackage ? EPackage.Registry.INSTANCE.getEPackage(eNS_URI) : new CustomerPackage());

		isInited = true;

		// Obtain or create and register interdependencies
		DataTypePackage theDataTypePackage = (DataTypePackage)(EPackage.Registry.INSTANCE.getEPackage(DataTypePackage.eNS_URI) instanceof DataTypePackage ? EPackage.Registry.INSTANCE.getEPackage(DataTypePackage.eNS_URI) : DataTypePackage.eINSTANCE);
		POPackage thePOPackage = (POPackage)(EPackage.Registry.INSTANCE.getEPackage(POPackage.eNS_URI) instanceof POPackage ? EPackage.Registry.INSTANCE.getEPackage(POPackage.eNS_URI) : POPackage.eINSTANCE);

		// Create package meta-data objects
		theCustomerPackage.createPackageContents();
		theDataTypePackage.createPackageContents();
		thePOPackage.createPackageContents();

		// Initialize created meta-data
		theCustomerPackage.initializePackageContents();
		theDataTypePackage.initializePackageContents();
		thePOPackage.initializePackageContents();

		// Mark meta-data to indicate it can't be changed
		theCustomerPackage.freeze();

		return theCustomerPackage;
	}


	/**
	 * Returns the meta object for class '{@link org.eclipse.emf.tutorial.advanced.customer.Person <em>Person</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Person</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Person
	 * @generated
	 */
	public EClass getPerson() {
		return personEClass;
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.customer.Person#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Person#getName()
	 * @see #getPerson()
	 * @generated
	 */
	public EAttribute getPerson_Name() {
		return (EAttribute)personEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.customer.Person#getBirthday <em>Birthday</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Birthday</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Person#getBirthday()
	 * @see #getPerson()
	 * @generated
	 */
	public EAttribute getPerson_Birthday() {
		return (EAttribute)personEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for class '{@link org.eclipse.emf.tutorial.advanced.customer.Customer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Customer</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer
	 * @generated
	 */
	public EClass getCustomer() {
		return customerEClass;
	}

	/**
	 * Returns the meta object for the reference list '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPurchaseOrdersList <em>Purchase Orders</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Purchase Orders</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer#getPurchaseOrdersList()
	 * @see #getCustomer()
	 * @generated
	 */
	public EReference getCustomer_PurchaseOrders() {
		return (EReference)customerEClass.getEStructuralFeatures().get(0);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getId <em>Id</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Id</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer#getId()
	 * @see #getCustomer()
	 * @generated
	 */
	public EAttribute getCustomer_Id() {
		return (EAttribute)customerEClass.getEStructuralFeatures().get(1);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#isVip <em>Vip</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Vip</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer#isVip()
	 * @see #getCustomer()
	 * @generated
	 */
	public EAttribute getCustomer_Vip() {
		return (EAttribute)customerEClass.getEStructuralFeatures().get(2);
	}

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPreferredPaymentMethod <em>Preferred Payment Method</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Preferred Payment Method</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer#getPreferredPaymentMethod()
	 * @see #getCustomer()
	 * @generated
	 */
	public EAttribute getCustomer_PreferredPaymentMethod() {
		return (EAttribute)customerEClass.getEStructuralFeatures().get(3);
	}

	/**
	 * Returns the meta object for enum '{@link org.eclipse.emf.tutorial.advanced.customer.PaymentMethod <em>Payment Method</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Payment Method</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
	 * @generated
	 */
	public EEnum getPaymentMethod() {
		return paymentMethodEEnum;
	}

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	public CustomerFactory getCustomerFactory() {
		return (CustomerFactory)getEFactoryInstance();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isCreated = false;

	/**
	 * Creates the meta-model objects for the package.  This method is
	 * guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void createPackageContents() {
		if (isCreated) return;
		isCreated = true;

		// Create classes and their features
		personEClass = createEClass(PERSON);
		createEAttribute(personEClass, PERSON__NAME);
		createEAttribute(personEClass, PERSON__BIRTHDAY);

		customerEClass = createEClass(CUSTOMER);
		createEReference(customerEClass, CUSTOMER__PURCHASE_ORDERS);
		createEAttribute(customerEClass, CUSTOMER__ID);
		createEAttribute(customerEClass, CUSTOMER__VIP);
		createEAttribute(customerEClass, CUSTOMER__PREFERRED_PAYMENT_METHOD);

		// Create enums
		paymentMethodEEnum = createEEnum(PAYMENT_METHOD);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private boolean isInitialized = false;

	/**
	 * Complete the initialization of the package and its meta-model.  This
	 * method is guarded to have no affect on any invocation but its first.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void initializePackageContents() {
		if (isInitialized) return;
		isInitialized = true;

		// Initialize package
		setName(eNAME);
		setNsPrefix(eNS_PREFIX);
		setNsURI(eNS_URI);

		// Obtain other dependent packages
		DataTypePackage theDataTypePackage = (DataTypePackage)EPackage.Registry.INSTANCE.getEPackage(DataTypePackage.eNS_URI);
		POPackage thePOPackage = (POPackage)EPackage.Registry.INSTANCE.getEPackage(POPackage.eNS_URI);

		// Add supertypes to classes
		customerEClass.getESuperTypes().add(this.getPerson());

		// Initialize classes and features; add operations and parameters
		initEClass(personEClass, Person.class, "Person", IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEAttribute(getPerson_Name(), ecorePackage.getEString(), "name", null, 0, 1, Person.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getPerson_Birthday(), theDataTypePackage.getDate(), "birthday", null, 0, 1, Person.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		addEOperation(personEClass, ecorePackage.getEInt(), "computeAge", 0, 1);

		initEClass(customerEClass, Customer.class, "Customer", !IS_ABSTRACT, !IS_INTERFACE, IS_GENERATED_INSTANCE_CLASS);
		initEReference(getCustomer_PurchaseOrders(), thePOPackage.getPurchaseOrder(), thePOPackage.getPurchaseOrder_Customer(), "purchaseOrders", null, 1, -1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_COMPOSITE, IS_RESOLVE_PROXIES, !IS_UNSETTABLE, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCustomer_Id(), ecorePackage.getEString(), "id", null, 0, 1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCustomer_Vip(), ecorePackage.getEBoolean(), "vip", null, 0, 1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);
		initEAttribute(getCustomer_PreferredPaymentMethod(), this.getPaymentMethod(), "preferredPaymentMethod", null, 0, 1, Customer.class, !IS_TRANSIENT, !IS_VOLATILE, IS_CHANGEABLE, !IS_UNSETTABLE, !IS_ID, IS_UNIQUE, !IS_DERIVED, IS_ORDERED);

		// Initialize enums and add enum literals
		initEEnum(paymentMethodEEnum, PaymentMethod.class, "PaymentMethod");
		addEEnumLiteral(paymentMethodEEnum, PaymentMethod.CREDIT_CARD_LITERAL);
		addEEnumLiteral(paymentMethodEEnum, PaymentMethod.DEBIT_CARD_LITERAL);
		addEEnumLiteral(paymentMethodEEnum, PaymentMethod.CHEQUE_LITERAL);
		addEEnumLiteral(paymentMethodEEnum, PaymentMethod.MONEY_ORDER_LITERAL);

		// Create resource
		createResource(eNS_URI);
	}

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public interface Literals {
		/**
		 * The meta object literal for the '{@link org.eclipse.emf.tutorial.advanced.customer.Person <em>Person</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.emf.tutorial.advanced.customer.Person
		 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getPerson()
		 * @generated
		 */
		public static final EClass PERSON = eINSTANCE.getPerson();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute PERSON__NAME = eINSTANCE.getPerson_Name();

		/**
		 * The meta object literal for the '<em><b>Birthday</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute PERSON__BIRTHDAY = eINSTANCE.getPerson_Birthday();

		/**
		 * The meta object literal for the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer <em>Customer</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.emf.tutorial.advanced.customer.Customer
		 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer()
		 * @generated
		 */
		public static final EClass CUSTOMER = eINSTANCE.getCustomer();

		/**
		 * The meta object literal for the '<em><b>Purchase Orders</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EReference CUSTOMER__PURCHASE_ORDERS = eINSTANCE.getCustomer_PurchaseOrders();

		/**
		 * The meta object literal for the '<em><b>Id</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute CUSTOMER__ID = eINSTANCE.getCustomer_Id();

		/**
		 * The meta object literal for the '<em><b>Vip</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute CUSTOMER__VIP = eINSTANCE.getCustomer_Vip();

		/**
		 * The meta object literal for the '<em><b>Preferred Payment Method</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		public static final EAttribute CUSTOMER__PREFERRED_PAYMENT_METHOD = eINSTANCE.getCustomer_PreferredPaymentMethod();

		/**
		 * The meta object literal for the '{@link org.eclipse.emf.tutorial.advanced.customer.PaymentMethod <em>Payment Method</em>}' enum.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
		 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getPaymentMethod()
		 * @generated
		 */
		public static final EEnum PAYMENT_METHOD = eINSTANCE.getPaymentMethod();

	}

} //CustomerPackage
