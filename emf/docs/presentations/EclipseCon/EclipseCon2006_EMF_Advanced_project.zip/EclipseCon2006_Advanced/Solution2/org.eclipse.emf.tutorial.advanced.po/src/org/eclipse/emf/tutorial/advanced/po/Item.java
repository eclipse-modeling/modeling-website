/*
 * Copyright (c) 2006 My Company and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 */
package org.eclipse.emf.tutorial.advanced.po;

import java.util.Collection;
import java.util.Date;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Item</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.Item#getSubItemsList <em>Sub Items</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.Item#getProductName <em>Product Name</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.Item#getQuantity <em>Quantity</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.Item#getPrice <em>Price</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.Item#getComment <em>Comment</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.Item#getShipDate <em>Ship Date</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.Item#getPartNum <em>Part Num</em>}</li>
 * </ul>
 * </p>
 *
 * @model
 * @generated
 */
public class Item extends EObjectImpl {
	/**
	 * The cached value of the '{@link #getSubItemsList() <em>Sub Items</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubItemsList()
	 * @generated
	 * @ordered
	 */
	protected EList subItems = null;

	/**
	 * The empty value for the '{@link #getSubItems() <em>Sub Items</em>}' array accessor.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSubItems()
	 * @generated
	 * @ordered
	 */
	protected static final Item[] SUB_ITEMS_EEMPTY_ARRAY = new Item [0];

	/**
	 * The default value of the '{@link #getProductName() <em>Product Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductName()
	 * @generated
	 * @ordered
	 */
	protected static final String PRODUCT_NAME_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getProductName() <em>Product Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getProductName()
	 * @generated
	 * @ordered
	 */
	protected String productName = PRODUCT_NAME_EDEFAULT;

	/**
	 * The default value of the '{@link #getQuantity() <em>Quantity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQuantity()
	 * @generated
	 * @ordered
	 */
	protected static final int QUANTITY_EDEFAULT = 0;

	/**
	 * The cached value of the '{@link #getQuantity() <em>Quantity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getQuantity()
	 * @generated
	 * @ordered
	 */
	protected int quantity = QUANTITY_EDEFAULT;

	/**
	 * The default value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected static final float PRICE_EDEFAULT = 0.0F;

	/**
	 * The cached value of the '{@link #getPrice() <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPrice()
	 * @generated
	 * @ordered
	 */
	protected float price = PRICE_EDEFAULT;

	/**
	 * The default value of the '{@link #getComment() <em>Comment</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComment()
	 * @generated
	 * @ordered
	 */
	protected static final String COMMENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getComment() <em>Comment</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComment()
	 * @generated
	 * @ordered
	 */
	protected String comment = COMMENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getShipDate() <em>Ship Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShipDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date SHIP_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getShipDate() <em>Ship Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShipDate()
	 * @generated
	 * @ordered
	 */
	protected Date shipDate = SHIP_DATE_EDEFAULT;

	/**
	 * The default value of the '{@link #getPartNum() <em>Part Num</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPartNum()
	 * @generated
	 * @ordered
	 */
	protected static final String PART_NUM_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getPartNum() <em>Part Num</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPartNum()
	 * @generated
	 * @ordered
	 */
	protected String partNum = PART_NUM_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Item() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return POPackage.Literals.ITEM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Item[] getSubItems() {
		if (subItems == null || subItems.isEmpty()) return SUB_ITEMS_EEMPTY_ARRAY;
		BasicEList list = (BasicEList)subItems;
		list.shrink();
		return (Item[])list.data();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Item getSubItems(int index) {
		return (Item)getSubItemsList().get(index);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getSubItemsLength() {
		return subItems == null ? 0 : subItems.size();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSubItems(Item[] newSubItems) {
		((BasicEList)getSubItemsList()).setData(newSubItems.length, newSubItems);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSubItems(int index, Item element) {
		getSubItemsList().set(index, element);
	}

	/**
	 * Returns the value of the '<em><b>Sub Items</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.emf.tutorial.advanced.po.Item}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Sub Items</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Sub Items</em>' containment reference list.
	 * @model type="org.eclipse.emf.tutorial.advanced.po.Item" containment="true"
	 * @generated
	 */
	public EList getSubItemsList() {
		if (subItems == null) {
			subItems = new EObjectContainmentEList(Item.class, this, POPackage.ITEM__SUB_ITEMS);
		}
		return subItems;
	}


	/**
	 * Adds the specified {@link org.eclipse.emf.tutorial.advanced.po.Item} at the specified index in the '<em><b>Sub Items</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param index The index at which to add the {@link org.eclipse.emf.tutorial.advanced.po.Item}.
	 * @param value The {@link org.eclipse.emf.tutorial.advanced.po.Item} to be added.
	 * @see #getSubItemsList()
	 * @generated
	 */
	public void addSubItems(int index, Item value) {
		getSubItemsList().add(index, value);
	}

	/**
	 * Removes the specified {@link org.eclipse.emf.tutorial.advanced.po.Item} from the '<em><b>Sub Items</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value The {@link org.eclipse.emf.tutorial.advanced.po.Item} to be removed.
	 * @return Whether the {@link org.eclipse.emf.tutorial.advanced.po.Item} was successfully removed.
	 * @see #getSubItemsList()
	 * @generated
	 */
	public boolean removeSubItems(Item value) {
		return getSubItemsList().remove(value);
	}

	/**
	 * Returns the value of the '<em><b>Product Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Product Name</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Product Name</em>' attribute.
	 * @see #setProductName(String)
	 * @model
	 * @generated
	 */
	public String getProductName() {
		return productName;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.Item#getProductName <em>Product Name</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Product Name</em>' attribute.
	 * @see #getProductName()
	 * @generated
	 */
	public void setProductName(String newProductName) {
		String oldProductName = productName;
		productName = newProductName;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.ITEM__PRODUCT_NAME, oldProductName, productName));
	}


	/**
	 * Returns the value of the '<em><b>Quantity</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Quantity</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Quantity</em>' attribute.
	 * @see #setQuantity(int)
	 * @model
	 * @generated
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.Item#getQuantity <em>Quantity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Quantity</em>' attribute.
	 * @see #getQuantity()
	 * @generated
	 */
	public void setQuantity(int newQuantity) {
		int oldQuantity = quantity;
		quantity = newQuantity;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.ITEM__QUANTITY, oldQuantity, quantity));
	}


	/**
	 * Returns the value of the '<em><b>Price</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Price</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Price</em>' attribute.
	 * @see #setPrice(float)
	 * @model
	 * @generated
	 */
	public float getPrice() {
		return price;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.Item#getPrice <em>Price</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Price</em>' attribute.
	 * @see #getPrice()
	 * @generated
	 */
	public void setPrice(float newPrice) {
		float oldPrice = price;
		price = newPrice;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.ITEM__PRICE, oldPrice, price));
	}


	/**
	 * Returns the value of the '<em><b>Comment</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Comment</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Comment</em>' attribute.
	 * @see #setComment(String)
	 * @model
	 * @generated
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.Item#getComment <em>Comment</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Comment</em>' attribute.
	 * @see #getComment()
	 * @generated
	 */
	public void setComment(String newComment) {
		String oldComment = comment;
		comment = newComment;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.ITEM__COMMENT, oldComment, comment));
	}


	/**
	 * Returns the value of the '<em><b>Ship Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ship Date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ship Date</em>' attribute.
	 * @see #setShipDate(Date)
	 * @model dataType="org.eclipse.emf.tutorial.advanced.datatype.Date"
	 * @generated
	 */
	public Date getShipDate() {
		return shipDate;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.Item#getShipDate <em>Ship Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ship Date</em>' attribute.
	 * @see #getShipDate()
	 * @generated
	 */
	public void setShipDate(Date newShipDate) {
		Date oldShipDate = shipDate;
		shipDate = newShipDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.ITEM__SHIP_DATE, oldShipDate, shipDate));
	}


	/**
	 * Returns the value of the '<em><b>Part Num</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Part Num</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Part Num</em>' attribute.
	 * @see #setPartNum(String)
	 * @model dataType="org.eclipse.emf.tutorial.advanced.datatype.SKU"
	 * @generated
	 */
	public String getPartNum() {
		return partNum;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.Item#getPartNum <em>Part Num</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Part Num</em>' attribute.
	 * @see #getPartNum()
	 * @generated
	 */
	public void setPartNum(String newPartNum) {
		String oldPartNum = partNum;
		partNum = newPartNum;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.ITEM__PART_NUM, oldPartNum, partNum));
	}


	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case POPackage.ITEM__SUB_ITEMS:
				return ((InternalEList)getSubItemsList()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case POPackage.ITEM__SUB_ITEMS:
				return getSubItemsList();
			case POPackage.ITEM__PRODUCT_NAME:
				return getProductName();
			case POPackage.ITEM__QUANTITY:
				return new Integer(getQuantity());
			case POPackage.ITEM__PRICE:
				return new Float(getPrice());
			case POPackage.ITEM__COMMENT:
				return getComment();
			case POPackage.ITEM__SHIP_DATE:
				return getShipDate();
			case POPackage.ITEM__PART_NUM:
				return getPartNum();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case POPackage.ITEM__SUB_ITEMS:
				getSubItemsList().clear();
				getSubItemsList().addAll((Collection)newValue);
				return;
			case POPackage.ITEM__PRODUCT_NAME:
				setProductName((String)newValue);
				return;
			case POPackage.ITEM__QUANTITY:
				setQuantity(((Integer)newValue).intValue());
				return;
			case POPackage.ITEM__PRICE:
				setPrice(((Float)newValue).floatValue());
				return;
			case POPackage.ITEM__COMMENT:
				setComment((String)newValue);
				return;
			case POPackage.ITEM__SHIP_DATE:
				setShipDate((Date)newValue);
				return;
			case POPackage.ITEM__PART_NUM:
				setPartNum((String)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case POPackage.ITEM__SUB_ITEMS:
				getSubItemsList().clear();
				return;
			case POPackage.ITEM__PRODUCT_NAME:
				setProductName(PRODUCT_NAME_EDEFAULT);
				return;
			case POPackage.ITEM__QUANTITY:
				setQuantity(QUANTITY_EDEFAULT);
				return;
			case POPackage.ITEM__PRICE:
				setPrice(PRICE_EDEFAULT);
				return;
			case POPackage.ITEM__COMMENT:
				setComment(COMMENT_EDEFAULT);
				return;
			case POPackage.ITEM__SHIP_DATE:
				setShipDate(SHIP_DATE_EDEFAULT);
				return;
			case POPackage.ITEM__PART_NUM:
				setPartNum(PART_NUM_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case POPackage.ITEM__SUB_ITEMS:
				return subItems != null && !subItems.isEmpty();
			case POPackage.ITEM__PRODUCT_NAME:
				return PRODUCT_NAME_EDEFAULT == null ? productName != null : !PRODUCT_NAME_EDEFAULT.equals(productName);
			case POPackage.ITEM__QUANTITY:
				return quantity != QUANTITY_EDEFAULT;
			case POPackage.ITEM__PRICE:
				return price != PRICE_EDEFAULT;
			case POPackage.ITEM__COMMENT:
				return COMMENT_EDEFAULT == null ? comment != null : !COMMENT_EDEFAULT.equals(comment);
			case POPackage.ITEM__SHIP_DATE:
				return SHIP_DATE_EDEFAULT == null ? shipDate != null : !SHIP_DATE_EDEFAULT.equals(shipDate);
			case POPackage.ITEM__PART_NUM:
				return PART_NUM_EDEFAULT == null ? partNum != null : !PART_NUM_EDEFAULT.equals(partNum);
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (productName: ");
		result.append(productName);
		result.append(", quantity: ");
		result.append(quantity);
		result.append(", price: ");
		result.append(price);
		result.append(", comment: ");
		result.append(comment);
		result.append(", shipDate: ");
		result.append(shipDate);
		result.append(", partNum: ");
		result.append(partNum);
		result.append(')');
		return result.toString();
	}

} // Item