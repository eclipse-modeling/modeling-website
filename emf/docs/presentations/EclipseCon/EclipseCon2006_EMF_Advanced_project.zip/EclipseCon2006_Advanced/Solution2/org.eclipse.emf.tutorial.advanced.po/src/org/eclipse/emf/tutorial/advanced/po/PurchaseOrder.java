/*
 * Copyright (c) 2006 My Company and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 */
package org.eclipse.emf.tutorial.advanced.po;

import java.util.Collection;
import java.util.Date;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.emf.tutorial.advanced.customer.Customer;
import org.eclipse.emf.tutorial.advanced.customer.CustomerPackage;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Purchase Order</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getItemsList <em>Items</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getComment <em>Comment</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getOrderDate <em>Order Date</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getBillTo <em>Bill To</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getShipTo <em>Ship To</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getPreviousOrder <em>Previous Order</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getCustomer <em>Customer</em>}</li>
 * </ul>
 * </p>
 *
 * @model
 * @generated
 */
public class PurchaseOrder extends EObjectImpl {
	/**
	 * The cached value of the '{@link #getItemsList() <em>Items</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getItemsList()
	 * @generated
	 * @ordered
	 */
	protected EList items = null;

	/**
	 * The empty value for the '{@link #getItems() <em>Items</em>}' array accessor.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getItems()
	 * @generated
	 * @ordered
	 */
	protected static final Item[] ITEMS_EEMPTY_ARRAY = new Item [0];

	/**
	 * The default value of the '{@link #getComment() <em>Comment</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComment()
	 * @generated
	 * @ordered
	 */
	protected static final String COMMENT_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getComment() <em>Comment</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getComment()
	 * @generated
	 * @ordered
	 */
	protected String comment = COMMENT_EDEFAULT;

	/**
	 * The default value of the '{@link #getOrderDate() <em>Order Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrderDate()
	 * @generated
	 * @ordered
	 */
	protected static final Date ORDER_DATE_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getOrderDate() <em>Order Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOrderDate()
	 * @generated
	 * @ordered
	 */
	protected Date orderDate = ORDER_DATE_EDEFAULT;

	/**
	 * The cached value of the '{@link #getBillTo() <em>Bill To</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBillTo()
	 * @generated
	 * @ordered
	 */
	protected Address billTo = null;

	/**
	 * The empty value for the '{@link #getBillTo() <em>Bill To</em>}' array accessor.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getBillTo()
	 * @generated
	 * @ordered
	 */
	protected static final Address[] BILL_TO_EEMPTY_ARRAY = new Address [0];

	/**
	 * The cached value of the '{@link #getShipTo() <em>Ship To</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShipTo()
	 * @generated
	 * @ordered
	 */
	protected Address shipTo = null;

	/**
	 * The empty value for the '{@link #getShipTo() <em>Ship To</em>}' array accessor.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getShipTo()
	 * @generated
	 * @ordered
	 */
	protected static final Address[] SHIP_TO_EEMPTY_ARRAY = new Address [0];

	/**
	 * The cached value of the '{@link #getPreviousOrder() <em>Previous Order</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreviousOrder()
	 * @generated
	 * @ordered
	 */
	protected PurchaseOrder previousOrder = null;

	/**
	 * The empty value for the '{@link #getPreviousOrder() <em>Previous Order</em>}' array accessor.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreviousOrder()
	 * @generated
	 * @ordered
	 */
	protected static final PurchaseOrder[] PREVIOUS_ORDER_EEMPTY_ARRAY = new PurchaseOrder [0];

	/**
	 * The cached value of the '{@link #getCustomer() <em>Customer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomer()
	 * @generated
	 * @ordered
	 */
	protected Customer customer = null;

	/**
	 * The empty value for the '{@link #getCustomer() <em>Customer</em>}' array accessor.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getCustomer()
	 * @generated
	 * @ordered
	 */
	protected static final Customer[] CUSTOMER_EEMPTY_ARRAY = new Customer [0];

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected PurchaseOrder() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return POPackage.Literals.PURCHASE_ORDER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Item[] getItems() {
		if (items == null || items.isEmpty()) return ITEMS_EEMPTY_ARRAY;
		BasicEList list = (BasicEList)items;
		list.shrink();
		return (Item[])list.data();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Item getItems(int index) {
		return (Item)getItemsList().get(index);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getItemsLength() {
		return items == null ? 0 : items.size();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setItems(Item[] newItems) {
		((BasicEList)getItemsList()).setData(newItems.length, newItems);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setItems(int index, Item element) {
		getItemsList().set(index, element);
	}

	/**
	 * Returns the value of the '<em><b>Items</b></em>' containment reference list.
	 * The list contents are of type {@link org.eclipse.emf.tutorial.advanced.po.Item}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Items</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Items</em>' containment reference list.
	 * @model type="org.eclipse.emf.tutorial.advanced.po.Item" containment="true"
	 * @generated
	 */
	public EList getItemsList() {
		if (items == null) {
			items = new EObjectContainmentEList(Item.class, this, POPackage.PURCHASE_ORDER__ITEMS);
		}
		return items;
	}


	/**
	 * Adds the specified {@link org.eclipse.emf.tutorial.advanced.po.Item} at the specified index in the '<em><b>Items</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param index The index at which to add the {@link org.eclipse.emf.tutorial.advanced.po.Item}.
	 * @param value The {@link org.eclipse.emf.tutorial.advanced.po.Item} to be added.
	 * @see #getItemsList()
	 * @generated
	 */
	public void addItems(int index, Item value) {
		getItemsList().add(index, value);
	}

	/**
	 * Removes the specified {@link org.eclipse.emf.tutorial.advanced.po.Item} from the '<em><b>Items</b></em>' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value The {@link org.eclipse.emf.tutorial.advanced.po.Item} to be removed.
	 * @return Whether the {@link org.eclipse.emf.tutorial.advanced.po.Item} was successfully removed.
	 * @see #getItemsList()
	 * @generated
	 */
	public boolean removeItems(Item value) {
		return getItemsList().remove(value);
	}

	/**
	 * Returns the value of the '<em><b>Comment</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Comment</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Comment</em>' attribute.
	 * @see #setComment(String)
	 * @model
	 * @generated
	 */
	public String getComment() {
		return comment;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getComment <em>Comment</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Comment</em>' attribute.
	 * @see #getComment()
	 * @generated
	 */
	public void setComment(String newComment) {
		String oldComment = comment;
		comment = newComment;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.PURCHASE_ORDER__COMMENT, oldComment, comment));
	}


	/**
	 * Returns the value of the '<em><b>Order Date</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Order Date</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Order Date</em>' attribute.
	 * @see #setOrderDate(Date)
	 * @model dataType="org.eclipse.emf.tutorial.advanced.datatype.Date"
	 * @generated
	 */
	public Date getOrderDate() {
		return orderDate;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getOrderDate <em>Order Date</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Order Date</em>' attribute.
	 * @see #getOrderDate()
	 * @generated
	 */
	public void setOrderDate(Date newOrderDate) {
		Date oldOrderDate = orderDate;
		orderDate = newOrderDate;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.PURCHASE_ORDER__ORDER_DATE, oldOrderDate, orderDate));
	}


	/**
	 * Returns the value of the '<em><b>Bill To</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Bill To</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Bill To</em>' containment reference.
	 * @see #setBillTo(Address)
	 * @model containment="true" required="true"
	 * @generated
	 */
	public Address getBillTo() {
		return billTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetBillTo(Address newBillTo, NotificationChain msgs) {
		Address oldBillTo = billTo;
		billTo = newBillTo;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, POPackage.PURCHASE_ORDER__BILL_TO, oldBillTo, newBillTo);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getBillTo <em>Bill To</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Bill To</em>' containment reference.
	 * @see #getBillTo()
	 * @generated
	 */
	public void setBillTo(Address newBillTo) {
		if (newBillTo != billTo) {
			NotificationChain msgs = null;
			if (billTo != null)
				msgs = ((InternalEObject)billTo).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - POPackage.PURCHASE_ORDER__BILL_TO, null, msgs);
			if (newBillTo != null)
				msgs = ((InternalEObject)newBillTo).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - POPackage.PURCHASE_ORDER__BILL_TO, null, msgs);
			msgs = basicSetBillTo(newBillTo, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.PURCHASE_ORDER__BILL_TO, newBillTo, newBillTo));
	}


	/**
	 * Returns the value of the '<em><b>Ship To</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Ship To</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Ship To</em>' containment reference.
	 * @see #setShipTo(Address)
	 * @model containment="true"
	 * @generated
	 */
	public Address getShipTo() {
		return shipTo;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetShipTo(Address newShipTo, NotificationChain msgs) {
		Address oldShipTo = shipTo;
		shipTo = newShipTo;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, POPackage.PURCHASE_ORDER__SHIP_TO, oldShipTo, newShipTo);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getShipTo <em>Ship To</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Ship To</em>' containment reference.
	 * @see #getShipTo()
	 * @generated
	 */
	public void setShipTo(Address newShipTo) {
		if (newShipTo != shipTo) {
			NotificationChain msgs = null;
			if (shipTo != null)
				msgs = ((InternalEObject)shipTo).eInverseRemove(this, EOPPOSITE_FEATURE_BASE - POPackage.PURCHASE_ORDER__SHIP_TO, null, msgs);
			if (newShipTo != null)
				msgs = ((InternalEObject)newShipTo).eInverseAdd(this, EOPPOSITE_FEATURE_BASE - POPackage.PURCHASE_ORDER__SHIP_TO, null, msgs);
			msgs = basicSetShipTo(newShipTo, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.PURCHASE_ORDER__SHIP_TO, newShipTo, newShipTo));
	}


	/**
	 * Returns the value of the '<em><b>Previous Order</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Previous Order</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Previous Order</em>' reference.
	 * @see #setPreviousOrder(PurchaseOrder)
	 * @model
	 * @generated
	 */
	public PurchaseOrder getPreviousOrder() {
		if (previousOrder != null && previousOrder.eIsProxy()) {
			InternalEObject oldPreviousOrder = (InternalEObject)previousOrder;
			previousOrder = (PurchaseOrder)eResolveProxy(oldPreviousOrder);
			if (previousOrder != oldPreviousOrder) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, POPackage.PURCHASE_ORDER__PREVIOUS_ORDER, oldPreviousOrder, previousOrder));
			}
		}
		return previousOrder;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PurchaseOrder basicGetPreviousOrder() {
		return previousOrder;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getPreviousOrder <em>Previous Order</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Previous Order</em>' reference.
	 * @see #getPreviousOrder()
	 * @generated
	 */
	public void setPreviousOrder(PurchaseOrder newPreviousOrder) {
		PurchaseOrder oldPreviousOrder = previousOrder;
		previousOrder = newPreviousOrder;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.PURCHASE_ORDER__PREVIOUS_ORDER, oldPreviousOrder, previousOrder));
	}


	/**
	 * Returns the value of the '<em><b>Customer</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPurchaseOrdersList <em>Purchase Orders</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Customer</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Customer</em>' reference.
	 * @see #setCustomer(Customer)
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer#getPurchaseOrdersList
	 * @model opposite="purchaseOrders" required="true"
	 * @generated
	 */
	public Customer getCustomer() {
		if (customer != null && customer.eIsProxy()) {
			InternalEObject oldCustomer = (InternalEObject)customer;
			customer = (Customer)eResolveProxy(oldCustomer);
			if (customer != oldCustomer) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, POPackage.PURCHASE_ORDER__CUSTOMER, oldCustomer, customer));
			}
		}
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Customer basicGetCustomer() {
		return customer;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetCustomer(Customer newCustomer, NotificationChain msgs) {
		Customer oldCustomer = customer;
		customer = newCustomer;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, POPackage.PURCHASE_ORDER__CUSTOMER, oldCustomer, newCustomer);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getCustomer <em>Customer</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Customer</em>' reference.
	 * @see #getCustomer()
	 * @generated
	 */
	public void setCustomer(Customer newCustomer) {
		if (newCustomer != customer) {
			NotificationChain msgs = null;
			if (customer != null)
				msgs = ((InternalEObject)customer).eInverseRemove(this, CustomerPackage.CUSTOMER__PURCHASE_ORDERS, Customer.class, msgs);
			if (newCustomer != null)
				msgs = ((InternalEObject)newCustomer).eInverseAdd(this, CustomerPackage.CUSTOMER__PURCHASE_ORDERS, Customer.class, msgs);
			msgs = basicSetCustomer(newCustomer, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, POPackage.PURCHASE_ORDER__CUSTOMER, newCustomer, newCustomer));
	}


	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case POPackage.PURCHASE_ORDER__CUSTOMER:
				if (customer != null)
					msgs = ((InternalEObject)customer).eInverseRemove(this, CustomerPackage.CUSTOMER__PURCHASE_ORDERS, Customer.class, msgs);
				return basicSetCustomer((Customer)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case POPackage.PURCHASE_ORDER__ITEMS:
				return ((InternalEList)getItemsList()).basicRemove(otherEnd, msgs);
			case POPackage.PURCHASE_ORDER__BILL_TO:
				return basicSetBillTo(null, msgs);
			case POPackage.PURCHASE_ORDER__SHIP_TO:
				return basicSetShipTo(null, msgs);
			case POPackage.PURCHASE_ORDER__CUSTOMER:
				return basicSetCustomer(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case POPackage.PURCHASE_ORDER__ITEMS:
				return getItemsList();
			case POPackage.PURCHASE_ORDER__COMMENT:
				return getComment();
			case POPackage.PURCHASE_ORDER__ORDER_DATE:
				return getOrderDate();
			case POPackage.PURCHASE_ORDER__BILL_TO:
				return getBillTo();
			case POPackage.PURCHASE_ORDER__SHIP_TO:
				return getShipTo();
			case POPackage.PURCHASE_ORDER__PREVIOUS_ORDER:
				if (resolve) return getPreviousOrder();
				return basicGetPreviousOrder();
			case POPackage.PURCHASE_ORDER__CUSTOMER:
				if (resolve) return getCustomer();
				return basicGetCustomer();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case POPackage.PURCHASE_ORDER__ITEMS:
				getItemsList().clear();
				getItemsList().addAll((Collection)newValue);
				return;
			case POPackage.PURCHASE_ORDER__COMMENT:
				setComment((String)newValue);
				return;
			case POPackage.PURCHASE_ORDER__ORDER_DATE:
				setOrderDate((Date)newValue);
				return;
			case POPackage.PURCHASE_ORDER__BILL_TO:
				setBillTo((Address)newValue);
				return;
			case POPackage.PURCHASE_ORDER__SHIP_TO:
				setShipTo((Address)newValue);
				return;
			case POPackage.PURCHASE_ORDER__PREVIOUS_ORDER:
				setPreviousOrder((PurchaseOrder)newValue);
				return;
			case POPackage.PURCHASE_ORDER__CUSTOMER:
				setCustomer((Customer)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case POPackage.PURCHASE_ORDER__ITEMS:
				getItemsList().clear();
				return;
			case POPackage.PURCHASE_ORDER__COMMENT:
				setComment(COMMENT_EDEFAULT);
				return;
			case POPackage.PURCHASE_ORDER__ORDER_DATE:
				setOrderDate(ORDER_DATE_EDEFAULT);
				return;
			case POPackage.PURCHASE_ORDER__BILL_TO:
				setBillTo((Address)null);
				return;
			case POPackage.PURCHASE_ORDER__SHIP_TO:
				setShipTo((Address)null);
				return;
			case POPackage.PURCHASE_ORDER__PREVIOUS_ORDER:
				setPreviousOrder((PurchaseOrder)null);
				return;
			case POPackage.PURCHASE_ORDER__CUSTOMER:
				setCustomer((Customer)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case POPackage.PURCHASE_ORDER__ITEMS:
				return items != null && !items.isEmpty();
			case POPackage.PURCHASE_ORDER__COMMENT:
				return COMMENT_EDEFAULT == null ? comment != null : !COMMENT_EDEFAULT.equals(comment);
			case POPackage.PURCHASE_ORDER__ORDER_DATE:
				return ORDER_DATE_EDEFAULT == null ? orderDate != null : !ORDER_DATE_EDEFAULT.equals(orderDate);
			case POPackage.PURCHASE_ORDER__BILL_TO:
				return billTo != null;
			case POPackage.PURCHASE_ORDER__SHIP_TO:
				return shipTo != null;
			case POPackage.PURCHASE_ORDER__PREVIOUS_ORDER:
				return previousOrder != null;
			case POPackage.PURCHASE_ORDER__CUSTOMER:
				return customer != null;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (comment: ");
		result.append(comment);
		result.append(", orderDate: ");
		result.append(orderDate);
		result.append(')');
		return result.toString();
	}

} // PurchaseOrder