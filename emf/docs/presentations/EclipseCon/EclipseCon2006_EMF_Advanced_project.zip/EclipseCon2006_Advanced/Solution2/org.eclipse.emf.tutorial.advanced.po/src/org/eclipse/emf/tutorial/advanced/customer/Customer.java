/*
 * Copyright (c) 2006 My Company and others.
 * All rights reserved.   This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 */
package org.eclipse.emf.tutorial.advanced.customer;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.BasicEList;
import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.emf.tutorial.advanced.po.POPackage;
import org.eclipse.emf.tutorial.advanced.po.PurchaseOrder;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Customer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPurchaseOrdersList <em>Purchase Orders</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getId <em>Id</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#isVip <em>Vip</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPreferredPaymentMethod <em>Preferred Payment Method</em>}</li>
 * </ul>
 * </p>
 *
 * @model
 * @generated
 */
public class Customer extends Person {
	/**
	 * The cached value of the '{@link #getPurchaseOrdersList() <em>Purchase Orders</em>}' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPurchaseOrdersList()
	 * @generated
	 * @ordered
	 */
	protected EList purchaseOrders = null;

	/**
	 * The empty value for the '{@link #getPurchaseOrders() <em>Purchase Orders</em>}' array accessor.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPurchaseOrders()
	 * @generated
	 * @ordered
	 */
	protected static final PurchaseOrder[] PURCHASE_ORDERS_EEMPTY_ARRAY = new PurchaseOrder [0];

	/**
	 * The default value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected static final String ID_EDEFAULT = null;

	/**
	 * The cached value of the '{@link #getId() <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getId()
	 * @generated
	 * @ordered
	 */
	protected String id = ID_EDEFAULT;

	/**
	 * The default value of the '{@link #isVip() <em>Vip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isVip()
	 * @generated
	 * @ordered
	 */
	protected static final boolean VIP_EDEFAULT = false;

	/**
	 * The cached value of the '{@link #isVip() <em>Vip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #isVip()
	 * @generated
	 * @ordered
	 */
	protected boolean vip = VIP_EDEFAULT;

	/**
	 * The default value of the '{@link #getPreferredPaymentMethod() <em>Preferred Payment Method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreferredPaymentMethod()
	 * @generated
	 * @ordered
	 */
	protected static final PaymentMethod PREFERRED_PAYMENT_METHOD_EDEFAULT = PaymentMethod.CREDIT_CARD_LITERAL;

	/**
	 * The cached value of the '{@link #getPreferredPaymentMethod() <em>Preferred Payment Method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPreferredPaymentMethod()
	 * @generated
	 * @ordered
	 */
	protected PaymentMethod preferredPaymentMethod = PREFERRED_PAYMENT_METHOD_EDEFAULT;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Customer() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EClass eStaticClass() {
		return CustomerPackage.Literals.CUSTOMER;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PurchaseOrder[] getPurchaseOrders() {
		if (purchaseOrders == null || purchaseOrders.isEmpty()) return PURCHASE_ORDERS_EEMPTY_ARRAY;
		BasicEList list = (BasicEList)purchaseOrders;
		list.shrink();
		return (PurchaseOrder[])list.data();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PurchaseOrder getPurchaseOrders(int index) {
		return (PurchaseOrder)getPurchaseOrdersList().get(index);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public int getPurchaseOrdersLength() {
		return purchaseOrders == null ? 0 : purchaseOrders.size();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPurchaseOrders(PurchaseOrder[] newPurchaseOrders) {
		((BasicEList)getPurchaseOrdersList()).setData(newPurchaseOrders.length, newPurchaseOrders);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setPurchaseOrders(int index, PurchaseOrder element) {
		getPurchaseOrdersList().set(index, element);
	}

	/**
	 * Returns the value of the '<em><b>Purchase Orders</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder}.
	 * It is bidirectional and its opposite is '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Purchase Orders</em>' reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Purchase Orders</em>' reference list.
	 * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getCustomer
	 * @model type="org.eclipse.emf.tutorial.advanced.po.PurchaseOrder" opposite="customer" required="true"
	 * @generated
	 */
	public EList getPurchaseOrdersList() {
		if (purchaseOrders == null) {
			purchaseOrders = new EObjectWithInverseResolvingEList(PurchaseOrder.class, this, CustomerPackage.CUSTOMER__PURCHASE_ORDERS, POPackage.PURCHASE_ORDER__CUSTOMER);
		}
		return purchaseOrders;
	}


	/**
	 * Adds the specified {@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder} at the specified index in the '<em><b>Purchase Orders</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param index The index at which to add the {@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder}.
	 * @param value The {@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder} to be added.
	 * @see #getPurchaseOrdersList()
	 * @generated
	 */
	public void addPurchaseOrders(int index, PurchaseOrder value) {
		getPurchaseOrdersList().add(index, value);
	}

	/**
	 * Removes the specified {@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder} from the '<em><b>Purchase Orders</b></em>' reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value The {@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder} to be removed.
	 * @return Whether the {@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder} was successfully removed.
	 * @see #getPurchaseOrdersList()
	 * @generated
	 */
	public boolean removePurchaseOrders(PurchaseOrder value) {
		return getPurchaseOrdersList().remove(value);
	}

	/**
	 * Returns the value of the '<em><b>Id</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Id</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Id</em>' attribute.
	 * @see #setId(String)
	 * @model
	 * @generated
	 */
	public String getId() {
		return id;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getId <em>Id</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Id</em>' attribute.
	 * @see #getId()
	 * @generated
	 */
	public void setId(String newId) {
		String oldId = id;
		id = newId;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CustomerPackage.CUSTOMER__ID, oldId, id));
	}


	/**
	 * Returns the value of the '<em><b>Vip</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Vip</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Vip</em>' attribute.
	 * @see #setVip(boolean)
	 * @model
	 * @generated
	 */
	public boolean isVip() {
		return vip;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#isVip <em>Vip</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Vip</em>' attribute.
	 * @see #isVip()
	 * @generated
	 */
	public void setVip(boolean newVip) {
		boolean oldVip = vip;
		vip = newVip;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CustomerPackage.CUSTOMER__VIP, oldVip, vip));
	}


	/**
	 * Returns the value of the '<em><b>Preferred Payment Method</b></em>' attribute.
	 * The literals are from the enumeration {@link org.eclipse.emf.tutorial.advanced.customer.PaymentMethod}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Preferred Payment Method</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Preferred Payment Method</em>' attribute.
	 * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
	 * @see #setPreferredPaymentMethod(PaymentMethod)
	 * @model
	 * @generated
	 */
	public PaymentMethod getPreferredPaymentMethod() {
		return preferredPaymentMethod;
	}

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPreferredPaymentMethod <em>Preferred Payment Method</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Preferred Payment Method</em>' attribute.
	 * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
	 * @see #getPreferredPaymentMethod()
	 * @generated
	 */
	public void setPreferredPaymentMethod(PaymentMethod newPreferredPaymentMethod) {
		PaymentMethod oldPreferredPaymentMethod = preferredPaymentMethod;
		preferredPaymentMethod = newPreferredPaymentMethod == null ? PREFERRED_PAYMENT_METHOD_EDEFAULT : newPreferredPaymentMethod;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD, oldPreferredPaymentMethod, preferredPaymentMethod));
	}


	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
				return ((InternalEList)getPurchaseOrdersList()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
				return ((InternalEList)getPurchaseOrdersList()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
				return getPurchaseOrdersList();
			case CustomerPackage.CUSTOMER__ID:
				return getId();
			case CustomerPackage.CUSTOMER__VIP:
				return isVip() ? Boolean.TRUE : Boolean.FALSE;
			case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
				return getPreferredPaymentMethod();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
				getPurchaseOrdersList().clear();
				getPurchaseOrdersList().addAll((Collection)newValue);
				return;
			case CustomerPackage.CUSTOMER__ID:
				setId((String)newValue);
				return;
			case CustomerPackage.CUSTOMER__VIP:
				setVip(((Boolean)newValue).booleanValue());
				return;
			case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
				setPreferredPaymentMethod((PaymentMethod)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void eUnset(int featureID) {
		switch (featureID) {
			case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
				getPurchaseOrdersList().clear();
				return;
			case CustomerPackage.CUSTOMER__ID:
				setId(ID_EDEFAULT);
				return;
			case CustomerPackage.CUSTOMER__VIP:
				setVip(VIP_EDEFAULT);
				return;
			case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
				setPreferredPaymentMethod(PREFERRED_PAYMENT_METHOD_EDEFAULT);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
				return purchaseOrders != null && !purchaseOrders.isEmpty();
			case CustomerPackage.CUSTOMER__ID:
				return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
			case CustomerPackage.CUSTOMER__VIP:
				return vip != VIP_EDEFAULT;
			case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
				return preferredPaymentMethod != PREFERRED_PAYMENT_METHOD_EDEFAULT;
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public String toString() {
		if (eIsProxy()) return super.toString();

		StringBuffer result = new StringBuffer(super.toString());
		result.append(" (id: ");
		result.append(id);
		result.append(", vip: ");
		result.append(vip);
		result.append(", preferredPaymentMethod: ");
		result.append(preferredPaymentMethod);
		result.append(')');
		return result.toString();
	}

} // Customer