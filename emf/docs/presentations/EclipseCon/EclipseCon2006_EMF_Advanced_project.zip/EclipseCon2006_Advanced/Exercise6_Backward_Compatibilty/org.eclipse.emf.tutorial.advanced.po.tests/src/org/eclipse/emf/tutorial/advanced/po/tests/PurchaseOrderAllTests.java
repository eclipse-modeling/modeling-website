/**
 * <copyright>
 * </copyright>
 *
 * $Id: PurchaseOrderAllTests.java,v 1.1 2006/03/28 22:06:01 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.po.tests;

import junit.framework.Test;
import junit.framework.TestSuite;

import junit.textui.TestRunner;

import org.eclipse.emf.tutorial.advanced.customer.tests.CustomerTests;

/**
 * <!-- begin-user-doc -->
 * A test suite for the '<em><b>PurchaseOrder</b></em>' model.
 * <!-- end-user-doc -->
 * @generated
 */
public class PurchaseOrderAllTests extends TestSuite {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static void main(String[] args) {
		TestRunner.run(suite());
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public static Test suite() {
		TestSuite suite = new PurchaseOrderAllTests("PurchaseOrder Tests");
		suite.addTest(CustomerTests.suite());
		return suite;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PurchaseOrderAllTests(String name) {
		super(name);
	}

} //PurchaseOrderAllTests
