/**
 * <copyright>
 * </copyright>
 *
 * $Id: PersonTest.java,v 1.1 2006/03/28 22:06:00 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.customer.tests;

import junit.framework.TestCase;

import org.eclipse.emf.tutorial.advanced.customer.Person;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Person</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following operations are tested:
 * <ul>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Person#computeAge() <em>Compute Age</em>}</li>
 * </ul>
 * </p>
 * @generated
 */
public abstract class PersonTest extends TestCase {
	/**
	 * The fixture for this Person test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Person fixture = null;

	/**
	 * Constructs a new Person test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public PersonTest(String name) {
		super(name);
	}

	/**
	 * Sets the fixture for this Person test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected void setFixture(Person fixture) {
		this.fixture = fixture;
	}

	/**
	 * Returns the fixture for this Person test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	private Person getFixture() {
		return fixture;
	}

	/**
	 * Tests the '{@link org.eclipse.emf.tutorial.advanced.customer.Person#computeAge() <em>Compute Age</em>}' operation.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see org.eclipse.emf.tutorial.advanced.customer.Person#computeAge()
	 * @generated
	 */
	public void testComputeAge() {
		// TODO: implement this operation test method
		// Ensure that you remove @generated or mark it @generated NOT
		fail();
	}

} //PersonTest
