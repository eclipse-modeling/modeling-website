/**
 * <copyright>
 * </copyright>
 *
 * $Id: Customer.java,v 1.1 2006/03/28 22:06:00 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.customer;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Customer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPurchaseOrders <em>Purchase Orders</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getIdentifier <em>Identifier</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#isVIP <em>VIP</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPreferredPaymentMethod <em>Preferred Payment Method</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer()
 * @model
 * @generated
 */
public interface Customer extends Person {
	/**
	 * Returns the value of the '<em><b>Purchase Orders</b></em>' reference list.
	 * The list contents are of type {@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder}.
	 * It is bidirectional and its opposite is '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getCustomer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Purchase Orders</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>Purchase Orders</em>' reference list.
	 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer_PurchaseOrders()
	 * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getCustomer
	 * @model type="org.eclipse.emf.tutorial.advanced.po.PurchaseOrder" opposite="customer" required="true"
	 * @generated
	 */
  EList getPurchaseOrders();

	/**
	 * Returns the value of the '<em><b>Identifier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Identifier</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Identifier</em>' attribute.
	 * @see #setIdentifier(String)
	 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer_Identifier()
	 * @model
	 * @generated
	 */
	String getIdentifier();

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getIdentifier <em>Identifier</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Identifier</em>' attribute.
	 * @see #getIdentifier()
	 * @generated
	 */
	void setIdentifier(String value);

	/**
	 * Returns the value of the '<em><b>VIP</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>VIP</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>VIP</em>' attribute.
	 * @see #setVIP(boolean)
	 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer_VIP()
	 * @model
	 * @generated
	 */
	boolean isVIP();

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#isVIP <em>VIP</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>VIP</em>' attribute.
	 * @see #isVIP()
	 * @generated
	 */
	void setVIP(boolean value);

	/**
	 * Returns the value of the '<em><b>Preferred Payment Method</b></em>' attribute.
	 * The literals are from the enumeration {@link org.eclipse.emf.tutorial.advanced.customer.PaymentMethod}.
	 * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Preferred Payment Method</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
	 * @return the value of the '<em>Preferred Payment Method</em>' attribute.
	 * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
	 * @see #setPreferredPaymentMethod(PaymentMethod)
	 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer_PreferredPaymentMethod()
	 * @model
	 * @generated
	 */
  PaymentMethod getPreferredPaymentMethod();

	/**
	 * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPreferredPaymentMethod <em>Preferred Payment Method</em>}' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Preferred Payment Method</em>' attribute.
	 * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
	 * @see #getPreferredPaymentMethod()
	 * @generated
	 */
  void setPreferredPaymentMethod(PaymentMethod value);

} // Customer