/**
 * <copyright>
 * </copyright>
 *
 * $Id: CustomerResourceImpl.java,v 1.1 2006/03/28 22:06:01 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.customer.util;

import org.eclipse.emf.common.util.URI;

import org.eclipse.emf.ecore.xmi.impl.XMIResourceImpl;

/**
 * <!-- begin-user-doc -->
 * The <b>Resource </b> associated with the package.
 * <!-- end-user-doc -->
 * @see org.eclipse.emf.tutorial.advanced.customer.util.CustomerResourceFactoryImpl
 * @generated
 */
public class CustomerResourceImpl extends XMIResourceImpl
{
	/**
	 * Creates an instance of the resource.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @param uri the URI of the new resource.
	 * @generated
	 */
  public CustomerResourceImpl(URI uri) {
		super(uri);
	}

} //CustomerResourceImpl
