/**
 * <copyright>
 * </copyright>
 *
 * $Id: CustomerPackage.java,v 1.1 2006/03/28 22:06:00 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.customer;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EEnum;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerFactory
 * @model kind="package"
 * @generated
 */
public interface CustomerPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  String eNAME = "customer";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  String eNS_URI = "http://www.eclipse.org/emf/tutorial/advanced/2007/Customer";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  String eNS_PREFIX = "customer";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 */
  CustomerPackage eINSTANCE = org.eclipse.emf.tutorial.advanced.customer.impl.CustomerPackageImpl.init();

	/**
	 * The meta object id for the '{@link org.eclipse.emf.tutorial.advanced.customer.impl.PersonImpl <em>Person</em>}' class.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see org.eclipse.emf.tutorial.advanced.customer.impl.PersonImpl
	 * @see org.eclipse.emf.tutorial.advanced.customer.impl.CustomerPackageImpl#getPerson()
	 * @generated
	 */
  int PERSON = 0;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int PERSON__NAME = 0;

	/**
	 * The feature id for the '<em><b>Birthday</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int PERSON__BIRTHDAY = 1;

	/**
	 * The number of structural features of the '<em>Person</em>' class.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int PERSON_FEATURE_COUNT = 2;

	/**
	 * The meta object id for the '{@link org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl <em>Customer</em>}' class.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl
	 * @see org.eclipse.emf.tutorial.advanced.customer.impl.CustomerPackageImpl#getCustomer()
	 * @generated
	 */
  int CUSTOMER = 1;

	/**
	 * The feature id for the '<em><b>Name</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int CUSTOMER__NAME = PERSON__NAME;

	/**
	 * The feature id for the '<em><b>Birthday</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int CUSTOMER__BIRTHDAY = PERSON__BIRTHDAY;

	/**
	 * The feature id for the '<em><b>Purchase Orders</b></em>' reference list.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int CUSTOMER__PURCHASE_ORDERS = PERSON_FEATURE_COUNT + 0;

	/**
	 * The feature id for the '<em><b>Identifier</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int CUSTOMER__IDENTIFIER = PERSON_FEATURE_COUNT + 1;

	/**
	 * The feature id for the '<em><b>VIP</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int CUSTOMER__VIP = PERSON_FEATURE_COUNT + 2;

	/**
	 * The feature id for the '<em><b>Preferred Payment Method</b></em>' attribute.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int CUSTOMER__PREFERRED_PAYMENT_METHOD = PERSON_FEATURE_COUNT + 3;

	/**
	 * The number of structural features of the '<em>Customer</em>' class.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
  int CUSTOMER_FEATURE_COUNT = PERSON_FEATURE_COUNT + 4;

	/**
	 * The meta object id for the '{@link org.eclipse.emf.tutorial.advanced.customer.PaymentMethod <em>Payment Method</em>}' enum.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
	 * @see org.eclipse.emf.tutorial.advanced.customer.impl.CustomerPackageImpl#getPaymentMethod()
	 * @generated
	 */
  int PAYMENT_METHOD = 2;


	/**
	 * Returns the meta object for class '{@link org.eclipse.emf.tutorial.advanced.customer.Person <em>Person</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Person</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Person
	 * @generated
	 */
  EClass getPerson();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.customer.Person#getName <em>Name</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Name</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Person#getName()
	 * @see #getPerson()
	 * @generated
	 */
  EAttribute getPerson_Name();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.customer.Person#getBirthday <em>Birthday</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Birthday</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Person#getBirthday()
	 * @see #getPerson()
	 * @generated
	 */
  EAttribute getPerson_Birthday();

	/**
	 * Returns the meta object for class '{@link org.eclipse.emf.tutorial.advanced.customer.Customer <em>Customer</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Customer</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer
	 * @generated
	 */
  EClass getCustomer();

	/**
	 * Returns the meta object for the reference list '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPurchaseOrders <em>Purchase Orders</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the reference list '<em>Purchase Orders</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer#getPurchaseOrders()
	 * @see #getCustomer()
	 * @generated
	 */
  EReference getCustomer_PurchaseOrders();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getIdentifier <em>Identifier</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Identifier</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer#getIdentifier()
	 * @see #getCustomer()
	 * @generated
	 */
	EAttribute getCustomer_Identifier();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#isVIP <em>VIP</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>VIP</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer#isVIP()
	 * @see #getCustomer()
	 * @generated
	 */
	EAttribute getCustomer_VIP();

	/**
	 * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPreferredPaymentMethod <em>Preferred Payment Method</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Preferred Payment Method</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.Customer#getPreferredPaymentMethod()
	 * @see #getCustomer()
	 * @generated
	 */
  EAttribute getCustomer_PreferredPaymentMethod();

	/**
	 * Returns the meta object for enum '{@link org.eclipse.emf.tutorial.advanced.customer.PaymentMethod <em>Payment Method</em>}'.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the meta object for enum '<em>Payment Method</em>'.
	 * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
	 * @generated
	 */
  EEnum getPaymentMethod();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
  CustomerFactory getCustomerFactory();

	/**
	 * <!-- begin-user-doc -->
   * Defines literals for the meta objects that represent
   * <ul>
   *   <li>each class,</li>
   *   <li>each feature of each class,</li>
   *   <li>each enum,</li>
   *   <li>and each data type</li>
   * </ul>
   * <!-- end-user-doc -->
	 * @generated
	 */
  interface Literals  {
		/**
		 * The meta object literal for the '{@link org.eclipse.emf.tutorial.advanced.customer.impl.PersonImpl <em>Person</em>}' class.
		 * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
		 * @see org.eclipse.emf.tutorial.advanced.customer.impl.PersonImpl
		 * @see org.eclipse.emf.tutorial.advanced.customer.impl.CustomerPackageImpl#getPerson()
		 * @generated
		 */
    EClass PERSON = eINSTANCE.getPerson();

		/**
		 * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
		 * @generated
		 */
    EAttribute PERSON__NAME = eINSTANCE.getPerson_Name();

		/**
		 * The meta object literal for the '<em><b>Birthday</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
		 * @generated
		 */
    EAttribute PERSON__BIRTHDAY = eINSTANCE.getPerson_Birthday();

		/**
		 * The meta object literal for the '{@link org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl <em>Customer</em>}' class.
		 * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
		 * @see org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl
		 * @see org.eclipse.emf.tutorial.advanced.customer.impl.CustomerPackageImpl#getCustomer()
		 * @generated
		 */
    EClass CUSTOMER = eINSTANCE.getCustomer();

		/**
		 * The meta object literal for the '<em><b>Purchase Orders</b></em>' reference list feature.
		 * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
		 * @generated
		 */
    EReference CUSTOMER__PURCHASE_ORDERS = eINSTANCE.getCustomer_PurchaseOrders();

		/**
		 * The meta object literal for the '<em><b>Identifier</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute CUSTOMER__IDENTIFIER = eINSTANCE.getCustomer_Identifier();

		/**
		 * The meta object literal for the '<em><b>VIP</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
		 * @generated
		 */
    EAttribute CUSTOMER__VIP = eINSTANCE.getCustomer_VIP();

		/**
		 * The meta object literal for the '<em><b>Preferred Payment Method</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
		 * @generated
		 */
    EAttribute CUSTOMER__PREFERRED_PAYMENT_METHOD = eINSTANCE.getCustomer_PreferredPaymentMethod();

		/**
		 * The meta object literal for the '{@link org.eclipse.emf.tutorial.advanced.customer.PaymentMethod <em>Payment Method</em>}' enum.
		 * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
		 * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
		 * @see org.eclipse.emf.tutorial.advanced.customer.impl.CustomerPackageImpl#getPaymentMethod()
		 * @generated
		 */
    EEnum PAYMENT_METHOD = eINSTANCE.getPaymentMethod();

  }

} //CustomerPackage
