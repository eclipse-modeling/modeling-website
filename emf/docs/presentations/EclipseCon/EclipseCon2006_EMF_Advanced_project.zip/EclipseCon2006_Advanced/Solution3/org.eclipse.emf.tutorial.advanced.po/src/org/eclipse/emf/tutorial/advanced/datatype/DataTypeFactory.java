/**
 * <copyright>
 * </copyright>
 *
 * $Id: DataTypeFactory.java,v 1.1 2006/03/28 22:06:00 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.datatype;

import org.eclipse.emf.ecore.EFactory;

/**
 * <!-- begin-user-doc -->
 * The <b>Factory</b> for the model.
 * It provides a create method for each non-abstract class of the model.
 * <!-- end-user-doc -->
 * @see org.eclipse.emf.tutorial.advanced.datatype.DataTypePackage
 * @generated
 */
public interface DataTypeFactory extends EFactory
{
  /**
   * The singleton instance of the factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  DataTypeFactory eINSTANCE = org.eclipse.emf.tutorial.advanced.datatype.impl.DataTypeFactoryImpl.init();

  /**
   * Returns the package supported by this factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the package supported by this factory.
   * @generated
   */
  DataTypePackage getDataTypePackage();

} //DataTypeFactory
