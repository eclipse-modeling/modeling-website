/**
 * <copyright>
 * </copyright>
 *
 * $Id: Person.java,v 1.1 2006/03/28 22:06:01 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.customer;

import java.util.Date;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Person</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Person#getName <em>Name</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Person#getBirthday <em>Birthday</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getPerson()
 * @model abstract="true"
 * @generated
 */
public interface Person extends EObject
{
  /**
   * Returns the value of the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Name</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Name</em>' attribute.
   * @see #setName(String)
   * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getPerson_Name()
   * @model
   * @generated
   */
  String getName();

  /**
   * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Person#getName <em>Name</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Name</em>' attribute.
   * @see #getName()
   * @generated
   */
  void setName(String value);

  /**
   * Returns the value of the '<em><b>Birthday</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Birthday</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Birthday</em>' attribute.
   * @see #setBirthday(Date)
   * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getPerson_Birthday()
   * @model dataType="org.eclipse.emf.tutorial.advanced.datatype.Date"
   * @generated
   */
  Date getBirthday();

  /**
   * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Person#getBirthday <em>Birthday</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Birthday</em>' attribute.
   * @see #getBirthday()
   * @generated
   */
  void setBirthday(Date value);

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @model
   * @generated
   */
  int computeAge();

} // Person