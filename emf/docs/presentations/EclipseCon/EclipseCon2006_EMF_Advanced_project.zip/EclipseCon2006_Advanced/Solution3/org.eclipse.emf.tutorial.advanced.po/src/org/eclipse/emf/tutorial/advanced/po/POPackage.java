/**
 * <copyright>
 * </copyright>
 *
 * $Id: POPackage.java,v 1.1 2006/03/28 22:06:01 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.po;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see org.eclipse.emf.tutorial.advanced.po.POFactory
 * @model kind="package"
 * @generated
 */
public interface POPackage extends EPackage
{
  /**
   * The package name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNAME = "po";

  /**
   * The package namespace URI.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_URI = "http://www.eclipse.org/emf/tutorial/advanced/2006/PurchaseOrder";

  /**
   * The package namespace name.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  String eNS_PREFIX = "po";

  /**
   * The singleton instance of the package.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  POPackage eINSTANCE = org.eclipse.emf.tutorial.advanced.po.impl.POPackageImpl.init();

  /**
   * The meta object id for the '{@link org.eclipse.emf.tutorial.advanced.po.impl.PurchaseOrderImpl <em>Purchase Order</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.tutorial.advanced.po.impl.PurchaseOrderImpl
   * @see org.eclipse.emf.tutorial.advanced.po.impl.POPackageImpl#getPurchaseOrder()
   * @generated
   */
  int PURCHASE_ORDER = 0;

  /**
   * The feature id for the '<em><b>Items</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PURCHASE_ORDER__ITEMS = 0;

  /**
   * The feature id for the '<em><b>Comment</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PURCHASE_ORDER__COMMENT = 1;

  /**
   * The feature id for the '<em><b>Order Date</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PURCHASE_ORDER__ORDER_DATE = 2;

  /**
   * The feature id for the '<em><b>Bill To</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PURCHASE_ORDER__BILL_TO = 3;

  /**
   * The feature id for the '<em><b>Ship To</b></em>' containment reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PURCHASE_ORDER__SHIP_TO = 4;

  /**
   * The feature id for the '<em><b>Previous Order</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PURCHASE_ORDER__PREVIOUS_ORDER = 5;

  /**
   * The feature id for the '<em><b>Customer</b></em>' reference.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PURCHASE_ORDER__CUSTOMER = 6;

  /**
   * The number of structural features of the '<em>Purchase Order</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int PURCHASE_ORDER_FEATURE_COUNT = 7;

  /**
   * The meta object id for the '{@link org.eclipse.emf.tutorial.advanced.po.impl.ItemImpl <em>Item</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.tutorial.advanced.po.impl.ItemImpl
   * @see org.eclipse.emf.tutorial.advanced.po.impl.POPackageImpl#getItem()
   * @generated
   */
  int ITEM = 1;

  /**
   * The feature id for the '<em><b>Sub Items</b></em>' containment reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ITEM__SUB_ITEMS = 0;

  /**
   * The feature id for the '<em><b>Product Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ITEM__PRODUCT_NAME = 1;

  /**
   * The feature id for the '<em><b>Quantity</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ITEM__QUANTITY = 2;

  /**
   * The feature id for the '<em><b>Price</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ITEM__PRICE = 3;

  /**
   * The feature id for the '<em><b>Comment</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ITEM__COMMENT = 4;

  /**
   * The feature id for the '<em><b>Ship Date</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ITEM__SHIP_DATE = 5;

  /**
   * The feature id for the '<em><b>Part Num</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ITEM__PART_NUM = 6;

  /**
   * The number of structural features of the '<em>Item</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ITEM_FEATURE_COUNT = 7;

  /**
   * The meta object id for the '{@link org.eclipse.emf.tutorial.advanced.po.impl.AddressImpl <em>Address</em>}' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see org.eclipse.emf.tutorial.advanced.po.impl.AddressImpl
   * @see org.eclipse.emf.tutorial.advanced.po.impl.POPackageImpl#getAddress()
   * @generated
   */
  int ADDRESS = 2;

  /**
   * The feature id for the '<em><b>Name</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ADDRESS__NAME = 0;

  /**
   * The feature id for the '<em><b>Street</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ADDRESS__STREET = 1;

  /**
   * The feature id for the '<em><b>City</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ADDRESS__CITY = 2;

  /**
   * The feature id for the '<em><b>State</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ADDRESS__STATE = 3;

  /**
   * The feature id for the '<em><b>Zip</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ADDRESS__ZIP = 4;

  /**
   * The feature id for the '<em><b>Country</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ADDRESS__COUNTRY = 5;

  /**
   * The number of structural features of the '<em>Address</em>' class.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   * @ordered
   */
  int ADDRESS_FEATURE_COUNT = 6;


  /**
   * Returns the meta object for class '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder <em>Purchase Order</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Purchase Order</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder
   * @generated
   */
  EClass getPurchaseOrder();

  /**
   * Returns the meta object for the containment reference list '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getItems <em>Items</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Items</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getItems()
   * @see #getPurchaseOrder()
   * @generated
   */
  EReference getPurchaseOrder_Items();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getComment <em>Comment</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Comment</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getComment()
   * @see #getPurchaseOrder()
   * @generated
   */
  EAttribute getPurchaseOrder_Comment();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getOrderDate <em>Order Date</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Order Date</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getOrderDate()
   * @see #getPurchaseOrder()
   * @generated
   */
  EAttribute getPurchaseOrder_OrderDate();

  /**
   * Returns the meta object for the containment reference '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getBillTo <em>Bill To</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Bill To</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getBillTo()
   * @see #getPurchaseOrder()
   * @generated
   */
  EReference getPurchaseOrder_BillTo();

  /**
   * Returns the meta object for the containment reference '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getShipTo <em>Ship To</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference '<em>Ship To</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getShipTo()
   * @see #getPurchaseOrder()
   * @generated
   */
  EReference getPurchaseOrder_ShipTo();

  /**
   * Returns the meta object for the reference '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getPreviousOrder <em>Previous Order</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Previous Order</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getPreviousOrder()
   * @see #getPurchaseOrder()
   * @generated
   */
  EReference getPurchaseOrder_PreviousOrder();

  /**
   * Returns the meta object for the reference '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getCustomer <em>Customer</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the reference '<em>Customer</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getCustomer()
   * @see #getPurchaseOrder()
   * @generated
   */
  EReference getPurchaseOrder_Customer();

  /**
   * Returns the meta object for class '{@link org.eclipse.emf.tutorial.advanced.po.Item <em>Item</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Item</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Item
   * @generated
   */
  EClass getItem();

  /**
   * Returns the meta object for the containment reference list '{@link org.eclipse.emf.tutorial.advanced.po.Item#getSubItems <em>Sub Items</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the containment reference list '<em>Sub Items</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Item#getSubItems()
   * @see #getItem()
   * @generated
   */
  EReference getItem_SubItems();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Item#getProductName <em>Product Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Product Name</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Item#getProductName()
   * @see #getItem()
   * @generated
   */
  EAttribute getItem_ProductName();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Item#getQuantity <em>Quantity</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Quantity</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Item#getQuantity()
   * @see #getItem()
   * @generated
   */
  EAttribute getItem_Quantity();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Item#getPrice <em>Price</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Price</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Item#getPrice()
   * @see #getItem()
   * @generated
   */
  EAttribute getItem_Price();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Item#getComment <em>Comment</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Comment</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Item#getComment()
   * @see #getItem()
   * @generated
   */
  EAttribute getItem_Comment();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Item#getShipDate <em>Ship Date</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Ship Date</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Item#getShipDate()
   * @see #getItem()
   * @generated
   */
  EAttribute getItem_ShipDate();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Item#getPartNum <em>Part Num</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Part Num</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Item#getPartNum()
   * @see #getItem()
   * @generated
   */
  EAttribute getItem_PartNum();

  /**
   * Returns the meta object for class '{@link org.eclipse.emf.tutorial.advanced.po.Address <em>Address</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for class '<em>Address</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Address
   * @generated
   */
  EClass getAddress();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Address#getName <em>Name</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Name</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Address#getName()
   * @see #getAddress()
   * @generated
   */
  EAttribute getAddress_Name();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Address#getStreet <em>Street</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Street</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Address#getStreet()
   * @see #getAddress()
   * @generated
   */
  EAttribute getAddress_Street();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Address#getCity <em>City</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>City</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Address#getCity()
   * @see #getAddress()
   * @generated
   */
  EAttribute getAddress_City();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Address#getState <em>State</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>State</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Address#getState()
   * @see #getAddress()
   * @generated
   */
  EAttribute getAddress_State();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Address#getZip <em>Zip</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Zip</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Address#getZip()
   * @see #getAddress()
   * @generated
   */
  EAttribute getAddress_Zip();

  /**
   * Returns the meta object for the attribute '{@link org.eclipse.emf.tutorial.advanced.po.Address#getCountry <em>Country</em>}'.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the meta object for the attribute '<em>Country</em>'.
   * @see org.eclipse.emf.tutorial.advanced.po.Address#getCountry()
   * @see #getAddress()
   * @generated
   */
  EAttribute getAddress_Country();

  /**
   * Returns the factory that creates the instances of the model.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @return the factory that creates the instances of the model.
   * @generated
   */
  POFactory getPOFactory();

  /**
   * <!-- begin-user-doc -->
   * Defines literals for the meta objects that represent
   * <ul>
   *   <li>each class,</li>
   *   <li>each feature of each class,</li>
   *   <li>each enum,</li>
   *   <li>and each data type</li>
   * </ul>
   * <!-- end-user-doc -->
   * @generated
   */
  interface Literals
  {
    /**
     * The meta object literal for the '{@link org.eclipse.emf.tutorial.advanced.po.impl.PurchaseOrderImpl <em>Purchase Order</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.eclipse.emf.tutorial.advanced.po.impl.PurchaseOrderImpl
     * @see org.eclipse.emf.tutorial.advanced.po.impl.POPackageImpl#getPurchaseOrder()
     * @generated
     */
    EClass PURCHASE_ORDER = eINSTANCE.getPurchaseOrder();

    /**
     * The meta object literal for the '<em><b>Items</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference PURCHASE_ORDER__ITEMS = eINSTANCE.getPurchaseOrder_Items();

    /**
     * The meta object literal for the '<em><b>Comment</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute PURCHASE_ORDER__COMMENT = eINSTANCE.getPurchaseOrder_Comment();

    /**
     * The meta object literal for the '<em><b>Order Date</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute PURCHASE_ORDER__ORDER_DATE = eINSTANCE.getPurchaseOrder_OrderDate();

    /**
     * The meta object literal for the '<em><b>Bill To</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference PURCHASE_ORDER__BILL_TO = eINSTANCE.getPurchaseOrder_BillTo();

    /**
     * The meta object literal for the '<em><b>Ship To</b></em>' containment reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference PURCHASE_ORDER__SHIP_TO = eINSTANCE.getPurchaseOrder_ShipTo();

    /**
     * The meta object literal for the '<em><b>Previous Order</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference PURCHASE_ORDER__PREVIOUS_ORDER = eINSTANCE.getPurchaseOrder_PreviousOrder();

    /**
     * The meta object literal for the '<em><b>Customer</b></em>' reference feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference PURCHASE_ORDER__CUSTOMER = eINSTANCE.getPurchaseOrder_Customer();

    /**
     * The meta object literal for the '{@link org.eclipse.emf.tutorial.advanced.po.impl.ItemImpl <em>Item</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.eclipse.emf.tutorial.advanced.po.impl.ItemImpl
     * @see org.eclipse.emf.tutorial.advanced.po.impl.POPackageImpl#getItem()
     * @generated
     */
    EClass ITEM = eINSTANCE.getItem();

    /**
     * The meta object literal for the '<em><b>Sub Items</b></em>' containment reference list feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EReference ITEM__SUB_ITEMS = eINSTANCE.getItem_SubItems();

    /**
     * The meta object literal for the '<em><b>Product Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ITEM__PRODUCT_NAME = eINSTANCE.getItem_ProductName();

    /**
     * The meta object literal for the '<em><b>Quantity</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ITEM__QUANTITY = eINSTANCE.getItem_Quantity();

    /**
     * The meta object literal for the '<em><b>Price</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ITEM__PRICE = eINSTANCE.getItem_Price();

    /**
     * The meta object literal for the '<em><b>Comment</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ITEM__COMMENT = eINSTANCE.getItem_Comment();

    /**
     * The meta object literal for the '<em><b>Ship Date</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ITEM__SHIP_DATE = eINSTANCE.getItem_ShipDate();

    /**
     * The meta object literal for the '<em><b>Part Num</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ITEM__PART_NUM = eINSTANCE.getItem_PartNum();

    /**
     * The meta object literal for the '{@link org.eclipse.emf.tutorial.advanced.po.impl.AddressImpl <em>Address</em>}' class.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @see org.eclipse.emf.tutorial.advanced.po.impl.AddressImpl
     * @see org.eclipse.emf.tutorial.advanced.po.impl.POPackageImpl#getAddress()
     * @generated
     */
    EClass ADDRESS = eINSTANCE.getAddress();

    /**
     * The meta object literal for the '<em><b>Name</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ADDRESS__NAME = eINSTANCE.getAddress_Name();

    /**
     * The meta object literal for the '<em><b>Street</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ADDRESS__STREET = eINSTANCE.getAddress_Street();

    /**
     * The meta object literal for the '<em><b>City</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ADDRESS__CITY = eINSTANCE.getAddress_City();

    /**
     * The meta object literal for the '<em><b>State</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ADDRESS__STATE = eINSTANCE.getAddress_State();

    /**
     * The meta object literal for the '<em><b>Zip</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ADDRESS__ZIP = eINSTANCE.getAddress_Zip();

    /**
     * The meta object literal for the '<em><b>Country</b></em>' attribute feature.
     * <!-- begin-user-doc -->
     * <!-- end-user-doc -->
     * @generated
     */
    EAttribute ADDRESS__COUNTRY = eINSTANCE.getAddress_Country();

  }

} //POPackage
