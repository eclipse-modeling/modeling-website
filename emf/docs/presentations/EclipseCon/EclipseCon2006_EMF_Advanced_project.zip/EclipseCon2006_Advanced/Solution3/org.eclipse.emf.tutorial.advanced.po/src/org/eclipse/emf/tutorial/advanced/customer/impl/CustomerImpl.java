/**
 * <copyright>
 * </copyright>
 *
 * $Id: CustomerImpl.java,v 1.1 2006/03/28 22:06:00 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.customer.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectWithInverseResolvingEList;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.emf.tutorial.advanced.customer.Customer;
import org.eclipse.emf.tutorial.advanced.customer.CustomerPackage;
import org.eclipse.emf.tutorial.advanced.customer.PaymentMethod;

import org.eclipse.emf.tutorial.advanced.po.POPackage;
import org.eclipse.emf.tutorial.advanced.po.PurchaseOrder;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Customer</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl#getPurchaseOrders <em>Purchase Orders</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl#getId <em>Id</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl#isVip <em>Vip</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.impl.CustomerImpl#getPreferredPaymentMethod <em>Preferred Payment Method</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class CustomerImpl extends PersonImpl implements Customer
{
  /**
   * The default value of the '{@link #getId() <em>Id</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getId()
   * @generated
   * @ordered
   */
  protected static final String ID_EDEFAULT = null;

  /**
   * The default value of the '{@link #isVip() <em>Vip</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isVip()
   * @generated
   * @ordered
   */
  protected static final boolean VIP_EDEFAULT = false;

  /**
   * The flag representing the value of the '{@link #isVip() <em>Vip</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #isVip()
   * @generated
   * @ordered
   */
  protected static final int VIP_EFLAG = 1 << 0;

  /**
   * The default value of the '{@link #getPreferredPaymentMethod() <em>Preferred Payment Method</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getPreferredPaymentMethod()
   * @generated
   * @ordered
   */
  protected static final PaymentMethod PREFERRED_PAYMENT_METHOD_EDEFAULT = PaymentMethod.CREDIT_CARD_LITERAL;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected CustomerImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return CustomerPackage.Literals.CUSTOMER;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getPurchaseOrders()
  {
    EList purchaseOrders = (EList)eVirtualGet(CustomerPackage.CUSTOMER__PURCHASE_ORDERS);
    if (purchaseOrders == null)
    {
      eVirtualSet(CustomerPackage.CUSTOMER__PURCHASE_ORDERS, purchaseOrders = new EObjectWithInverseResolvingEList(PurchaseOrder.class, this, CustomerPackage.CUSTOMER__PURCHASE_ORDERS, POPackage.PURCHASE_ORDER__CUSTOMER));
    }
    return purchaseOrders;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getId()
  {
    return (String)eVirtualGet(CustomerPackage.CUSTOMER__ID, ID_EDEFAULT);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setId(String newId)
  {
    String id = newId;
    Object oldId = eVirtualSet(CustomerPackage.CUSTOMER__ID, id);
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, CustomerPackage.CUSTOMER__ID, oldId == EVIRTUAL_NO_VALUE ? ID_EDEFAULT : oldId, id));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean isVip()
  {
    return (flags & VIP_EFLAG) != 0;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setVip(boolean newVip)
  {
    boolean oldVip = (flags & VIP_EFLAG) != 0;
    if (newVip) flags |= VIP_EFLAG; else flags &= ~VIP_EFLAG;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, CustomerPackage.CUSTOMER__VIP, oldVip, newVip));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public PaymentMethod getPreferredPaymentMethod()
  {
    return (PaymentMethod)eVirtualGet(CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD, PREFERRED_PAYMENT_METHOD_EDEFAULT);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setPreferredPaymentMethod(PaymentMethod newPreferredPaymentMethod)
  {
    PaymentMethod preferredPaymentMethod = newPreferredPaymentMethod == null ? PREFERRED_PAYMENT_METHOD_EDEFAULT : newPreferredPaymentMethod;
    Object oldPreferredPaymentMethod = eVirtualSet(CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD, preferredPaymentMethod);
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD, oldPreferredPaymentMethod == EVIRTUAL_NO_VALUE ? PREFERRED_PAYMENT_METHOD_EDEFAULT : oldPreferredPaymentMethod, preferredPaymentMethod));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        return ((InternalEList)getPurchaseOrders()).basicAdd(otherEnd, msgs);
    }
    return super.eInverseAdd(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        return ((InternalEList)getPurchaseOrders()).basicRemove(otherEnd, msgs);
    }
    return super.eInverseRemove(otherEnd, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(int featureID, boolean resolve, boolean coreType)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        return getPurchaseOrders();
      case CustomerPackage.CUSTOMER__ID:
        return getId();
      case CustomerPackage.CUSTOMER__VIP:
        return isVip() ? Boolean.TRUE : Boolean.FALSE;
      case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
        return getPreferredPaymentMethod();
    }
    return super.eGet(featureID, resolve, coreType);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(int featureID, Object newValue)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        getPurchaseOrders().clear();
        getPurchaseOrders().addAll((Collection)newValue);
        return;
      case CustomerPackage.CUSTOMER__ID:
        setId((String)newValue);
        return;
      case CustomerPackage.CUSTOMER__VIP:
        setVip(((Boolean)newValue).booleanValue());
        return;
      case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
        setPreferredPaymentMethod((PaymentMethod)newValue);
        return;
    }
    super.eSet(featureID, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(int featureID)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        getPurchaseOrders().clear();
        return;
      case CustomerPackage.CUSTOMER__ID:
        setId(ID_EDEFAULT);
        return;
      case CustomerPackage.CUSTOMER__VIP:
        setVip(VIP_EDEFAULT);
        return;
      case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
        setPreferredPaymentMethod(PREFERRED_PAYMENT_METHOD_EDEFAULT);
        return;
    }
    super.eUnset(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(int featureID)
  {
    switch (featureID)
    {
      case CustomerPackage.CUSTOMER__PURCHASE_ORDERS:
        EList purchaseOrders = (EList)eVirtualGet(CustomerPackage.CUSTOMER__PURCHASE_ORDERS);
        return purchaseOrders != null && !purchaseOrders.isEmpty();
      case CustomerPackage.CUSTOMER__ID:
        String id = (String)eVirtualGet(CustomerPackage.CUSTOMER__ID, ID_EDEFAULT);
        return ID_EDEFAULT == null ? id != null : !ID_EDEFAULT.equals(id);
      case CustomerPackage.CUSTOMER__VIP:
        return ((flags & VIP_EFLAG) != 0) != VIP_EDEFAULT;
      case CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD:
        return eVirtualGet(CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD, PREFERRED_PAYMENT_METHOD_EDEFAULT) != PREFERRED_PAYMENT_METHOD_EDEFAULT;
    }
    return super.eIsSet(featureID);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (id: ");
    result.append(eVirtualGet(CustomerPackage.CUSTOMER__ID, ID_EDEFAULT));
    result.append(", vip: ");
    result.append((flags & VIP_EFLAG) != 0);
    result.append(", preferredPaymentMethod: ");
    result.append(eVirtualGet(CustomerPackage.CUSTOMER__PREFERRED_PAYMENT_METHOD, PREFERRED_PAYMENT_METHOD_EDEFAULT));
    result.append(')');
    return result.toString();
  }

} //CustomerImpl