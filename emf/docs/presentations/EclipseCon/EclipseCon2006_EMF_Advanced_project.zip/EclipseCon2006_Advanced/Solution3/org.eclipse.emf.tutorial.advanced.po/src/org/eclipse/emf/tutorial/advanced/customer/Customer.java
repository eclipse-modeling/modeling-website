/**
 * <copyright>
 * </copyright>
 *
 * $Id: Customer.java,v 1.1 2006/03/28 22:06:01 nickb Exp $
 */
package org.eclipse.emf.tutorial.advanced.customer;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Customer</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPurchaseOrders <em>Purchase Orders</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getId <em>Id</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#isVip <em>Vip</em>}</li>
 *   <li>{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPreferredPaymentMethod <em>Preferred Payment Method</em>}</li>
 * </ul>
 * </p>
 *
 * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer()
 * @model
 * @generated
 */
public interface Customer extends Person
{
  /**
   * Returns the value of the '<em><b>Purchase Orders</b></em>' reference list.
   * The list contents are of type {@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder}.
   * It is bidirectional and its opposite is '{@link org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getCustomer <em>Customer</em>}'.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Purchase Orders</em>' reference list isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Purchase Orders</em>' reference list.
   * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer_PurchaseOrders()
   * @see org.eclipse.emf.tutorial.advanced.po.PurchaseOrder#getCustomer
   * @model type="org.eclipse.emf.tutorial.advanced.po.PurchaseOrder" opposite="customer" required="true"
   * @generated
   */
  EList getPurchaseOrders();

  /**
   * Returns the value of the '<em><b>Id</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Id</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Id</em>' attribute.
   * @see #setId(String)
   * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer_Id()
   * @model
   * @generated
   */
  String getId();

  /**
   * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getId <em>Id</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Id</em>' attribute.
   * @see #getId()
   * @generated
   */
  void setId(String value);

  /**
   * Returns the value of the '<em><b>Vip</b></em>' attribute.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Vip</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Vip</em>' attribute.
   * @see #setVip(boolean)
   * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer_Vip()
   * @model
   * @generated
   */
  boolean isVip();

  /**
   * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#isVip <em>Vip</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Vip</em>' attribute.
   * @see #isVip()
   * @generated
   */
  void setVip(boolean value);

  /**
   * Returns the value of the '<em><b>Preferred Payment Method</b></em>' attribute.
   * The literals are from the enumeration {@link org.eclipse.emf.tutorial.advanced.customer.PaymentMethod}.
   * <!-- begin-user-doc -->
   * <p>
   * If the meaning of the '<em>Preferred Payment Method</em>' attribute isn't clear,
   * there really should be more of a description here...
   * </p>
   * <!-- end-user-doc -->
   * @return the value of the '<em>Preferred Payment Method</em>' attribute.
   * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
   * @see #setPreferredPaymentMethod(PaymentMethod)
   * @see org.eclipse.emf.tutorial.advanced.customer.CustomerPackage#getCustomer_PreferredPaymentMethod()
   * @model
   * @generated
   */
  PaymentMethod getPreferredPaymentMethod();

  /**
   * Sets the value of the '{@link org.eclipse.emf.tutorial.advanced.customer.Customer#getPreferredPaymentMethod <em>Preferred Payment Method</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @param value the new value of the '<em>Preferred Payment Method</em>' attribute.
   * @see org.eclipse.emf.tutorial.advanced.customer.PaymentMethod
   * @see #getPreferredPaymentMethod()
   * @generated
   */
  void setPreferredPaymentMethod(PaymentMethod value);

} // Customer