Fundamentals of the Eclipse Modeling Framework: Tutorial Exercises


This README file is contained in an archived Update Manager site, which
provides the exercises for the EMF tutorial at EclipseCon 2008.

You will first need to install Eclipse and EMF. The recommended versions for
this tutorial are Eclipse 3.4 M5 and EMF 2.4 M5:

http://download.eclipse.org/eclipse/downloads/drops/S-3.4M5-200802071530/index.php#EclipseSDK
http://www.eclipse.org/downloads/download.php?file=/modeling/emf/emf/downloads/drops/2.4.0/S200802090050/emf-sdo-xsd-SDK-2.4.0M5.zip

Then, you can start Eclipse and run Update Manager: "Help > Software Updates >
Find and Install..." Select "Search for new features to install" and click
"Next".

Click the "New Archived Site..." button. Find and select the archive
"EclipseCon2008_309T_Fundamentals_of_EMF_Exercises.zip". Give the site a
simpler name, such as "EMF at EclipseCon 2008" and click "OK". Then select the
new site and click the "Finish" button.

On the Search Results page, select "EMF at EclipseCon 2008" and click "Finish".
If there are errors, you'll need to cancel and ensure that you have installed
EMF (2.3.0 or later) manually.

Accept the license and allow the installation of the unsigned feature. Restart
Eclipse when prompted. The Welcome experience should be started, with "EMF at
EclipseCon 2008" displayed prominently. Click the EMF icon to launch the cheat
sheet and follow its instructions to start the exercises. If you don't see it,
you can launch the cheat sheet via "Help > Cheat Sheets...".
