/**
 * <copyright>
 * </copyright>
 *
 * $Id: SDODOMExample.java,v 1.1 2006/03/28 23:55:06 nickb Exp $
 */
package org.eclipse.emf.example.dom;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.EMap;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.sdo.SDOPackage;
import org.eclipse.emf.ecore.sdo.impl.DynamicEDataObjectImpl;
import org.eclipse.emf.ecore.util.BasicExtendedMetaData;
import org.eclipse.emf.ecore.util.Diagnostician;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.ExtendedMetaData;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.FeatureMapUtil;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.GenericXMLResourceFactoryImpl;
import org.eclipse.emf.ecore.xml.type.AnyType;
import org.eclipse.emf.ecore.xml.type.XMLTypeFactory;
import org.eclipse.xsd.XSDAttributeDeclaration;
import org.eclipse.xsd.XSDAttributeUse;
import org.eclipse.xsd.XSDComplexTypeDefinition;
import org.eclipse.xsd.XSDCompositor;
import org.eclipse.xsd.XSDElementDeclaration;
import org.eclipse.xsd.XSDFactory;
import org.eclipse.xsd.XSDModelGroup;
import org.eclipse.xsd.XSDParticle;
import org.eclipse.xsd.XSDSchema;
import org.eclipse.xsd.ecore.XSDEcoreBuilder;
import org.eclipse.xsd.util.XSDConstants;
import org.eclipse.xsd.util.XSDResourceFactoryImpl;


/**
 * <!-- begin-user-doc -->
 * A sample utility for the '<em><b>dom</b></em>' package.
 * <!-- end-user-doc -->
 * @generated
 */
public class SDODOMExample
{
  public static final String NAMESPACE_URI = "http://www.eclipse.org/emf/example/DOM";
  public static final String NAMESPACE_PREFIX = "dom";
  /**
   * <!-- begin-user-doc -->
   * Load all the argument file paths or URIs as instances of the model.
   * <!-- end-user-doc -->
   * @param args the file paths or URIs.
   * @generated
   */
  public static void main(String[] args)
  {
    // Create a resource set to hold the resources.
    //
    ResourceSet resourceSet = new ResourceSetImpl();
    
    // Register the appropriate resource factory to handle all file extentions.
    //
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put
      (Resource.Factory.Registry.DEFAULT_EXTENSION, 
       new GenericXMLResourceFactoryImpl()
       {
         public Resource createResource(URI uri)
         {
           XMLResource result = (XMLResource)super.createResource(uri);
           result.getDefaultLoadOptions().put(XMLResource.OPTION_ANY_SIMPLE_TYPE, SDOPackage.eINSTANCE.getEDataObjectSimpleAnyType());
           result.getDefaultLoadOptions().put(XMLResource.OPTION_ANY_TYPE, SDOPackage.eINSTANCE.getEDataObjectAnyType());
           return result;
         }
       });

    // If there are no arguments, emit an appropriate usage message.
    //
    if (args.length == 0)
    {
      System.out.println("Enter a list of file paths or URIs that have content like this:");
      
      ExtendedMetaData extendedMetaData = new BasicExtendedMetaData(resourceSet.getPackageRegistry());
      
      EStructuralFeature documentRootFeature = extendedMetaData.demandFeature(NAMESPACE_URI, "root", true);
      
      EClass documentRootClass = documentRootFeature.getEContainingClass();
      documentRootClass.getEPackage().setEFactoryInstance(new DynamicEDataObjectImpl.FactoryImpl());
      EObject documentRoot = EcoreUtil.create(documentRootClass);
      
      EMap xmlnsPrefixMap = (EMap)documentRoot.eGet(extendedMetaData.getXMLNSPrefixMapFeature(documentRootClass));
      xmlnsPrefixMap.put("dom", NAMESPACE_URI);
      
      AnyType rootValue = XMLTypeFactory.eINSTANCE.createAnyType();
      documentRoot.eSet(documentRootFeature, rootValue);
      
      EStructuralFeature childAttribute = extendedMetaData.demandFeature(null, "x", false);
      rootValue.eSet(childAttribute, "value");
      
      FeatureMap rootMixed = rootValue.getMixed();
      FeatureMapUtil.addText(rootMixed, "\n  ");
      
      EStructuralFeature childElement = extendedMetaData.demandFeature(null, "child", true);
      AnyType childValue = XMLTypeFactory.eINSTANCE.createAnyType();
      FeatureMapUtil.addText(childValue.getAny(), "childElementContent");
      FeatureMapUtil.addCDATA(childValue.getAny(), " <escape> ");
      FeatureMapUtil.addComment(childValue.getAny(), "commentary");
      rootMixed.add(childElement, childValue);
      
      FeatureMapUtil.addText(rootMixed, "\n");
     
      ByteArrayOutputStream serializedDocument = new ByteArrayOutputStream();
      try
      {
        Resource resource = resourceSet.createResource(URI.createURI("http:///my.xml"));
        resource.getContents().add(documentRoot);
        resource.save(System.out, null);
        resource.save(serializedDocument, null);
        
        Resource newResource = resourceSet.createResource(URI.createURI("http:///my2.xml"));
        newResource.load(new ByteArrayInputStream(serializedDocument.toByteArray()), null);
        
        if (!newResource.getContents().isEmpty())
        {
          EObject root = (EObject)newResource.getContents().get(0);
          System.out.println();
          System.out.println("Visit");
          visit(root, "");
        }
        
        XSDSchema xsdSchema = schemaExample(resourceSet);
        URI xsdSchemaLocation = URI.createFileURI(new File("data/my.xsd").getAbsolutePath());
        xsdSchema.eResource().setURI(xsdSchemaLocation);
        xsdSchema.eResource().save(null);
        
        URI dataFileLocation = URI.createFileURI(new File("data/my.xml").getAbsolutePath());
        Resource newResource2 = resourceSet.createResource(dataFileLocation);
        newResource2.load(new ByteArrayInputStream(serializedDocument.toByteArray()), null);
        
        if (!newResource2.getContents().isEmpty())
        {
          EObject root = (EObject)newResource2.getContents().get(0);
          
          EMap xsiSchemaLocationMap = (EMap)root.eGet(extendedMetaData.getXSISchemaLocationMapFeature(root.eClass()));
          xsiSchemaLocationMap.put(xsdSchema.getTargetNamespace(), xsdSchemaLocation.toString());
          
          System.out.println();
          System.out.println("Visit----");
          visit(root, "");
          
          newResource2.save(null);
        }
        
        ResourceSet resourceSet2 = new ResourceSetImpl();
        
        // Register the appropriate resource factory to handle all file extentions.
        //
        resourceSet2.getResourceFactoryRegistry().getExtensionToFactoryMap().put
          (Resource.Factory.Registry.DEFAULT_EXTENSION, 
           new GenericXMLResourceFactoryImpl());
           
        Resource resource3 = resourceSet2.getResource(dataFileLocation, true);
        if (!resource3.getContents().isEmpty())
        {
          EObject root = (EObject)resource3.getContents().get(0);
          
          System.out.println();
          System.out.println("Visit-*-");
          visit(root, "");
          
          resource3.save(System.out, null);
        }
      }
      catch (IOException exception) 
      {
        exception.printStackTrace();
      }
    }
    else
    {
      // Iterate over all the arguments.
      //
      for (int i = 0; i < args.length; ++i)
      {
        // Construct the URI for the instance file.
        // The argument is treated as a file path only if it denotes an existing file.
        // Otherwise, it's directly treated as a URL.
        //
        File file = new File(args[0]);
        URI uri = file.isFile() ? URI.createFileURI(file.getAbsolutePath()): URI.createURI(args[0]);

        try
        {
          // Demand load resource for this file.
          //
          Resource resource = resourceSet.getResource(uri, true);
          System.out.println("Loaded " + uri);

          // Validate the contents of the loaded resource.
          //
          for (Iterator j = resource.getContents().iterator(); j.hasNext(); )
          {
            EObject eObject = (EObject)j.next();
            Diagnostic diagnostic = Diagnostician.INSTANCE.validate(eObject);
            if (diagnostic.getSeverity() != Diagnostic.OK)
            {
              printDiagnostic(diagnostic, "");
            }
          }
        }
        catch (RuntimeException exception) 
        {
          System.out.println("Problem loading " + uri);
          exception.printStackTrace();
        }
      }
    }
  }
  
  public static XSDSchema schemaExample(ResourceSet resourceSet)
  {
    // Create the schema, give it a target namespace, and set its form defaults.
    //
    XSDSchema xsdSchema =  XSDFactory.eINSTANCE.createXSDSchema();

    xsdSchema.setTargetNamespace(NAMESPACE_URI);

    // If you want schema tags and references to schema types to be qualified,
    // which is recommend, this is the recommended qualifier.
    //
    xsdSchema.setSchemaForSchemaQNamePrefix("xsd");

    // Choose the prefix used for this schema's namespace,
    // the schema for schema's namespace,
    // and some other imported namespace.
    //
    Map qNamePrefixToNamespaceMap = xsdSchema.getQNamePrefixToNamespaceMap();
    qNamePrefixToNamespaceMap.put(NAMESPACE_PREFIX, xsdSchema.getTargetNamespace());
    qNamePrefixToNamespaceMap.put(xsdSchema.getSchemaForSchemaQNamePrefix(), XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001);
    
    
    XSDComplexTypeDefinition rootTypeDefinition  = XSDFactory.eINSTANCE.createXSDComplexTypeDefinition();
    rootTypeDefinition.setName("Root");
    xsdSchema.getContents().add(rootTypeDefinition);
    
    XSDParticle modelGroupParticle = XSDFactory.eINSTANCE.createXSDParticle();
    XSDModelGroup sequence = XSDFactory.eINSTANCE.createXSDModelGroup();
    sequence.setCompositor(XSDCompositor.SEQUENCE_LITERAL);
    modelGroupParticle.setContent(sequence);
    rootTypeDefinition.setContent(modelGroupParticle);
    
    XSDParticle childElementParticle = XSDFactory.eINSTANCE.createXSDParticle();
    XSDElementDeclaration childElement = XSDFactory.eINSTANCE.createXSDElementDeclaration();
    childElement.setName("child");
    childElement.setTypeDefinition(xsdSchema.getSchemaForSchema().resolveSimpleTypeDefinition("string"));
    childElementParticle.setContent(childElement);
    
    sequence.getContents().add(childElementParticle);
    
    XSDAttributeUse xAttributeUse = XSDFactory.eINSTANCE.createXSDAttributeUse(); 
    XSDAttributeDeclaration xAttribute = XSDFactory.eINSTANCE.createXSDAttributeDeclaration();
    xAttribute.setName("x");
    xAttribute.setTypeDefinition(xsdSchema.getSchemaForSchema().resolveSimpleTypeDefinition("string"));
    xAttributeUse.setContent(xAttribute);
    
    rootTypeDefinition.getAttributeContents().add(xAttributeUse);
    
    XSDElementDeclaration rootElementDeclaration = XSDFactory.eINSTANCE.createXSDElementDeclaration();
    rootElementDeclaration.setName("root");
    rootElementDeclaration.setTypeDefinition(rootTypeDefinition);
    xsdSchema.getContents().add(rootElementDeclaration);
    
    // Register the appropriate resource factory to handle all file extentions.
    //
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put
      ("xsd",
       new XSDResourceFactoryImpl());
    
    Resource xsdResource = resourceSet.createResource(URI.createURI("http:///my.xsd"));
    xsdResource.getContents().add(xsdSchema);
    
    try
    {
      xsdResource.save(System.out, null);
    }
    catch (IOException exception)
    {
      exception.printStackTrace();
    }
    
    XSDEcoreBuilder xsdEcoreBuilder = new XSDEcoreBuilder();
    xsdEcoreBuilder.generate(xsdSchema);
    EPackage ePackage = (EPackage)xsdEcoreBuilder.getTargetNamespaceToEPackageMap().get(xsdSchema.getTargetNamespace());
    
    // Register the appropriate resource factory to handle all file extentions.
    //
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put
      ("ecore",
       new EcoreResourceFactoryImpl());
       
    Resource ecoreResource = resourceSet.createResource(URI.createURI("http:///my.ecore"));
    ecoreResource.getContents().add(ePackage);
    
    try
    {
      ecoreResource.save(System.out, null);
    }
    catch (IOException exception)
    {
      exception.printStackTrace();
    }
    
    resourceSet.getPackageRegistry().put(xsdSchema.getTargetNamespace(), ePackage);
    
    return xsdSchema;
  }
  
  protected static void visit(EObject eObject, String indentation)
  {
    EClass eClass = eObject.eClass();
    System.out.print(indentation);
    System.out.print(eClass.getEPackage().getNsURI());
    System.out.print("#");
    System.out.println(eClass.getName());
    for (int i = 0, size = eClass.getFeatureCount(); i < size; ++i)
    { 
      EStructuralFeature eStructuralFeature = eClass.getEStructuralFeature(i);
      if (!eStructuralFeature.isTransient() && eObject.eIsSet(eStructuralFeature))
      {
        Object value = eObject.eGet(eStructuralFeature);
        if (FeatureMapUtil.isFeatureMap(eStructuralFeature))
        {
          FeatureMap featureMap = (FeatureMap)value;
          for (int j = 0, featureMapSize = featureMap.size(); j < featureMapSize; ++j)
          {
            visit(featureMap.getEStructuralFeature(j), featureMap.getValue(j), indentation);
          }
        }
        else if (eStructuralFeature.isMany())
        {
          for (Iterator j = ((List)value).iterator(); j.hasNext(); )
          {
            visit(eStructuralFeature, j.next(), indentation);
          }
        }
        else
        {
          visit(eStructuralFeature, value, indentation + "  ");
        }
      }
    }
  }
  
  protected static void visit(EStructuralFeature eStructuralFeature, Object value, String indentation)
  {
    System.out.print(indentation);
    System.out.print("  ");
    System.out.print(eStructuralFeature.getName());
    if (eStructuralFeature instanceof EAttribute)
    {
      EAttribute eAttribute = (EAttribute)eStructuralFeature;
      System.out.print("=\"");
      System.out.print(EcoreUtil.convertToString(eAttribute.getEAttributeType(), value));
      System.out.println('"');
    }
    else
    {
      EReference eReference = (EReference)eStructuralFeature;
      if (eReference.isContainment())
      {
        System.out.println();
        visit((EObject)value, indentation + "    ");
      }
      else
      {
        System.out.print("=");
        System.out.println(EcoreUtil.getURI((EObject)value));
      }
    }
  }
  
  /**
   * <!-- begin-user-doc -->
   * Prints diagnostics with indentation.
   * <!-- end-user-doc -->
   * @param diagnostic the diagnostic to print.
   * @param indent the indentation for printing.
   * @generated
   */
  protected static void printDiagnostic(Diagnostic diagnostic, String indent)
  {
    System.out.print(indent);
    System.out.println(diagnostic.getMessage());
    for (Iterator i = diagnostic.getChildren().iterator(); i.hasNext(); )
    {
      printDiagnostic((Diagnostic)i.next(), indent + "  ");
    }
  }

} //DomExample
