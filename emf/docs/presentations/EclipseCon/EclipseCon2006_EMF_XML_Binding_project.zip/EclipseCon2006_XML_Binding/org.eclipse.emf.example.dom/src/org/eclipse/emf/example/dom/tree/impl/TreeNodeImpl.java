/**
 * <copyright>
 * </copyright>
 *
 * $Id: TreeNodeImpl.java,v 1.1 2006/03/28 23:55:06 nickb Exp $
 */
package org.eclipse.emf.example.dom.tree.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.BasicFeatureMap;
import org.eclipse.emf.ecore.util.EObjectResolvingEList;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.InternalEList;

import org.eclipse.emf.example.dom.tree.TreeNode;
import org.eclipse.emf.example.dom.tree.TreePackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Node</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link org.eclipse.emf.example.dom.tree.impl.TreeNodeImpl#getMixed <em>Mixed</em>}</li>
 *   <li>{@link org.eclipse.emf.example.dom.tree.impl.TreeNodeImpl#getChildNodes <em>Child Nodes</em>}</li>
 *   <li>{@link org.eclipse.emf.example.dom.tree.impl.TreeNodeImpl#getLabel <em>Label</em>}</li>
 *   <li>{@link org.eclipse.emf.example.dom.tree.impl.TreeNodeImpl#getReferences <em>References</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class TreeNodeImpl extends EObjectImpl implements TreeNode
{
  /**
   * The cached value of the '{@link #getMixed() <em>Mixed</em>}' attribute list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getMixed()
   * @generated
   * @ordered
   */
  protected FeatureMap mixed = null;

  /**
   * The default value of the '{@link #getLabel() <em>Label</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLabel()
   * @generated
   * @ordered
   */
  protected static final String LABEL_EDEFAULT = null;

  /**
   * The cached value of the '{@link #getLabel() <em>Label</em>}' attribute.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getLabel()
   * @generated
   * @ordered
   */
  protected String label = LABEL_EDEFAULT;

  /**
   * The cached value of the '{@link #getReferences() <em>References</em>}' reference list.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @see #getReferences()
   * @generated
   * @ordered
   */
  protected EList references = null;

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected TreeNodeImpl()
  {
    super();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected EClass eStaticClass()
  {
    return TreePackage.eINSTANCE.getTreeNode();
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public FeatureMap getMixed()
  {
    if (mixed == null)
    {
      mixed = new BasicFeatureMap(this, TreePackage.TREE_NODE__MIXED);
    }
    return mixed;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getChildNodes()
  {
    return ((FeatureMap)getMixed()).list(TreePackage.eINSTANCE.getTreeNode_ChildNodes());
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String getLabel()
  {
    return label;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void setLabel(String newLabel)
  {
    String oldLabel = label;
    label = newLabel;
    if (eNotificationRequired())
      eNotify(new ENotificationImpl(this, Notification.SET, TreePackage.TREE_NODE__LABEL, oldLabel, label));
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public EList getReferences()
  {
    if (references == null)
    {
      references = new EObjectResolvingEList(TreeNode.class, this, TreePackage.TREE_NODE__REFERENCES);
    }
    return references;
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, Class baseClass, NotificationChain msgs)
  {
    if (featureID >= 0)
    {
      switch (eDerivedStructuralFeatureID(featureID, baseClass))
      {
        case TreePackage.TREE_NODE__MIXED:
          return ((InternalEList)getMixed()).basicRemove(otherEnd, msgs);
        case TreePackage.TREE_NODE__CHILD_NODES:
          return ((InternalEList)getChildNodes()).basicRemove(otherEnd, msgs);
        default:
          return eDynamicInverseRemove(otherEnd, featureID, baseClass, msgs);
      }
    }
    return eBasicSetContainer(null, featureID, msgs);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public Object eGet(EStructuralFeature eFeature, boolean resolve)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case TreePackage.TREE_NODE__MIXED:
        return getMixed();
      case TreePackage.TREE_NODE__CHILD_NODES:
        return getChildNodes();
      case TreePackage.TREE_NODE__LABEL:
        return getLabel();
      case TreePackage.TREE_NODE__REFERENCES:
        return getReferences();
    }
    return eDynamicGet(eFeature, resolve);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eSet(EStructuralFeature eFeature, Object newValue)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case TreePackage.TREE_NODE__MIXED:
        getMixed().clear();
        getMixed().addAll((Collection)newValue);
        return;
      case TreePackage.TREE_NODE__CHILD_NODES:
        getChildNodes().clear();
        getChildNodes().addAll((Collection)newValue);
        return;
      case TreePackage.TREE_NODE__LABEL:
        setLabel((String)newValue);
        return;
      case TreePackage.TREE_NODE__REFERENCES:
        getReferences().clear();
        getReferences().addAll((Collection)newValue);
        return;
    }
    eDynamicSet(eFeature, newValue);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public void eUnset(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case TreePackage.TREE_NODE__MIXED:
        getMixed().clear();
        return;
      case TreePackage.TREE_NODE__CHILD_NODES:
        getChildNodes().clear();
        return;
      case TreePackage.TREE_NODE__LABEL:
        setLabel(LABEL_EDEFAULT);
        return;
      case TreePackage.TREE_NODE__REFERENCES:
        getReferences().clear();
        return;
    }
    eDynamicUnset(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public boolean eIsSet(EStructuralFeature eFeature)
  {
    switch (eDerivedStructuralFeatureID(eFeature))
    {
      case TreePackage.TREE_NODE__MIXED:
        return mixed != null && !mixed.isEmpty();
      case TreePackage.TREE_NODE__CHILD_NODES:
        return !getChildNodes().isEmpty();
      case TreePackage.TREE_NODE__LABEL:
        return LABEL_EDEFAULT == null ? label != null : !LABEL_EDEFAULT.equals(label);
      case TreePackage.TREE_NODE__REFERENCES:
        return references != null && !references.isEmpty();
    }
    return eDynamicIsSet(eFeature);
  }

  /**
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public String toString()
  {
    if (eIsProxy()) return super.toString();

    StringBuffer result = new StringBuffer(super.toString());
    result.append(" (mixed: ");
    result.append(mixed);
    result.append(", label: ");
    result.append(label);
    result.append(')');
    return result.toString();
  }

} //TreeNodeImpl
