/**
 * <copyright>
 * </copyright>
 *
 * $Id: TreeExample.java,v 1.1 2006/03/28 23:55:06 nickb Exp $
 */
package org.eclipse.emf.example.dom;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;


import org.eclipse.emf.common.util.EMap;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.EDataType;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EPackage;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.EcorePackage;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.util.BasicExtendedMetaData;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.ExtendedMetaData;
import org.eclipse.emf.ecore.util.FeatureMap;
import org.eclipse.emf.ecore.util.FeatureMapUtil;
import org.eclipse.emf.ecore.xmi.XMLResource;
import org.eclipse.emf.ecore.xmi.impl.EcoreResourceFactoryImpl;
import org.eclipse.emf.ecore.xmi.impl.GenericXMLResourceFactoryImpl;
import org.eclipse.emf.ecore.xml.type.AnyType;
import org.eclipse.emf.ecore.xml.type.XMLTypeFactory;
import org.eclipse.emf.example.dom.tree.DocumentRoot;
import org.eclipse.emf.example.dom.tree.TreeNode;
import org.eclipse.emf.example.dom.tree.TreePackage;
import org.eclipse.emf.example.dom.tree.util.TreeResourceFactoryImpl;
import org.eclipse.xsd.XSDAttributeDeclaration;
import org.eclipse.xsd.XSDAttributeUse;
import org.eclipse.xsd.XSDComplexTypeDefinition;
import org.eclipse.xsd.XSDCompositor;
import org.eclipse.xsd.XSDElementDeclaration;
import org.eclipse.xsd.XSDFactory;
import org.eclipse.xsd.XSDForm;
import org.eclipse.xsd.XSDModelGroup;
import org.eclipse.xsd.XSDParticle;
import org.eclipse.xsd.XSDSchema;
import org.eclipse.xsd.XSDSimpleTypeDefinition;
import org.eclipse.xsd.ecore.XSDEcoreBuilder;
import org.eclipse.xsd.util.XSDConstants;
import org.eclipse.xsd.util.XSDResourceFactoryImpl;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;

/**
 *<p>
 * Manipulating XML data easily and efficiently in Java remains an important problem.
 * Numerous approaches to XML binding exist in the industry, 
 * including DOM, JAXB, XML Beans, Castor, and so on.
 * In this article we will explore how the Eclipse Modeling Framework, EMF, 
 * solves the XML binding problem in a number interesting ways,
 * and we'll compare that to the alternatives.
 * EMF provides a core meta model API, Ecore, analgous to XML Schema, 
 * and a core instance data model API, EObject, analgous to DOM Node.
 * Ecore is to abstract syntax what XML Schema is to concrete syntax, a unifiying meta model.
 * But rather start with vague abstractions, 
 * it seems best to start from  something well known and concrete.
 * and to draw comparisons to that.
 *</p>
 *<p>
 * To bring concreteness to the discussion,
 * we explore the binding problem by way of an example.
 * Consider the problem of creating the following XML instance using DOM, i.e., org.w3c.dom.*.
 *<pre>
 * &lt;?xml version="1.0" encoding="UTF-8"?>
 * &lt;tree:rootNode xmlns:tree="http://www.eclipse.org/emf/example/dom/Tree" label="root">
 *   &lt;tree:childNode label="text">text&lt;/tree:childNode>
 *   &lt;tree:childNode label="comment">&lt;!--comment-->&lt;/tree:childNode>
 *   &lt;tree:childNode label="cdata">&lt;![CDATA[&lt;cdata>]]>&lt;/tree:childNode>
 * &lt;/tree:rootNode>
 *</pre>
 * The complete source code for this article can be found at #URL#.
 *</p>
 *
 * @author merks@ca.ibm.com
 */
public class TreeExample
{
  /**
   * When running this examle as an Eclipse project, 
   * the current directory will be the root folder of the project.
   */
  public static final String WORKING_FOLDER;
  static
  {
    String result = "."; 
    try
    {
      result = new File(".").getCanonicalPath() + "/";
    }
    catch (Exception exception)
    {
    }
    WORKING_FOLDER = result;
  }
  
  /**
   * We will store data files in the "data" subfolder of the project.
   */
  public static final String DATA_FOLDER = WORKING_FOLDER + "data/";
  
  /**
   * And we will store meta data files in "model" subfolder of the project.
   */
  public static final String MODEL_FOLDER = WORKING_FOLDER + "model/";
  
  /**
   *  This is the namespace in our example.
   */
  public static final String NAMESPACE_URI = "http://www.eclipse.org/emf/example/dom/Tree";
  
  /**
   *  And this is the prefix in our example.
   */
  public static final String NAMESPACE_PREFIX = "tree";
  
  /**
   * We will first look at how to use DOM to create the sample instance, serialize it, load it, and traverse it.
   * Then we will look at how to use EMF to do the analagous things,
   * and reflect on the differences and similarities.
   * After that, we will explore how XML Schema helps bring structure and order to the binding problem 
   * by helping set expectations about what meaningful content may appear.
   * EMF provides the XSD model to represent XML Schema instances,
   * and it provides support for mapping XSD instances to Ecore instances.
   * We'll demonstrate how this can be used for processing data instances in more structured way.
   *
   * Given that EMF supports generating a Java API from Ecore, 
   * the mapping from XSD to Ecore provides an implict mapping onto Java.
   * The Eclipse EMF website tutorial shows how to generate a Java implementation starting with a schema.
   * We will look at how that generated API can be used to process a instance 
   * and at how EMF's flexible resource model supports multiple cross linked documents.
   * For the stake of brevity, we will ignore exceptions.
   */
  public static void main(String[] args) throws Exception
  {
    demonstrateDOMCreateAndSave();
    demonstrateDOMLoadAndTraverse();
    demonstateEMFDOMCreateAndSave();
    demonstrateEMFDOMLoadAndTraverse();
    demonstrateSchema();
    demonstrateDynamicSchemaLoad();
    demonstrateStaticLoadAndTraverse();
    demonstrateMultiResourceStaticLoadAndTraverse();
  }
  
  /**
   * We will start by creating an instance and saving it to a file using DOM.
   */
  public static void demonstrateDOMCreateAndSave() throws Exception
  {
    System.out.println("DOM Create And Save");
    
    // Create a document builder factory, 
    // which can be configured in interesting ways.
    // For our purposes, it should be namespace aware.
    //
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    documentBuilderFactory.setNamespaceAware(true);
    
    // Use the document builder factory to create a document builder.
    //
    DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
    
    // And use the document builder to create the desired document 
    // as the starting point for building a DOM instance.
    //
    Document document = documentBuilder.newDocument();
    
    // Create a root element with the right namespace and prefix as in the example.
    //
    Element rootTreeNode =  document.createElementNS(NAMESPACE_URI, NAMESPACE_PREFIX + ":rootNode");
    
    // Add it as the root document element.
    //
    document.appendChild(rootTreeNode);
    
    // Note that the creation of the element implicitly does.
    //
    rootTreeNode.setAttributeNS("http://www.w3.org/2000/xmlns/", "xmlns:" + NAMESPACE_PREFIX, NAMESPACE_URI);
    
    // Set the label attribute of the root to the appropriate value.
    //
    rootTreeNode.setAttributeNS(null, "label", "root");
    
    // Next create and add all the children.
    // Note that to get the formatting exactly the way it is in the example,
    // we'll need to add all the formatting ourselves,
    // rather than rely on indented formatting.
    
    // Create the first child element, 
    // append identation to the root, 
    // append the child to the root,
    // set the label of the child,
    // and append a regular text node.
    //
    Element textChildTreeNode =  document.createElementNS(NAMESPACE_URI, NAMESPACE_PREFIX + ":childNode");
    rootTreeNode.appendChild(document.createTextNode("\n  "));
    rootTreeNode.appendChild(textChildTreeNode);
    textChildTreeNode.setAttributeNS(null, "label", "text");
    textChildTreeNode.appendChild(document.createTextNode("text"));
    
    // Create the second child element, 
    // append identation to the root, 
    // append the child to the root,
    // set the label of the child,
    // and append a comment node.
    //
    Element commentChildTreeNode =  document.createElementNS(NAMESPACE_URI, NAMESPACE_PREFIX + ":childNode");
    rootTreeNode.appendChild(document.createTextNode("\n  "));
    rootTreeNode.appendChild(commentChildTreeNode);
    commentChildTreeNode.setAttributeNS(null, "label", "comment");
    commentChildTreeNode.appendChild(document.createComment("comment"));
    
    // Create the third child element, 
    // append identation to the root, 
    // append the child to the root,
    // set the label of the child,
    // and append a comment node.
    //
    Element cdataChildTreeNode =  document.createElementNS(NAMESPACE_URI, NAMESPACE_PREFIX + ":childNode");
    rootTreeNode.appendChild(document.createTextNode("\n  "));
    rootTreeNode.appendChild(cdataChildTreeNode);
    cdataChildTreeNode.setAttributeNS(null, "label", "cdata");
    cdataChildTreeNode.appendChild(document.createCDATASection("<cdata>"));
    
    // Ensure that the closing delimiter is on a new line.
    //
    rootTreeNode.appendChild(document.createTextNode("\n"));
    
    // To serialize, create a transformer factory and use it to create a tranformer.
    // For the example, we serialize both to the data folders and to System.out.
    //
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    transformer.transform(new DOMSource(document), new StreamResult(new FileOutputStream(DATA_FOLDER + "DOMTreeNode.xml")));
    transformer.transform(new DOMSource(document), new StreamResult(System.out));
    System.out.println();
    
    // This produces the example result with the minor annoyance that the xml header is not on a line by itself.
    //
  }
  
  /**
   * Having serialized the sample result in a file, we'll now look at now to load it again.
   */
  public static void demonstrateDOMLoadAndTraverse() throws Exception
  {
    System.out.println("DOM Load And Traverse");
    
    // Set up a document builder again.
    //
    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
    documentBuilderFactory.setNamespaceAware(true);
    DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
    
    // But use it to parse the file. 
    //
    Document document = documentBuilder.parse(new File(DATA_FOLDER + "DOMTreeNode.xml"));
    
    // Use a transformer to display the results of reading in the data.
    //
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    transformer.transform(new DOMSource(document), new StreamResult(System.out));
    System.out.println();
    
    // We will use a recursive method to traverse the element structure of the DOM,
    // to print out a trace of the data.
    //
    System.out.println("Traversing DOM Element");
    new Object()
    {
      /**
       * Visit each element.
       */
      public void traverse(String indent, Element element)
      {
        // Print the namespace and name of the element.
        //
        System.out.println(indent + "{" + element.getNamespaceURI() + "}" + element.getLocalName());
        
        // Print the label of the element.
        //
        System.out.println(indent + "  label=" + element.getAttributeNS(null, "label"));
        
        // Visit the children.
        //
        for (Node child = element.getFirstChild(); child != null; child = child.getNextSibling())
        {
          // Consider each type of child.
          //
          switch (child.getNodeType())
          {
            case Node.TEXT_NODE:
            {
              // Print a representation of the text.
              //
              System.out.println(indent + "  '" + child.getNodeValue().replaceAll("\n", "\\\\n") + "'");
              break;
            }
            case Node.COMMENT_NODE:
            {
              // Print a representation of the comment.
              //
              System.out.println(indent + "  <!--" + child.getNodeValue() + "-->");
              break;
            }
            case Node.CDATA_SECTION_NODE:
            {
              // Print a representation of the CDATA.
              //
              System.out.println(indent + "  <![CDATA[" + child.getNodeValue() + "]]>");
              break;
            }
            case Node.ELEMENT_NODE:
            {
              // Visit the nested element.
              //
              traverse(indent + "  ", (Element)child);
              break;
            }
          }
        }
      }
    }.traverse("",  document.getDocumentElement());
  }
  
  /**
   * Having looked at how to use DOM to create the sample instance, serialize it, load it, and traverse it,
   * we'll now look at how to use EMF to do the analagous things.
   */
  public static void demonstateEMFDOMCreateAndSave() throws Exception
  {
    System.out.println("EMF DOM Create And Save");
    
    // To set up the context for EMF, we create a resource set,
    // which holds or provide access to all the data and meta data.
    //
    ResourceSet resourceSet = new ResourceSetImpl();

    // To use EMF's mapping of XML Schema to Ecore, 
    // we will rely on the extended meta data API,
    // so we create a local instance,
    // and register it so that this one instance will be used when loading data into the resource set.
    //
    final ExtendedMetaData extendedMetaData = new BasicExtendedMetaData(resourceSet.getPackageRegistry());
    resourceSet.getLoadOptions().put(XMLResource.OPTION_EXTENDED_META_DATA, extendedMetaData);
      
    // Since EMF is strictly modeled, 
    // the names and namespaces used freely in DOM,
    // first need to be mapped to their corresponding representation in Ecore.
    // Since elements map to features in Ecore, to create the equivalent of an element we need to have an appropriate feature.
    // We do this by demanding a feature corresponding to a global element declaration with the given namespace and name.
    //
    EStructuralFeature rootNodeFeature = extendedMetaData.demandFeature(NAMESPACE_URI, "rootNode", true);
    
    // A feature is always defined within a containing class,
    // and for a feature corresponding to global element (or attribute) declaration, 
    // this will be a special class refered to as a document root.
    //
    EClass documentRootClass = rootNodeFeature.getEContainingClass();
    
    // As with any class, we can create an instance from it.
    // This instance is directly analagous to a DOM document.
    //
    EObject documentRoot = EcoreUtil.create(documentRootClass);
      
    // A document root has a special feature to hold the xmlns prefixes,
    // so we fetch the map and set the prefix.
    //
    EMap xmlnsPrefixMap = (EMap)documentRoot.eGet(extendedMetaData.getXMLNSPrefixMapFeature(documentRootClass));
    xmlnsPrefixMap.put(NAMESPACE_PREFIX, NAMESPACE_URI);
      
    // Use the factory corresponding to the XML Schema namespace to create an AnyType instance, 
    // which is the mapping for the XML Schema anyType, 
    // and provides effectively the equivalent data API as DOM.
    // It is a lot like an element, but, as we'll see later, 
    // it is more properly thought of as an instance of a complex type.
    //
    AnyType rootTreeNode = XMLTypeFactory.eINSTANCE.createAnyType();
    
    // Add it to the document.
    //
    documentRoot.eSet(rootNodeFeature, rootTreeNode);
      
    // Demand a feature that corresponds to a global attribute declaration with the given namespace and name,
    // and use it to set the label feature to the appropriate value. 
    //
    EStructuralFeature labelAttribute = extendedMetaData.demandFeature(null, "label", false);
    rootTreeNode.eSet(labelAttribute, "root");
      
    // Since the anyType has mixed content, there is a feature map representing that mixed content.
    // A feature map is effectively a list of feature value pairs 
    // designed to help support things like mixed content and substitution groups.
    //
    FeatureMap rootMixed = rootTreeNode.getMixed();
    
    // To create a child tree node with the correct element name, 
    // demand yet another element-based feature.
    //
    EStructuralFeature childNodeFeature = extendedMetaData.demandFeature(NAMESPACE_URI, "childNode", true);
    
    // Create the first child, 
    // append identation to the root, 
    // append the child to the root,
    // set the label of the child,
    // and append text.
    //
    AnyType textChildTreeNode = XMLTypeFactory.eINSTANCE.createAnyType();
    FeatureMapUtil.addText(rootMixed, "\n  ");
    rootMixed.add(childNodeFeature, textChildTreeNode);
    textChildTreeNode.eSet(labelAttribute, "text");
    FeatureMapUtil.addText(textChildTreeNode.getMixed(), "text");
    
    // Create the second child, 
    // append identation to the root, 
    // append the child to the root,
    // set the label of the child,
    // and append a comment.
    //
    AnyType commentChildTreeNode = XMLTypeFactory.eINSTANCE.createAnyType();
    FeatureMapUtil.addText(rootMixed, "\n  ");
    rootMixed.add(childNodeFeature, commentChildTreeNode);
    commentChildTreeNode.eSet(labelAttribute, "comment");
    FeatureMapUtil.addComment(commentChildTreeNode.getMixed(), "comment");
    
    // Create the third child, 
    // append identation to the root, 
    // append the child to the root,
    // set the label of the child,
    // and append CDATA.
    //
    AnyType cdataChildTreeNode = XMLTypeFactory.eINSTANCE.createAnyType();
    FeatureMapUtil.addText(rootMixed, "\n  ");
    rootMixed.add(childNodeFeature, cdataChildTreeNode);
    cdataChildTreeNode.eSet(labelAttribute, "cdata");
    FeatureMapUtil.addCDATA(cdataChildTreeNode.getMixed(), "<cdata>");
    
    // Ensure that the closing delimiter will begin on a new line.
    //
    FeatureMapUtil.addText(rootMixed, "\n");
     
    // Register the appropriate resource factory to handle all file extentions.
    //
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put
      (Resource.Factory.Registry.DEFAULT_EXTENSION, 
       new GenericXMLResourceFactoryImpl());
       
    // Create a resource to hold our instance,
    // add the instance to the resource,
    // and save it to the target file and to System.out.
    //
    Resource resource = resourceSet.createResource(URI.createFileURI(DATA_FOLDER + "EMFDOMTreeNode.xml"));
    resource.getContents().add(documentRoot);
    resource.save(null);
    resource.save(System.out, null);
    System.out.println();
    
    // This produces the example result exactly.
    //
  }
  
  /**
   * Having serialized the sample result in a file, we'll now look at now to load it again with EMF.
   */
  public static void demonstrateEMFDOMLoadAndTraverse() throws Exception
  {
    System.out.println("EMF DOM Load And Traverse");
    
    // Set up the same context as was used during save.
    //
    ResourceSet resourceSet = new ResourceSetImpl();
    final ExtendedMetaData extendedMetaData = new BasicExtendedMetaData(resourceSet.getPackageRegistry());
    resourceSet.getLoadOptions().put(XMLResource.OPTION_EXTENDED_META_DATA, extendedMetaData);
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put
      (Resource.Factory.Registry.DEFAULT_EXTENSION, 
       new GenericXMLResourceFactoryImpl());
       
    // Demand load the resource.
    //
    Resource resource = resourceSet.getResource(URI.createFileURI(DATA_FOLDER + "EMFDOMTreeNode.xml"), true);
    
    // Display what was loaded.
    //
    resource.save(System.out, null);
    System.out.println();
    
    System.out.println("Traversing EMF AnyType");
    
    // Get the document root instance from the resource
    // and get the root object from that.
    // We'll assume that it's an instance of AnyType (which isn't a good general assumption).
    //
    EObject documentRoot = (EObject)resource.getContents().get(0);
    AnyType rootTreeNode = (AnyType)documentRoot.eContents().get(0);
    
    // Cache the label feature we will use during the traversal.
    //
    final EStructuralFeature labelAttribute = extendedMetaData.demandFeature(null, "label", false);
    
    // Traverse the root tree node.
    //
    new Object()
    {
      public void traverse(String indent, AnyType anyType)
      {
        // Print out the element namespace and name.
        //
        System.out.println(indent + "{" + extendedMetaData.getNamespace(anyType.eContainmentFeature()) + "}" + 
                                          extendedMetaData.getName(anyType.eContainmentFeature()));
        // Print out the label.
        //
        System.out.println(indent + "  label=" + anyType.eGet(labelAttribute));
        
        // Visit the mixed content.
        //
        FeatureMap featureMap = anyType.getMixed();
        for (int i = 0, size = featureMap.size(); i < size; ++i)
        {
          // Consider each type of feature (in this example).
          //
          EStructuralFeature feature = featureMap.getEStructuralFeature(i);
          if (FeatureMapUtil.isText(feature))
          {
            // Print out the text.
            //
            System.out.println(indent + "  '" + featureMap.getValue(i).toString().replaceAll("\n", "\\\\n") + "'");
          }
          else if (FeatureMapUtil.isComment(feature))
          {
            // Print out the comment.
            //
            System.out.println(indent + "  <!--" +  featureMap.getValue(i) + "-->");
          }
          else if (FeatureMapUtil.isCDATA(feature))
          {
            // Print out the CDATA.
            //
            System.out.println(indent + "  <![CDATA[" + featureMap.getValue(i) + "]]>");
          }
          else if (feature instanceof EReference)
          {
            // Visit the child.
            //
            traverse(indent + "  ", (AnyType)featureMap.getValue(i));
          }
        }
      }
    }.traverse("", rootTreeNode);
    
    System.out.println("Result of EMF to DOM conversion");
    
    // An XML resource can be converted directly to a DOM document,
    // and it's possible to record a map between the two representations.
    // We'll do that and display the result of DOM as before
    //
    Document document = ((XMLResource)resource).save(null, null, null);
    TransformerFactory transformerFactory = TransformerFactory.newInstance();
    Transformer transformer = transformerFactory.newTransformer();
    transformer.transform(new DOMSource(document), new StreamResult(System.out));
    System.out.println();
  }
  
  /**
   * Reflecting back on the both approaches, 
   * it's quite clear that they are roughly equivalent,
   * and neither approach is very satisfying.
   * Moreover, the Ecore meta data seems to provide little additional value to justify the complexity, 
   * however small, it introduces.
   * 
   * Going back to the original problem of XML binding, 
   * a basic problem is that the XML infoset is a very complex low-level abstraction
   * and that complexity is reflected in any fully general data model representation of it.
   * That's why reinventing DOM will not lead to a great new leap forward.
   *
   * To address this fundamental problem,
   * XML Schema brings order to the unneeded generality of the XML infoset 
   * by specifying a grammatical type structure to impose on the infoset.
   * So the problem of XML binding to Java has focused primarily on mapping XML Schema to Java 
   * as a way to produce a cleaner more specific API.
   * Let's look into this more closely by considering possible schemas for our example.
   * The following trivial schema is a schema for our example, 
   * but an effectively useless one:
   * 
   * <xsd:schema  xmlns:tree="http://www.eclipse.org/emf/example/dom/Tree" 
   *      xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
   *      targetNamespace="http://www.eclipse.org/emf/example/dom/Tree">
   *   <xsd:element name="rootNode" type="xsd:anyType"/>
   * </xsd:schema>
   * 
   * This schema is interesting to consider, because this is effectively exactly the schema that's being used in the preceding DOM example.
   * The anyType is defined as
   *   <xsd:complexType name="anyType" mixed="true">
   *     <xsd:sequence>
   *       <xsd:any minOccurs="0" maxOccurs="unbounded" processContents="lax"/>
   *     </xsd:sequence>
   *     <xsd:anyAttribute processContents="lax"/>
   *   </xsd:complexType>
   * I.e., it defines a type for elements that have mixed content, any elements, and any attributes.
   * The Ecore mapping for XML Schema's anyType is as follows, with each access there for the obvious reason.
   * public interface AnyType extends EObject
   * {
   *   FeatureMap getMixed();
   *   FeatureMap getAny();
   *   FeatureMap getAnyAttribute();
   * }
   * Again, it's a fully general representation of mixed text, any element features, and any attribute features.
   * It says nothing about what specific things to expect in the content.
   * and it gives us no information with which to provide a simpler API.
   *
   * The following schema is a more interesting and restrictive version 
   * that describes the specific things we expect to see in our example.
   *
   * <?xml version="1.0" encoding="UTF-8"?>
   * <xsd:schema  xmlns:tree="http://www.eclipse.org/emf/example/dom/Tree" 
   *      xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
   *      targetNamespace="http://www.eclipse.org/emf/example/dom/Tree">
   *   <xsd:complexType mixed="true" name="TreeNode">
   *     <xsd:sequence>
   *       <xsd:element form="qualified" maxOccurs="unbounded" name="childNode" type="tree:TreeNode"/>
   *     </xsd:sequence>
   *     <xsd:attribute name="label" type="xsd:ID"/>
   *   </xsd:complexType>
   *   <xsd:element name="rootNode" type="tree:TreeNode"/>
   * </xsd:schema>
   * 
   *
   * It defines a TreeNode complex type 
   * with an element for "childNode" that is recursively of type TreeNode
   * and an attribute for "label" of type ID, so the value must be unique in the document.
   * It also defines a "rootNode" element of the TreeNode type.
   *
   * The whole point of a schema is to describe the form of data to be expected
   * and this information allows for the preparation of more specific data structures to carry the data
   * and  more specific APIs to access the data.
   * We will see how EMF takes advantage of this meta data to improve upon the DOM-level complexity of the AnyType API.
   *
   * In order to help highlight some of the interesting high-level capabilities of EMF,
   * we will augment this schema to add an additional attribute to TreeNode,
   * and to add EMF-specific annotations.
   * Specifically, 
   * we add an "ecore:name" annotation, to specify the name of the corresponding feature,
   * an attribute called "references", whose value is list of anyURI,
   * and an "ecore:reference" annotation for that attribute, 
   * to specify that these URIs represent references to other TreeNodes.
   * The idea of the URI-based reference is for them to appear just like an href in HTML, 
   * i.e., of the form <location-of-document>#<xml-id-in-document>.
   * Here's the slightly more interesting schema we will use for the example.
   *
   * <?xml version="1.0" encoding="UTF-8"?>
   * <xsd:schema xmlns:ecore="http://www.eclipse.org/emf/2002/Ecore" 
   *      xmlns:tree="http://www.eclipse.org/emf/example/dom/Tree" 
   *      xmlns:xsd="http://www.w3.org/2001/XMLSchema" 
   *      targetNamespace="http://www.eclipse.org/emf/example/dom/Tree">
   *   <xsd:complexType mixed="true" name="TreeNode">
   *     <xsd:sequence>
   *       <xsd:element ecore:name="childNodes" form="qualified" maxOccurs="unbounded" name="childNode" type="tree:TreeNode"/>
   *     </xsd:sequence>
   *     <xsd:attribute name="label" type="xsd:ID"/>
   *     <xsd:attribute ecore:reference="tree:TreeNode" name="references">
   *       <xsd:simpleType>
   *         <xsd:list itemType="xsd:anyURI"/>
   *       </xsd:simpleType>
   *     </xsd:attribute>
   *   </xsd:complexType>
   *   <xsd:element name="rootNode" type="tree:TreeNode"/>
   * </xsd:schema>
   *
   * XML Schema is just another model and EMF has the XSD model to represent instances of it, 
   * so we can create an instance XSD much like we did the example instance.
   * We'll look at how to do that first, 
   * keeping in mind that creating a schema is just like creating our example instance document.
   * One could of course create it using DOM directly, using a StringBuffer, or even a fancy schema editor, for that matter,
   * but ultimately, if you want to analyze a schema, you'll need an abstract model,
   * and EMF does need to analyze schemas when converting them to Ecore,
   * which we will also show in this example.
   */
  public static void demonstrateSchema() throws Exception
  {
    System.out.println("XSD Create Schema");
    
    // Set up a context as before.
    //
    ResourceSet resourceSet = new ResourceSetImpl();
    final ExtendedMetaData extendedMetaData = new BasicExtendedMetaData(resourceSet.getPackageRegistry());
    resourceSet.getLoadOptions().put(XMLResource.OPTION_EXTENDED_META_DATA, extendedMetaData);
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put
      (Resource.Factory.Registry.DEFAULT_EXTENSION, 
       new GenericXMLResourceFactoryImpl());
       
    // We will create this schema in the model folder.
    //
    URI schemaLocation = URI.createFileURI(MODEL_FOLDER + "DOMEMFTreeNode.xsd");
    
    // Create the schema instance, and give it a target namespace.
    //
    XSDSchema xsdSchema =  XSDFactory.eINSTANCE.createXSDSchema();
    xsdSchema.setTargetNamespace(NAMESPACE_URI);

    // Qualify the schema for schema as recommended.
    //
    xsdSchema.setSchemaForSchemaQNamePrefix("xsd");

    // Choose the prefix used for this schema's namespace,
    // for the schema for schema's namespace,
    // and for the Ecore namespace (which is used in the non-schema namespace attributes that act annotations).
    //
    Map qNamePrefixToNamespaceMap = xsdSchema.getQNamePrefixToNamespaceMap();
    qNamePrefixToNamespaceMap.put(NAMESPACE_PREFIX, xsdSchema.getTargetNamespace());
    qNamePrefixToNamespaceMap.put(xsdSchema.getSchemaForSchemaQNamePrefix(), XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001);
    qNamePrefixToNamespaceMap.put(EcorePackage.eNS_PREFIX, EcorePackage.eNS_URI);
    
    // Force the underlying DOM to be created 
    // so that we can add annotations to it directly.
    //
    xsdSchema.updateElement();
    
    // Create the TreeNode type, and add it to the schema.
    //
    XSDComplexTypeDefinition treeNodeTypeDefinition  = XSDFactory.eINSTANCE.createXSDComplexTypeDefinition();
    treeNodeTypeDefinition.setName("TreeNode");
    treeNodeTypeDefinition.setMixed(true);
    xsdSchema.getContents().add(treeNodeTypeDefinition);
    
    // Create the sequence model group to hold the element declaration, and add it to the type.
    //
    XSDParticle modelGroupParticle = XSDFactory.eINSTANCE.createXSDParticle();
    XSDModelGroup sequence = XSDFactory.eINSTANCE.createXSDModelGroup();
    sequence.setCompositor(XSDCompositor.SEQUENCE_LITERAL);
    modelGroupParticle.setContent(sequence);
    treeNodeTypeDefinition.setContent(modelGroupParticle);
    
    // Create a "childNode" element of type TreeNode, add it to the model group, and annotate it.
    //
    XSDParticle childElementParticle = XSDFactory.eINSTANCE.createXSDParticle();
    childElementParticle.setMaxOccurs(-1);
    XSDElementDeclaration childElement = XSDFactory.eINSTANCE.createXSDElementDeclaration();
    childElement.setName("childNode");
    childElement.setTypeDefinition(treeNodeTypeDefinition);
    childElement.setForm(XSDForm.QUALIFIED_LITERAL);
    childElementParticle.setContent(childElement);
    sequence.getContents().add(childElementParticle);
    childElement.getElement().setAttributeNS
      (EcorePackage.eNS_URI, EcorePackage.eNS_PREFIX + ":name", "childNodes");
    
    // Create a "label" attribute of type ID, and add it to the type.
    //
    XSDAttributeUse labelAttributeUse = XSDFactory.eINSTANCE.createXSDAttributeUse(); 
    XSDAttributeDeclaration xAttribute = XSDFactory.eINSTANCE.createXSDAttributeDeclaration();
    xAttribute.setName("label");
    xAttribute.setTypeDefinition(xsdSchema.getSchemaForSchema().resolveSimpleTypeDefinition("ID"));
    labelAttributeUse.setContent(xAttribute);
    treeNodeTypeDefinition.getAttributeContents().add(labelAttributeUse);
    
    // Create a "references" attribute of an anonymous list type, add it to the type, and annotate it.
    //
    XSDAttributeUse referencesAttributeUse = XSDFactory.eINSTANCE.createXSDAttributeUse(); 
    XSDAttributeDeclaration referencesAttributeDeclaration = XSDFactory.eINSTANCE.createXSDAttributeDeclaration();
    referencesAttributeDeclaration.setName("references");
    XSDSimpleTypeDefinition listOfAnyURITypeDefinition = XSDFactory.eINSTANCE.createXSDSimpleTypeDefinition();
    listOfAnyURITypeDefinition.setItemTypeDefinition(xsdSchema.getSchemaForSchema().resolveSimpleTypeDefinition("anyURI"));
    referencesAttributeDeclaration.setAnonymousTypeDefinition(listOfAnyURITypeDefinition);
    referencesAttributeUse.setContent(referencesAttributeDeclaration);
    treeNodeTypeDefinition.getAttributeContents().add(referencesAttributeUse);
    referencesAttributeDeclaration.getElement().setAttributeNS
      (EcorePackage.eNS_URI, EcorePackage.eNS_PREFIX + ":reference", NAMESPACE_PREFIX + ":TreeNode");
    
    // Create a "rootNode" element and add it to the schema.
    //
    XSDElementDeclaration rootElementDeclaration = XSDFactory.eINSTANCE.createXSDElementDeclaration();
    rootElementDeclaration.setName("rootNode");
    rootElementDeclaration.setTypeDefinition(treeNodeTypeDefinition);
    xsdSchema.getContents().add(rootElementDeclaration);
    
    // Register the appropriate resource factory to handle "xsd" file extentions.
    //
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put
      ("xsd",
       new XSDResourceFactoryImpl());
    
    // Create a resource to hold the new schema and add the schema to it.
    //
    Resource xsdResource = resourceSet.createResource(schemaLocation);
    xsdResource.getContents().add(xsdSchema);
    
    // Save the schema to the location,
    // and display what's been saved.
    //
    xsdSchema.eResource().setURI(schemaLocation);
    xsdSchema.eResource().save(null);
    xsdSchema.eResource().save(System.out, null);
        
    // This completes the creation of the example schema.
    // It's interesting to consider how many of the concepts needed to manipulate XML instances are reused when dealing with XSD.
    // XSD acts as a wrapper for the underlying DOM syntax of the language, 
    // and that DOM is fully accessible for setting non-schema namespaces annotation attributes,
    // so your knowledge of DOM can be reapplied.
    // The XSD instances, like the AnyType instances, 
    // are created with a factory and are added to a resource that in turn is created with a resource factory within a resource set.
    // This reuse of common concepts that apply for all instances is the whole point of EMF's existance.
    // Given a suitably powerful system of representation, it will assimilate all other data.
    //
    // An XSD instance is assimilated by converting it to an Ecore instance.
    // To do that, create an instance of the XSDEcoreBuilder, 
    // and use it to create a corresponding Ecore instance given our XSD instance.
    // Each namespace in the schema results in a corresponding EPackage, 
    // which acts as a container for all the types defined in that namespace.  
    // There's only one namespace in our example,
    // so we extract that one corresponding package.
    //
    XSDEcoreBuilder xsdEcoreBuilder = new XSDEcoreBuilder(extendedMetaData);
    xsdEcoreBuilder.generate(xsdSchema);
    EPackage ePackage = extendedMetaData.getPackage(NAMESPACE_URI);
    
    // Let's very briefly consider the basic structure of an Ecore model.
    // A package has an nsURI corresponding to the schema's namespace,
    // and contain contains classifiers corresponding to the types in the schema.
    //
    System.out.println("XSD to Ecore Mapping");
    System.out.println("package " + ePackage.getNsURI());
    for (Iterator i = ePackage.getEClassifiers().iterator(); i.hasNext(); )
    {
      // Each classifier is either a class or a data type,
      // corresponding to either a complex type or a simple type in the schema.
      //
      EClassifier eClassifier = (EClassifier)i.next();
      if (eClassifier instanceof EClass)
      {
        // A class has a name and contains features.
        // Instances of a class are EObjects.
        //
        EClass eClass = (EClass)eClassifier;
        System.out.println("  class " + eClass.getName());
        for (Iterator j = eClass.getEStructuralFeatures().iterator(); j.hasNext(); )
        {
          // Each feature, corresponding to an element or attribute in the schema, 
          // is either a reference or an attribute,
          // depending on whether the type of the element or attribute is complex or simple.
          // I.e., references have class types and attributes have data types.
          //
          EStructuralFeature eStructuralFeature = (EStructuralFeature)j.next();
          if (eStructuralFeature instanceof EReference)
          {
            EReference eReference = (EReference)eStructuralFeature;
            System.out.println("    reference " + eReference.getName() + ":" + eReference.getEReferenceType().getName());
          }
          else
          {
            EAttribute eAttribute = (EAttribute)eStructuralFeature;
            System.out.println("    attribute " + eAttribute.getName() + ":" + eAttribute.getEAttributeType().getName());
          }
        }
      }
      else
      {
        // Data type instances are serializeable by conversion to and from a simple string representation,
        // unlike class instances, i.e., EObjects, which need a hierarchical element structure to serialize all their complex parts.
        //
        EDataType eDataType = (EDataType)eClassifier;
        System.out.println("  data type " + eDataType.getName());
      }
    }
    
    // A package, like any other instance, can be added to a resource.
    // The URI of the package's containing resource can be used to control the schema location saved in a serialized instance,
    // so we create a resource independant from this resource set, using the appropriate resource factory and the schema location URI,
    // and add the package to it.
    // Note that we want to avoid having more than one resource in the resource set with the same URI,
    // and we need to be especially careful when using a URI with an "xsd" extension
    // that we don't end up creating a resource specialized for XSD instances.
    //
    Resource ecoreResource =  new EcoreResourceFactoryImpl().createResource(schemaLocation);
    ecoreResource.getContents().add(ePackage);
    
    // Now we load the example instance resource using the meta data just created to handle it,
    // and rename the resource so that we can save it with an xsi:schemaLocation for use in the next example.
    //
    Resource resource = resourceSet.getResource(URI.createFileURI(DATA_FOLDER + "EMFDOMTreeNode.xml"), true);
    resource.setURI(URI.createFileURI(DATA_FOLDER + "EMFDOMTreeNodeWithXSI.xml"));
    resource.save(null);
    resource.save(System.out, null);
    System.out.println();
    
    // The above produces this:
    //
    // <?xml version="1.0" encoding="UTF-8"?>
    // <tree:rootNode xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:tree="http://www.eclipse.org/emf/example/dom/Tree"
    //    xsi:schemaLocation="http://www.eclipse.org/emf/example/dom/Tree ../model/DOMEMFTreeNode.xsd" label="root">
    //   <tree:childNode label="text">text</tree:childNode>
    //   <tree:childNode label="comment"><!--comment--></tree:childNode>
    //   <tree:childNode label="cdata"><![CDATA[<cdata>]]></tree:childNode>
    // </tree:rootNode>
    
    System.out.println("Traversing EMF EObject");
    
    // Get the document root instance from the resource
    // and get the root object from that.
    // This time we won't assume the root is an instance of AnyType, which in fact it won't be.
    //
    EObject documentRoot = (EObject)resource.getContents().get(0);
    EObject rootTreeNode = (EObject)documentRoot.eContents().get(0);
    
    // This time we'll assume the root object and all the intermediate objects are of some special type representing a TreeNode.
    // We can access that type directly from the instance,
    // or we can look it up by name.
    //
    if (rootTreeNode.eClass() != extendedMetaData.getType(NAMESPACE_URI, "TreeNode"))
    {
      throw new Exception("Bad meta data");
    }
    
    // Since we know what kind of data to expect for a TreeNode,
    // we know to cache two features for fetching instance data during traversal,
    // the mixed feature and the label feature.
    //
    final EStructuralFeature mixedFeature = extendedMetaData.getMixedFeature(rootTreeNode.eClass());
    final EStructuralFeature labelAttribute = extendedMetaData.getAttribute(rootTreeNode.eClass(), null, "label");
    
    // Visit all the tree nodes exactly as before, 
    // but without assuming they are AnyType instances.
    // I.e., we use purely reflection on the EMF's data API.
    //
    new Object()
    {
      public void traverse(String indent, EObject eObject)
      {
        System.out.println(indent + "{" + extendedMetaData.getNamespace(eObject.eContainmentFeature()) + "}" + 
                                          extendedMetaData.getName(eObject.eContainmentFeature()));
        System.out.println(indent + "  label=" + eObject.eGet(labelAttribute));
        
        // Access the feature map reflectively.
        //
        FeatureMap featureMap = (FeatureMap)eObject.eGet(mixedFeature);
        for (int i = 0, size = featureMap.size(); i < size; ++i)
        {
          EStructuralFeature feature = featureMap.getEStructuralFeature(i);
          if (FeatureMapUtil.isText(feature))
          {
            System.out.println(indent + "  '" + featureMap.getValue(i).toString().replaceAll("\n", "\\\\n") + "'");
          }
          else if (FeatureMapUtil.isComment(feature))
          {
            System.out.println(indent + "  <!--" +  featureMap.getValue(i) + "-->");
          }
          else if (FeatureMapUtil.isCDATA(feature))
          {
            System.out.println(indent + "  <![CDATA[" + featureMap.getValue(i) + "]]>");
          }
          else if (feature instanceof EReference)
          {
            traverse(indent + "  ", (EObject)featureMap.getValue(i));
          }
        }
      }
    }.traverse("", rootTreeNode);
  }
  
  /**
   * As we saw in the previous example, EMF can create Ecore instances on demand from XSD instances,
   * and can create instances of that Ecore model to process an instance document.
   * Given this purely dynamic capabilitiy, 
   * it shouldn't be surprising that EMF can take advantage of schema location information in an instance document,
   * to do all the same processing automatically behind the scenes.
   * We'll look at how that's done, as well as how to exploit EMF's support for cross references.
   */
  public static void demonstrateDynamicSchemaLoad() throws Exception
  {
    System.out.println("EMF Dynamic Load Schema");
    
    // Set up the context as before.
    //
    ResourceSet resourceSet = new ResourceSetImpl();
    final ExtendedMetaData extendedMetaData = new BasicExtendedMetaData(resourceSet.getPackageRegistry());
    resourceSet.getLoadOptions().put(XMLResource.OPTION_EXTENDED_META_DATA, extendedMetaData);
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put
      (Resource.Factory.Registry.DEFAULT_EXTENSION, 
       new GenericXMLResourceFactoryImpl());
       
    // Load the example resource containing the xsi:schemaLocation,
    // and display what's loaded.
    //
    Resource resource = resourceSet.getResource(URI.createFileURI(DATA_FOLDER + "EMFDOMTreeNodeWithXSI.xml"), true);
    resource.save(System.out, null);
    System.out.println();
    
    System.out.println("Traversing EMF EObject");
    
    // Fetch the root object as before.
    //
    EObject documentRoot = (EObject)resource.getContents().get(0);
    final EObject rootTreeNode = (EObject)documentRoot.eContents().get(0);
    
    // Again, we'll assume the root object and all the interemediate objects are of some special type representing a TreeNode.
    // We can access that type directly from the instance,
    // or we can look it up by name.
    //
    if (rootTreeNode.eClass() != extendedMetaData.getType(NAMESPACE_URI, "TreeNode"))
    {
      throw new Exception("Bad meta data");
    }
    
    // Cache the features that will be used to access instance data during the traversal as before.
    // Also cache the references feature which we introduced earlier.
    // Recall that we introduced a references attribute of type list of anyURI 
    // so that each tree node can not only contain other tree nodes but can also reference other tree nodes.
    //
    final EStructuralFeature mixedFeature = extendedMetaData.getMixedFeature(rootTreeNode.eClass());
    final EStructuralFeature labelAttribute = extendedMetaData.getAttribute(rootTreeNode.eClass(), null, "label");
    final EStructuralFeature referencesAttribute = extendedMetaData.getAttribute(rootTreeNode.eClass(), null, "references");
    
    // Traverse each tree node as before, but also add references to the root node to each node.
    //
    new Object()
    {
      public void traverse(String indent, EObject eObject)
      {
        System.out.println(indent + "{" + extendedMetaData.getNamespace(eObject.eContainmentFeature()) + "}" + 
                                          extendedMetaData.getName(eObject.eContainmentFeature()));
        System.out.println(indent + "  label=" + eObject.eGet(labelAttribute));
        
        // Use the references feature to fetch the list of references for this tree node
        // and add the root tree node as one of the nodes being referenced.
        //
        ((List)eObject.eGet(referencesAttribute)).add(rootTreeNode);
        
        FeatureMap featureMap = (FeatureMap)eObject.eGet(mixedFeature);
        for (int i = 0, size = featureMap.size(); i < size; ++i)
        {
          EStructuralFeature feature = featureMap.getEStructuralFeature(i);
          if (FeatureMapUtil.isText(feature))
          {
            System.out.println(indent + "  '" + featureMap.getValue(i).toString().replaceAll("\n", "\\\\n") + "'");
          }
          else if (FeatureMapUtil.isComment(feature))
          {
            System.out.println(indent + "  <!--" +  featureMap.getValue(i) + "-->");
          }
          else if (FeatureMapUtil.isCDATA(feature))
          {
            System.out.println(indent + "  <![CDATA[" + featureMap.getValue(i) + "]]>");
          }
          else if (feature instanceof EReference)
          {
            traverse(indent + "  ", (EObject)featureMap.getValue(i));
          }
        }
      }
    }.traverse("", rootTreeNode);
    
    System.out.println("Showing References set by traversal");
    
    // Rename the resource to save the modified instance.
    //
    resource.setURI(URI.createFileURI(DATA_FOLDER + "EMFDOMTreeNodeWithReferences.xml"));
    
    // Remove the xsi:schemaLocation from the instance before saving.
    //
    EMap xsiSchemaLocationMap = (EMap)documentRoot.eGet(extendedMetaData.getXSISchemaLocationMapFeature(documentRoot.eClass()));
    xsiSchemaLocationMap.clear();
    
    // Save and display the renamed instance.
    //
    resource.save(null);
    resource.save(System.out, null);
    System.out.println();
    
    // The above produces this result.
    //
    // <?xml version="1.0" encoding="UTF-8"?>
    // <tree:rootNode xmlns:tree="http://www.eclipse.org/emf/example/dom/Tree" label="root"
    //     references="#root">
    //   <tree:childNode label="text" references="#root">text</tree:childNode>
    //   <tree:childNode label="comment" references="#root"><!--comment--></tree:childNode>
    //   <tree:childNode label="cdata" references="#root"><![CDATA[<cdata>]]></tree:childNode>
    // </tree:rootNode>
    //
    // When serializing each referenced object, 
    // EMF determines the resource containing the object, EObject.eResource(),
    // and asks that resource how best to reference the object, 
    // Resource.getURIFragmentReference(EObject).
    // Because the label feature of the tree node is an ID, 
    // that value can be used to uniquely locate the instance in the document,
    // and so that's what's returned.
    // The reference is then formed by appending the fragment to the resource's URI, resource.getURI().
    // Before saving this URI, EMF determines if the URI can be made relative to the URI of resource into which the reference is being saved,
    // so all the same document references to the root object in the example result simple in "#root".
    // 
    // During load, this process is reversed. 
    // I.e., relative URIs are resolved to make them absolute, 
    // the portion of the URI without the fragment is used to find/load the resource, ResourceSet.getResource,
    // and the fragment portion is used to locate the object in the resource, Resource.getEObject.
    // All this URI behavior should come as no surprise, since that's how hrefs work in HMTL.
    //
  }
  
  /**
   * To complete EMF's XML binding picture, we need to take advantage of EMF's Java code generation capabilities.
   * Given the schema we've generated for this example,
   * we can use EMF's tools to import it.
   * To do this, right click on the .xsd and invoke "New->Other...->Eclise Modeling Framework->EMF Model".
   * Complete the dialog and it will open the Generator;
   * right clicking on the root object and invoking "Generate All" 
   * generates the corresponding Java implementation of the model,
   * along with all the other goodies we won't have time to explore,
   * such as a customizeable Eclipse editor that edits instances.
   *
   * Doing that will produces the following data API
   * A TreeNode interface with the expected methods
   *
   * public interface TreeNode extends EObject
   * {
   *   FeatureMap getMixed();
   *   EList getChildNodes();
   *   String getLabel();
   *   void setLabel(String value);
   *   EList getReferences();
   * }
   *
   * and a DocumentRoot interface with some general purpose methods as well as methods for accessing the root node.
   *
   *  public interface DocumentRoot extends EObject
   * {
   *   FeatureMap getMixed();
   *   EMap getXMLNSPrefixMap();
   *   EMap getXSISchemaLocation();
   * 
   *   TreeNode getRootNode();
   *   void setRootNode(TreeNode value);
   * }
   *
   */
  public static void  demonstrateStaticLoadAndTraverse() throws Exception
  {
    System.out.println("EMF Static Generated Load and Traverse");
    
    // Set up the context as before.
    //
    ResourceSet resourceSet = new ResourceSetImpl();
    final ExtendedMetaData extendedMetaData = new BasicExtendedMetaData(resourceSet.getPackageRegistry());
    resourceSet.getLoadOptions().put(XMLResource.OPTION_EXTENDED_META_DATA, extendedMetaData);
    
    // But register the resource factory generated for the tree model.
    //
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put
      (Resource.Factory.Registry.DEFAULT_EXTENSION, 
       new TreeResourceFactoryImpl());
       
    // Ensure that the generated tree package is registered.
    //
    resourceSet.getPackageRegistry().put(TreePackage.eNS_URI, TreePackage.eINSTANCE);
    
    // Load the resource for the example instance with the interesting references.
    // Note how we saved using a dynamic Ecore model but we are now loading using a statically generated model.
    //
    Resource resource = resourceSet.getResource(URI.createFileURI(DATA_FOLDER + "EMFDOMTreeNodeWithReferences.xml"), true);
    
    // Display what's been loaded.
    //
    resource.save(System.out, null);
    System.out.println();
    
    System.out.println("Traversing EMF TreeNode");
    
    // Fetch the root object using the generated example-specific API.
    //
    DocumentRoot documentRoot = (DocumentRoot)resource.getContents().get(0);
    TreeNode rootTreeNode = documentRoot.getRootNode();
    
    // The reflective data API supports an bountiful collection of useful utilities, such as a copier.
    // Here we will use a copier instance directly, so that we can take advantage of the map it computes from originals to copies.
    // We create a copier, copy the document root, and then ensure that all the cross references are set up based on the available copies.
    //
    final EcoreUtil.Copier copier = new EcoreUtil.Copier();
    final DocumentRoot documentRootCopy = (DocumentRoot)copier.copy(documentRoot);
    copier.copyReferences();
    
    // We will traverse the tree as so many times before, 
    // but now we can assume they are tree node instances.
    // During this traversal, 
    // we will make each copied node refer back to the original node from which it was copied.
    //
    new Object()
    {
      public void traverse(String indent, TreeNode treeNode)
      {
        System.out.println(indent + "{" + extendedMetaData.getNamespace(treeNode.eContainmentFeature()) + "}" + 
                                          extendedMetaData.getName(treeNode.eContainmentFeature()));
        System.out.println(indent + "  label=" + treeNode.getLabel());
        
        // Iterate over the references of the tree node.
        //
        for (Iterator i = treeNode.getReferences().iterator(); i.hasNext(); )
        {
          TreeNode referencedTreeNode = (TreeNode)i.next();
          
          // Display the label of the referenced tree node.
          //
          System.out.println(indent + "  reference=#" + referencedTreeNode.getLabel());
        }
        
        // Fetch the copy for this node and add this node to the set of nodes referenced by the copy.
        //
        TreeNode treeNodeCopy = (TreeNode)copier.get(treeNode);
        treeNodeCopy.getReferences().add(treeNode);
        
        FeatureMap featureMap = treeNode.getMixed();
        for (int i = 0, size = featureMap.size(); i < size; ++i)
        {
          EStructuralFeature feature = featureMap.getEStructuralFeature(i);
          if (FeatureMapUtil.isText(feature))
          {
            System.out.println(indent + "  '" + featureMap.getValue(i).toString().replaceAll("\n", "\\\\n") + "'");
          }
          else if (FeatureMapUtil.isComment(feature))
          {
            System.out.println(indent + "  <!--" +  featureMap.getValue(i) + "-->");
          }
          else if (FeatureMapUtil.isCDATA(feature))
          {
            System.out.println(indent + "  <![CDATA[" + featureMap.getValue(i) + "]]>");
          }
          else if (feature instanceof EReference)
          {
            traverse(indent + "  ", (TreeNode)featureMap.getValue(i));
          }
        }
      }
    }.traverse("", rootTreeNode);
    
    System.out.println("Showing the references set in the copy");
    
    // Create a new resource to store the copy, 
    // add the copy to it,
    // save it and display it.
    //
    Resource resource2 = resourceSet.createResource(URI.createFileURI(DATA_FOLDER + "TreeNodeMap.xml"));
    resource2.getContents().add(documentRootCopy);
    resource2.save(null);
    resource2.save(System.out, null);
    System.out.println();
   
    // This produces
    //
    // <?xml version="1.0" encoding="UTF-8"?>
    // <tree:rootNode xmlns:tree="http://www.eclipse.org/emf/example/dom/Tree" label="root"
    //     references="#root EMFDOMTreeNodeWithReferences.xml#root">
    //   <tree:childNode label="text" references="#root EMFDOMTreeNodeWithReferences.xml#text">text</tree:childNode>
    //   <tree:childNode label="comment" references="#root EMFDOMTreeNodeWithReferences.xml#comment"><!--comment--></tree:childNode>
    //   <tree:childNode label="cdata" references="#root EMFDOMTreeNodeWithReferences.xml#cdata"><![CDATA[<cdata>]]></tree:childNode>
    // </tree:rootNode>
    // 
    // Note how each node not only refers to the root node, but refers to the corresponding node in the other resource.
    // Also note how the reference to a resource in the same folder has been deresolved to produce a relative URI.
    //
  }
  
  /**
   * Instances with cross document references support loading resource on demand.
   */
  public static void demonstrateMultiResourceStaticLoadAndTraverse() throws Exception
  {
    System.out.println("EMF Multi Resource Static Generated Load and Traverse");
    
    // Set up the context as before.
    //
    ResourceSet resourceSet = new ResourceSetImpl();
    resourceSet.getPackageRegistry().put(TreePackage.eNS_URI, TreePackage.eINSTANCE);
    final ExtendedMetaData extendedMetaData = new BasicExtendedMetaData(resourceSet.getPackageRegistry());
    resourceSet.getLoadOptions().put(XMLResource.OPTION_EXTENDED_META_DATA, extendedMetaData);
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put
      (Resource.Factory.Registry.DEFAULT_EXTENSION, 
       new TreeResourceFactoryImpl());
       
    // Load the example instance containing the interesting cross document references,
    // and display what was loaded.
    //
    Resource resource = resourceSet.getResource(URI.createFileURI(DATA_FOLDER + "TreeNodeMap.xml"), true);
    
    resource.save(System.out, null);
    System.out.println();
    
    System.out.println("Traversing EMF TreeNode " + resource.getURI());
    
    // Fetch the root tree node as before.
    //
    DocumentRoot documentRoot = (DocumentRoot)resource.getContents().get(0);
    TreeNode rootTreeNode = documentRoot.getRootNode();
    
    // Traverse the tree yet again, paying special attention to the references.
    //
    new Object()
    {
      public void traverse(String indent, TreeNode treeNode)
      {
        System.out.println(indent + "{" + extendedMetaData.getNamespace(treeNode.eContainmentFeature()) + "}" + 
                                          extendedMetaData.getName(treeNode.eContainmentFeature()));
        System.out.println(indent + "  label=" + treeNode.getLabel());
        
        // Iterate over the references of the tree node.
        //
        for (Iterator i = treeNode.getReferences().iterator(); i.hasNext(); )
        {
          TreeNode referencedTreeNode = (TreeNode)i.next();
          
          // Display the resource of the referenced object and its label.
          //
          System.out.println(indent + "  reference=" + referencedTreeNode.eResource().getURI().lastSegment() + "#" + 
                                                       referencedTreeNode.getLabel());
        }
        
        FeatureMap featureMap = treeNode.getMixed();
        for (int i = 0, size = featureMap.size(); i < size; ++i)
        {
          EStructuralFeature feature = featureMap.getEStructuralFeature(i);
          if (FeatureMapUtil.isText(feature))
          {
            System.out.println(indent + "  '" + featureMap.getValue(i).toString().replaceAll("\n", "\\\\n") + "'");
          }
          else if (FeatureMapUtil.isComment(feature))
          {
            System.out.println(indent + "  <!--" +  featureMap.getValue(i) + "-->");
          }
          else if (FeatureMapUtil.isCDATA(feature))
          {
            System.out.println(indent + "  <![CDATA[" + featureMap.getValue(i) + "]]>");
          }
          else if (feature instanceof EReference)
          {
            traverse(indent + "  ", (TreeNode)featureMap.getValue(i));
          }
        }
      }
    }.traverse("", rootTreeNode);
    
    // This result is produced
    //
    //{http://www.eclipse.org/emf/example/dom/Tree}rootNode
    //  label=root
    //  reference=TreeNodeMap.xml#root
    //  reference=EMFDOMTreeNodeWithReferences.xml#root
    //  '\n  '
    //  {http://www.eclipse.org/emf/example/dom/Tree}childNode
    //    label=text
    //    reference=TreeNodeMap.xml#root
    //    reference=EMFDOMTreeNodeWithReferences.xml#text
    //    'text'
    //  '\n  '
    //  {http://www.eclipse.org/emf/example/dom/Tree}childNode
    //    label=comment
    //    reference=TreeNodeMap.xml#root
    //    reference=EMFDOMTreeNodeWithReferences.xml#comment
    //    <!--comment-->
    //  '\n  '
    //  {http://www.eclipse.org/emf/example/dom/Tree}childNode
    //    label=cdata
    //    reference=TreeNodeMap.xml#root
    //    reference=EMFDOMTreeNodeWithReferences.xml#cdata
    //    <![CDATA[<cdata>]]>
    //  '\n'
    //
    // To support this multi resource model, 
    // when parsing a resource, EMF creates a proxy placeholder for each cross document URI reference.
    // That placeholder is resolved on demand as it is fetched later during data traversal,
    // much as an HMTL linked is resolved to load a new document as you click on it.
    //
  }
  
  /**
   * We've really only touched the tip of the iceberg in terms of all the capabilities of EMF.
   * The primary goal of EMF's design and implementation has always been to provide 
   * a powerful yet simple high-level abstract data model 
   * and an efficient flexible instance representation for it.
   * EMF's application to XML binding has arisen as a natural evolutionary consequence of 
   * any suitably powerful representation's ability to assimilate all other data.
   * Ecore is simpler than XML Schema yet more powerful in important ways, e.g., typed references and multiple inheritance,
   * and EObject too is simpler than DOM yet more powerful in very important ways, e.g., a type-safe abstract reflective access,
   * so it should come as no surprise that the XML binding problem can be subsumed.
   * Reflecting back on the general nature of the problem,
   * it is clear that although there may be many ways in which XML can be bound to Java,
   * any binding for the full XML infoset will likely look much like DOM 
   * and that any binding for XML Schema will look much like the accessors API pattern we've outlined.
   * 
   * There is in fact little real difference between the various XML binding solutions.
   * Most of the differences between them arise because of the fact that XML Schema brings many complex problems into the picture,
   * necessating the introduction of undesireable complexities, like FeatureMaps.
   * Each complete binding solution surfaces this complexity in a different way.  
   * For example, our sample schema (modified to replace anyURI with IDREF, since JAXB doesn't support cross document references)
   * produces this API in JAXB 2.0:
   * 
   * public class TreeNode
   * {
   *     public List<Serializable> getContent();
   * 
   *     public String getLabel();
   * 
   *     public void setLabel(String value);
   * 
   *     public List<Object> getReferences();
   * }
   * 
   * With JAXB, the need to support mixed content results in loss of an accessor for the child nodes, 
   * in favor a of single general content accessor.
   * This contents lists can contain strings, representing the mixed content, 
   * and JAXBElement<TreeNode>s, representing value wrappers.
   * It's easy to draw a parallel between JAXBElements and EMF's FeatureMap.Entry,
   * but if we removed mixed content from the picture, the generated APIs for EMF and JAXB are effectively identical.
   * 
   * The problem of binding XML to Java remains a problem 
   * because XML Schema's complexities inevitably yield suboptimal bindings in all binding solutions.
   * Only a shift in focus away from concrete syntax and toward abstract syntax will yield optimal bindings.
   * APIs must focus on high-level abstractions, 
   * while the details of various possible concrete serializations should remain subordinate.
   * Models are the fundamental underlying unity that brings order; everything can be modeled and is a model.
   * Ecore models 
   * 
   * We've explored closely how XML Schema and Ecore paralell each other,
   * so this fundamental distinction betwee abstract syntax and  concrete syntax is something that becomes crystal
   * if you consider that although XML Schema's schema for schemas describes XML Schema's concrete syntax itself,
   * just as Ecore's Ecore model describes Ecore's abstract syntax iself,
   * it takes Ecore's XSD model to describe XML Schema's abstract syntax.
   */
  
} //DomExample
