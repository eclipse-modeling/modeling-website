/**
 * <copyright>
 * </copyright>
 *
 * $Id: TreeXMLProcessor.java,v 1.1 2006/03/28 23:55:06 nickb Exp $
 */
package org.eclipse.emf.example.dom.tree.util;

import java.util.Map;

import org.eclipse.emf.ecore.EPackage;

import org.eclipse.emf.ecore.xmi.util.XMLProcessor;

import org.eclipse.emf.example.dom.tree.TreePackage;

/**
 * This class contains helper methods to serialize and deserialize XML documents
 * <!-- begin-user-doc -->
 * <!-- end-user-doc -->
 * @generated
 */
public class TreeXMLProcessor extends XMLProcessor
{

  /**
   * Public constructor to instantiate the helper.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  public TreeXMLProcessor()
  {
    super((EPackage.Registry.INSTANCE));
    TreePackage.eINSTANCE.eClass();
  }
  
  /**
   * Register for "*" and "xml" file extensions the TreeResourceFactoryImpl factory.
   * <!-- begin-user-doc -->
   * <!-- end-user-doc -->
   * @generated
   */
  protected Map getRegistrations()
  {
    if (registrations == null)
    {
      super.getRegistrations();
      registrations.put(XML_EXTENSION, new TreeResourceFactoryImpl());
      registrations.put(STAR_EXTENSION, new TreeResourceFactoryImpl());
    }
    return registrations;
  }

} //TreeXMLProcessor
