These files can be used to configure Eclipse to format *.java files, set up the order of import statements in *.java files, and configure the template used when creating new *.java files. They are completely optional, but if you ever want to submit a patch to us, we STRONGLY recommend you use these so that your code will look like the existing EMF code, and thus be easier to diff.

To import these, start up Eclipse, then open Window > Preferences..., and browse to the following preference pages:

1. Java > Code Style > Code Templates > Import > EMFCodeTemplates.xml

2. Java > Code Style > Formatter > Import > EMFCodeFormatter.xml

3. Java > Code Style > Organize Imports > Import > EMF.importorder

Thanks!

The EMF Development Team
