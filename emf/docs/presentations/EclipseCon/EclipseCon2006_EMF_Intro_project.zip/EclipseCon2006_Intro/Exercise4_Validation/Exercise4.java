package exercises;


import java.io.File;
import java.io.IOException;

import org.eclipse.emf.common.util.Diagnostic;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;

import com.example.po.DocumentRoot;
import com.example.po.POPackage;
import com.example.po.PurchaseOrder;
import com.example.po.util.POResourceFactoryImpl;


public class Exercise4
{
  public static void main(String[] args) throws IOException
  {
    // Create a resource set and initialize it with resource factory and package registrations.
    //
    ResourceSet resourceSet = new ResourceSetImpl();
    resourceSet.getResourceFactoryRegistry().getExtensionToFactoryMap().put(
      Resource.Factory.Registry.DEFAULT_EXTENSION,
      new POResourceFactoryImpl());
    resourceSet.getPackageRegistry().put(POPackage.eNS_URI, POPackage.eINSTANCE);

    // Create a resource to load the po.xml file, and retrieve the order.
    //
    URI uri = URI.createFileURI(new File("data/po.xml").getAbsolutePath());
    Resource resource = resourceSet.createResource(uri);
    resource.load(null);
    DocumentRoot document = (DocumentRoot)resource.getContents().get(0);
    PurchaseOrder order = document.getOrder();

    // TODO: Obtain the singleton diagnostician instance, with which the data will be validated.
    //


    // TODO: Validate the purchase order and inspect the resulting diagnostic.
    // Another method is needed to recurse through the diagnostic's children,
    // printing the status and message for each.
    // See the method printDiagnostic() below.
    //


    // TODO: Fix the bad partNum values in the items.
    //   1. change item.0 partNum to 123-AB
    //   2. change item.1 partNum to 123-CD
    //


    // TODO: Validate the order again - this time it should be valid.
    //


    // TODO: Save the valid purchase order to "po-valid.xml", in the data directory.
    //

  }

  /**
   * Recursively prints the severity and message for the given diagnostic and its children.
   * @param diagnostic the diagnostic to print
   * @param depth the nesting depth of the diagnostic; should be 0 when first called
   */
  private static void printDiagnostic(Diagnostic diagnostic, int depth)
  {
    // TODO: Implement this method.
  }
}
