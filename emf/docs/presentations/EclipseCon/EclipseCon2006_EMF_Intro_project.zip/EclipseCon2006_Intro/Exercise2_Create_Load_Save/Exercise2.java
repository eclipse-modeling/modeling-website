package exercises;


import java.io.File;
import java.io.IOException;

import org.eclipse.emf.common.util.URI;


public class Exercise2
{
  public static void main(String[] args) throws IOException
  {
    // TODO: Create a resource set to hold the resources.
    //


    // TODO: Register the appropriate resource factory to handle all file extentions.
    //


    // TODO: Register the package to ensure it is available during loading.
    //


    // TODO: Create a resource and load an existing po.xml file using an absolute URI.
    // If you know the actual path, the URI could be something simpler like:
    //   URI uri = URI.createFileURI("/home/data/po.xml");
    //
    URI uri = URI.createFileURI(new File("data/po.xml").getAbsolutePath());


    // TODO: Retrieve the order.
    //


    // TODO: Retrieve the shipTo address from the order and print out the address data.
    //


    // TODO: Remove the discontinued item with SKU 'STV999876' from the order.
    //


    // TODO: Change the order's comment to indicate that the discontinued item has been removed.
    //


    // TODO: Serialize the updated content to the console, then to a "po-updated.xml" file.
    //

  }
}
