package org.eclipse.xsd.examples.schema2;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */

import java.util.*;

import org.eclipse.core.resources.*;

import org.eclipse.xsd.*;

/**
 * @author Dave Spriet
 * 
 * Lab 4 builds from Lab 3
 * 
<?xml version="1.0"?>
<schema 
  targetNamespace="http://www.eclipse.org/xsd/examples/po"
  xmlns="http://www.w3.org/2001/XMLSchema" 
  xmlns:po="http://www.eclipse.org/xsd/examples/po">
  
    <simpleType name="USState">
        <restriction base="string">
            <enumeration value="AK"/>
            <enumeration value="AL"/>
            <enumeration value="AR"/>
        </restriction>
    </simpleType>
    
    <simpleType>
        <list itemType="po:USState"/>
    </simpleType>
    
    <complexType name="PurchaseOrderType">
        <sequence/>
    </complexType>
    
</schema>
 */
public class Lab4 extends Object
{
/**
 * 
 */
public Lab4()
{
	super();
}

/**
 * Create the following schema
 * 
 * <?xml version="1.0"?>
 * <schema
 *   targetNamespace="http://www.eclipse.org/xsd/examples/po"
 *   xmlns="http://www.w3.org/2001/XMLSchema"
 *   xmlns:po="http://www.eclipse.org/xsd/examples/po">
 * 
 *   <simpleType name="USState">
 *     <restriction base="string">
 *        <enumeration value="AK"/>
 *        <enumeration value="AL"/>
 *        <enumeration value="AR"/>
 *     </restriction>
 *   </simpleType>
 * 
 *   <simpleType>
 *     <list itemType="po:USState"/>
 *   </simpleType>
 * 
 *   <complexType name="PurchaseOrderType">
 *      <sequence/>
 *   </complexType>
 * </schema>
 * 
 * @param xsdFile
 * @return
 */
public XSDSchema createSchema(IFile xsdFile)
{
	try
	{
		//Lab 4 builds from Lab 3
		Lab3 lab3 = new Lab3();
		XSDSchema schema = lab3.createSchema(xsdFile);
		
		//Create global complex type with name = "PurchaseOrderType"
		XSDComplexTypeDefinition complexType = XSDFactory.eINSTANCE.createXSDComplexTypeDefinition();
		complexType.setName("PurchaseOrderType");
		
		XSDParticle particle = XSDFactory.eINSTANCE.createXSDParticle();
		
		//Create a sequence model group
		XSDModelGroup modelGroup = XSDFactory.eINSTANCE.createXSDModelGroup();
		modelGroup.setCompositor(XSDCompositor.SEQUENCE_LITERAL);
		
		//Add the model group to the particle
		particle.setContent(modelGroup);
		
		//Set the contents of the complex type to be the particle
		complexType.setContent(particle);
		
		//Add the complex type to the root schema
		schema.getContents().add(complexType);
		
		// Save the contents of the resource to the file system.
		schema.eResource().save(Collections.EMPTY_MAP);
		
		return schema;
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	return null;
}
}
