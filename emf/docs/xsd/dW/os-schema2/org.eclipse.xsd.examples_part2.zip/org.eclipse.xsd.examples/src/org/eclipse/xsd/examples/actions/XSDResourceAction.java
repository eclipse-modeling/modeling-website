package org.eclipse.xsd.examples.actions;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */
 
import org.eclipse.core.resources.*;
import org.eclipse.jface.action.*;
import org.eclipse.jface.viewers.*;
import org.eclipse.ui.*;
import org.eclipse.ui.actions.*;

import org.eclipse.xsd.examples.schema2.*;

public class XSDResourceAction extends ActionDelegate implements IWorkbenchWindowActionDelegate
{
  protected IStructuredSelection fSelection;

  //Cache the xsd file 
  protected IFolder fGeneratedFolder;

/**
 * XSDResourceAction constructor comment.
 */
public XSDResourceAction() 
{
	super();
}

/** (non-Javadoc)
 * Method declared on IActionBar.
 */
public void run(IAction action)
{
	if (fGeneratedFolder != null)
	{
		try
		{
			//lets create the xml schema file createXSDWithTNS.xsd with target namespace 
			//http://www.eclipse.org/xsd/examples/createxsd
			IFile file = fGeneratedFolder.getFile("lab1.xsd");
			Lab1 lab1 = new Lab1();
			lab1.createSchema(file);
			
			file = fGeneratedFolder.getFile("lab2.xsd");
			Lab2 lab2 = new Lab2();
			lab2.createSchema(file);
			
			file = fGeneratedFolder.getFile("lab3.xsd");
			Lab3 lab3 = new Lab3();
			lab3.createSchema(file);
			
			file = fGeneratedFolder.getFile("lab4.xsd");
			Lab4 lab4 = new Lab4();
			lab4.createSchema(file);
			
			file = fGeneratedFolder.getFile("lab5.xsd");
			Lab5 lab5 = new Lab5();
			lab5.createSchema(file);
			
			file = fGeneratedFolder.getFile("lab6.xsd");
			Lab6 lab6 = new Lab6();
			lab6.createSchema(file);
												
			file = fGeneratedFolder.getFile("lab7.xsd");
			Lab7 lab7 = new Lab7();
			lab7.createSchema(file);												
		}
		catch (Exception e)
		{}
	}
}

/** (Non-javadoc)
 * Method declared on IActionDelegate.
 */
public void selectionChanged(IAction action, ISelection selection) 
{
	fGeneratedFolder=null;
	if (selection instanceof IStructuredSelection) 
	{
		fSelection = (IStructuredSelection)selection;
	}

	Object element = fSelection.getFirstElement();
		
	if ((element != null) && (element instanceof IFolder))
	{
		fGeneratedFolder = (IFolder) element;
		action.setEnabled(true);
		return;
	}
	action.setEnabled(false);		
}	

/* (non-Javadoc)
 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#dispose()
 */
public void dispose()
{
	
}

/* (non-Javadoc)
 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#init(org.eclipse.ui.IWorkbenchWindow)
 */
public void init(IWorkbenchWindow window)
{

}

}
