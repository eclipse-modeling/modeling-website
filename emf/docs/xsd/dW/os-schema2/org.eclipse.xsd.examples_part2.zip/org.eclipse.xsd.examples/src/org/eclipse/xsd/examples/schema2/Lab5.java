package org.eclipse.xsd.examples.schema2;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */

import java.util.*;

import org.eclipse.core.resources.*;

import org.eclipse.xsd.*;
import org.eclipse.xsd.util.*;

/**
 * @author Dave Spriet
 * 
 * Lab 5 builds from Lab 4
 * 
<?xml version="1.0"?>
<schema 
  targetNamespace="http://www.eclipse.org/xsd/examples/po"
  xmlns="http://www.w3.org/2001/XMLSchema" 
  xmlns:po="http://www.eclipse.org/xsd/examples/po">
  
    <simpleType name="USState">
        <restriction base="string">
            <enumeration value="AK"/>
            <enumeration value="AL"/>
            <enumeration value="AR"/>
        </restriction>
    </simpleType>
    
    <simpleType>
        <list itemType="po:USState"/>
    </simpleType>
    
    <complexType name="PurchaseOrderType">
        <sequence>
            <element minOccurs="0" name="state" type="po:USState"/>
            <element ref="po:notes"/>
        </sequence>
    </complexType>
    
    <element name="notes" type="string"/>
</schema>

 */
public class Lab5 extends Object
{
/**
 * 
 */
public Lab5()
{
	super();
}

/**
 * Create the following schema
 * 
 * <?xml version="1.0"?>
 * <schema
 *   targetNamespace="http://www.eclipse.org/xsd/examples/po"
 *   xmlns="http://www.w3.org/2001/XMLSchema"
 *   xmlns:po="http://www.eclipse.org/xsd/examples/po">
 * 
 *  <simpleType name="USState">
 *    <restriction base="string">
 *       <enumeration value="AK"/>
 *       <enumeration value="AL"/>
 *       <enumeration value="AR"/>
 *    </restriction>
 *  </simpleType>
 * 
 *  <simpleType>
 *    <list itemType="po:USState"/>
 *  </simpleType>
 * 
 *  <complexType name="PurchaseOrderType">
 *     <sequence>
 *         <element minOccurs="0" name="state" type="po:USState"/>
 *         <element ref="po:notes"/>
 *     </sequence>
 *  </complexType>
 * 
 *  <element name="notes" type="string"/>
 * </schema>
 * 
 * @param xsdFile
 * @return
 */
public XSDSchema createSchema(IFile xsdFile)
{
	try
	{
		//Lab 5 builds from Lab 4
		Lab4 lab4 = new Lab4();
		XSDSchema schema = lab4.createSchema(xsdFile);
		
		//Lets get the PurchaseOrderType complex type
		XSDComplexTypeDefinition purchaseOrderType = schema.resolveComplexTypeDefinition("PurchaseOrderType");
		
		//Lets get the model group that was created in Lab4
		XSDModelGroup modelGroup = (XSDModelGroup)((XSDParticle)purchaseOrderType.getContent()).getContent();
		
		/**
		 * Create a global element with name="note" and type="string"
		 */
		XSDElementDeclaration noteElement = XSDFactory.eINSTANCE.createXSDElementDeclaration();
		
		//Set the name to "notes"
		noteElement.setName("notes");
		
		//Set the type of notes element to string
		XSDSimpleTypeDefinition stringType = schema.getSchemaForSchema().resolveSimpleTypeDefinition(XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001,"string");
		noteElement.setTypeDefinition(stringType);
		
		//Add the global element to the root schema
		schema.getContents().add(noteElement);
		
		/**
		 * Create local element with name="state", type="po:USState" and minOccurs="0"
		 * Local elements have particles as parents
		 */
		XSDParticle localElementParticle = XSDFactory.eINSTANCE.createXSDParticle();
		
		XSDElementDeclaration stateElement = XSDFactory.eINSTANCE.createXSDElementDeclaration();
		localElementParticle.setContent(stateElement);
		
		//Set the name to state
		stateElement.setName("state");
		
		//Set the tyoe to USState
		stateElement.setTypeDefinition(schema.resolveSimpleTypeDefinition("USState"));
		
		//Set the minOccurs="0"
		localElementParticle.setMinOccurs(0);
		
		//Add the new particle to the modelgroup
		modelGroup.getContents().add(localElementParticle);
		
		/**
		 * Create the element reference to the global element note
		 */
		XSDParticle elementRefParticle = XSDFactory.eINSTANCE.createXSDParticle();
		
		XSDElementDeclaration notesRef = XSDFactory.eINSTANCE.createXSDElementDeclaration();
		elementRefParticle.setContent(notesRef);
		
		//Set the element reference to the global element notes
		notesRef.setResolvedElementDeclaration(noteElement);
		
		//Add the new particle to the modelgroup
		modelGroup.getContents().add(elementRefParticle);
				
		// Save the contents of the resource to the file system.
		schema.eResource().save(Collections.EMPTY_MAP);
		
		return schema;
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	return null;
}
}
