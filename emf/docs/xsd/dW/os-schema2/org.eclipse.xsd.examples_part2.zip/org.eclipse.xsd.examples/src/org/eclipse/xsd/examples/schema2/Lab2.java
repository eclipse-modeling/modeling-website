package org.eclipse.xsd.examples.schema2;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */

import java.util.*;

import org.eclipse.core.resources.*;
import org.eclipse.xsd.*;
import org.eclipse.xsd.util.*;

/**
 * @author Dave Spriet
 * 
 * Lab 2 builds from Lab 1
<?xml version="1.0"?>
<schema 
  targetNamespace="http://www.eclipse.org/xsd/examples/po"
  xmlns="http://www.w3.org/2001/XMLSchema" 
  xmlns:po="http://www.eclipse.org/xsd/examples/po">
  
    <simpleType name="USState">
        <restriction base="string">
            <enumeration value="AK"/>
            <enumeration value="AL"/>
            <enumeration value="AR"/>
        </restriction>
    </simpleType>
    
</schema>

 */
public class Lab2 extends Object
{
/**
 * 
 */
public Lab2()
{
	super();
}

/** 
 * Create the following schema
 * 
 * <?xml version="1.0"?>
 * <schema
 *   targetNamespace="http://www.eclipse.org/xsd/examples/po"
 *   xmlns="http://www.w3.org/2001/XMLSchema"
 *   xmlns:po="http://www.eclipse.org/xsd/examples/po">
 * 
 *   <simpleType name="USState">
 *     <restriction base="string">
 *        <enumeration value="AK"/>
 *        <enumeration value="AL"/>
 *        <enumeration value="AR"/>
 *     </restriction>
 *   </simpleType>
 * </schema>
 * 
 * @param xsdFile
 * @return
 */
public XSDSchema createSchema(IFile xsdFile)
{
	try
	{
		//Lab 2 builds from Lab 1
		Lab1 lab1 = new Lab1();
		XSDSchema schema = lab1.createSchema(xsdFile);
		
		//Create global simple type with name="USState"
		XSDSimpleTypeDefinition simpleType = XSDFactory.eINSTANCE.createXSDSimpleTypeDefinition();
		simpleType.setName("USState");
		
		//Set the base type to be a string
		XSDSimpleTypeDefinition stringType = schema.getSchemaForSchema().resolveSimpleTypeDefinition(XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001,"string");
		simpleType.setBaseTypeDefinition(stringType);
		
		//AK Enumeration
		XSDEnumerationFacet akEnum = XSDFactory.eINSTANCE.createXSDEnumerationFacet();
		akEnum.setLexicalValue("AK");
		simpleType.getFacetContents().add(akEnum);

		//AL Enumeration
		XSDEnumerationFacet alEnum = XSDFactory.eINSTANCE.createXSDEnumerationFacet();
		alEnum.setLexicalValue("AL");
		simpleType.getFacetContents().add(alEnum);
		
		//AR Enumeration
		XSDEnumerationFacet arEnum = XSDFactory.eINSTANCE.createXSDEnumerationFacet();
		arEnum.setLexicalValue("AR");
		simpleType.getFacetContents().add(arEnum);
		
		//Add the simple type to the root schema
		schema.getContents().add(simpleType);
		
		// Save the contents of the resource to the file system.
		schema.eResource().save(Collections.EMPTY_MAP);
		
		return schema;
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	return null;
}
}
