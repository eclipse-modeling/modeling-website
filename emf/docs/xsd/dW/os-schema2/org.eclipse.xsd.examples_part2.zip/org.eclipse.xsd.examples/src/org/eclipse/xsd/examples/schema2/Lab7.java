package org.eclipse.xsd.examples.schema2;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */

import java.util.*;

import org.eclipse.core.resources.*;
import org.eclipse.emf.common.util.*;
import org.eclipse.emf.ecore.resource.*;
import org.eclipse.emf.ecore.resource.impl.*;
import org.eclipse.xsd.*;
import org.eclipse.xsd.util.*;

/**
 * @author Dave Spriet
 *
 * Lab7

<?xml version="1.0"?>
<xsd:schema xmlns:xsd="http://www.w3.org/2001/XMLSchema">

    <xsd:complexType name="PurchaseOrderType">
        <xsd:sequence>
            <xsd:element name="shipTo" type="USAddress"/>
            <xsd:element name="billTo" type="USAddress"/>
            <xsd:element minOccurs="0" ref="comment"/>
            <xsd:element name="items" type="Items"/>
        </xsd:sequence>
        <xsd:attribute name="orderDate" type="xsd:date"/>
    </xsd:complexType>
    
    <xsd:complexType name="USAddress">
        <xsd:sequence>
            <xsd:element name="name" type="xsd:string"/>
            <xsd:element name="street" type="xsd:string"/>
            <xsd:element name="city" type="xsd:string"/>
            <xsd:element name="state" type="xsd:string"/>
            <xsd:element name="zip" type="xsd:decimal"/>
        </xsd:sequence>
        <xsd:attribute fixed="US" name="country" type="xsd:NMTOKEN"/>
    </xsd:complexType>
    
    <xsd:complexType name="Items">
        <xsd:sequence>
            <xsd:element maxOccurs="unbounded" minOccurs="0" name="item">
                <xsd:complexType>
                    <xsd:sequence>
                        <xsd:element name="productName" type="xsd:string"/>
                        <xsd:element name="quantity">
                            <xsd:simpleType>
                                <xsd:restriction base="xsd:positiveInteger">
                                    <xsd:maxExclusive value="100"/>
                                </xsd:restriction>
                            </xsd:simpleType>
                        </xsd:element>
                        <xsd:element name="USPrice" type="xsd:decimal"/>
                        <xsd:element minOccurs="0" ref="comment"/>
                        <xsd:element minOccurs="0" name="shipDate" type="xsd:date"/>
                    </xsd:sequence>
                    <xsd:attribute name="partNum" type="SKU" use="required"/>
                </xsd:complexType>
            </xsd:element>
        </xsd:sequence>
    </xsd:complexType>
    
    <xsd:simpleType name="SKU">
        <xsd:restriction base="xsd:string">
            <xsd:pattern value="\d{3}-[A-Z]{2}"/>
        </xsd:restriction>
    </xsd:simpleType>
    
    <xsd:element name="purchaseOrder" type="PurchaseOrderType"/>
    
    <xsd:element name="comment" type="xsd:string"/>
    
</xsd:schema>

 */
public class Lab7 extends Object
{
/**
 * 
 */
public Lab7()
{
	super();
}

/**
 * Create the schema in the class comment described above
 *  
 * @param xsdFile
 * @return
 */
public XSDSchema createSchema(IFile xsdFile)
{
	try
	{
		//Create the root schema
		//Get the URI of the model file.
		URI fileURI = URI.createPlatformResourceURI(xsdFile.getFullPath().toString());

		//Create a resource set to manage the different resources
		ResourceSet resourceSet = new ResourceSetImpl();

	    //Create a resource for this file.		
		Resource resource = resourceSet.createResource(fileURI);

		XSDFactory xsdFactory = XSDFactory.eINSTANCE;
		
	    //Create the root XSDSchema object
		XSDSchema schema = xsdFactory.createXSDSchema();

	    //set the schema for schema QName prefix to "xsd"
		schema.setSchemaForSchemaQNamePrefix("xsd");
		java.util.Map qNamePrefixToNamespaceMap = schema.getQNamePrefixToNamespaceMap();
		
		//put the following namespace in the root schema namespace map
		//xsd:http://www.w3.org/2001/XMLSchema
		qNamePrefixToNamespaceMap.put(schema.getSchemaForSchemaQNamePrefix(),XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001);
		
		//We call updateElement to synchronize the MOF model with the underlying DOM model
		//This should only have to be done after creating a new model 
		schema.updateElement();

		//Add the root schema to the resource that was created above
		resource.getContents().add(schema);
	
		/**
		 * Create the global constructs
		 * Create Global Complex Type with name="PurchaseOrderType"
		 * Create Global Complex Type with name="USAddress"
		 * Create Global Complex Type with name="Items"
		 * Create Global Simple Type with name="SKU"
		 * Create Global Element with name="purchaseOrder" type="PurchaseOrderType"
		 * Create Global Element with name="comment" type="string" 
		 */
		
		//Create Global Complex Type with name="PurchaseOrderType"
		XSDComplexTypeDefinition poType = xsdFactory.createXSDComplexTypeDefinition();
		poType.setName("PurchaseOrderType");
		schema.getContents().add(poType);
		
		//Create Global Complex Type with name="USAddress"
		XSDComplexTypeDefinition usAddressType = xsdFactory.createXSDComplexTypeDefinition();
		usAddressType.setName("USAddress");
		schema.getContents().add(usAddressType);

		//Create Global Complex Type with name="Items"
		XSDComplexTypeDefinition itemsType = xsdFactory.createXSDComplexTypeDefinition();
		itemsType.setName("Items");
		schema.getContents().add(itemsType);		
			
		//Create Global Simple Type with name="SKU"
		XSDSimpleTypeDefinition skuType = xsdFactory.createXSDSimpleTypeDefinition();
		skuType.setName("SKU");
		schema.getContents().add(skuType);
		
		//Create Global Element with name="purchaseOrder" type="PurchaseOrderType"
		XSDElementDeclaration poElement = xsdFactory.createXSDElementDeclaration();
		poElement.setName("purchaseOrder");
		poElement.setTypeDefinition(poType);
		schema.getContents().add(poElement);
		
		//Create Global Element with name="comment" type="string"
		XSDElementDeclaration commentElement = xsdFactory.createXSDElementDeclaration();
		commentElement.setName("comment");
		XSDSimpleTypeDefinition stringType = schema.getSchemaForSchema().resolveSimpleTypeDefinition(XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001,"string");
		commentElement.setTypeDefinition(stringType);
		schema.getContents().add(commentElement);
		
				
		/**
		 * Create the following contents under the PurchaseOrderType complex type
		 * 
		 *   <xsd:complexType name="PurchaseOrderType">
		 *     <xsd:sequence>
		 *   	  <xsd:element name="shipTo" type="USAddress" />
		 *        <xsd:element name="billTo" type="USAddress" />
		 *        <xsd:element ref="comment" minOccurs="0" />
		 *        <xsd:element name="items" type="Items" />
		 *     </xsd:sequence>
		 *     <xsd:attribute name="orderDate" type="xsd:date" />
		 *   </xsd:complexType>
		 */
		XSDParticle poSequenceParticle = xsdFactory.createXSDParticle();
		XSDModelGroup poSeqeuence = xsdFactory.createXSDModelGroup();
		poSeqeuence.setCompositor(XSDCompositor.SEQUENCE_LITERAL);
		
		poSequenceParticle.setContent(poSeqeuence);
		poType.setContent(poSequenceParticle);
		
		//Create local element name="shipTo" type="USAddress"
		XSDElementDeclaration shipToElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle shipToParticle = xsdFactory.createXSDParticle();
		shipToParticle.setContent(shipToElement);
		
		shipToElement.setName("shipTo");
		shipToElement.setTypeDefinition(usAddressType);
		poSeqeuence.getContents().add(shipToParticle);
		
		//Create local element name="billTo" type="USAddress"
		XSDElementDeclaration billToElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle billToParticle = xsdFactory.createXSDParticle();
		billToParticle.setContent(billToElement);
		
		billToElement.setName("billTo");
		billToElement.setTypeDefinition(usAddressType);
		poSeqeuence.getContents().add(billToParticle);
				
		//Create element ref="comment" minOccurs="0"
		XSDElementDeclaration commentRef = xsdFactory.createXSDElementDeclaration();
		XSDParticle commentRefParticle = xsdFactory.createXSDParticle();
		commentRefParticle.setContent(commentRef);
		
		commentRef.setResolvedElementDeclaration(commentElement);
		commentRefParticle.setMinOccurs(0);
		poSeqeuence.getContents().add(commentRefParticle);
				
		//Create local element name="items" type="Items"
		XSDElementDeclaration itemsElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle itemsParticle = xsdFactory.createXSDParticle();
		itemsParticle.setContent(itemsElement);
		
		itemsElement.setName("items");
		itemsElement.setTypeDefinition(itemsType);
		poSeqeuence.getContents().add(itemsParticle);		
		
		//Create local attribute name="orderDate" type="xsd:date"
		XSDAttributeDeclaration orderDate = xsdFactory.createXSDAttributeDeclaration();
		XSDAttributeUse orderDateUse = xsdFactory.createXSDAttributeUse();
		orderDateUse.setContent(orderDate);
		
		orderDate.setName("orderDate");
		XSDSimpleTypeDefinition dateType = schema.getSchemaForSchema().resolveSimpleTypeDefinition(XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001,"date");
		orderDate.setTypeDefinition(dateType);
		poType.getAttributeContents().add(orderDateUse);	
		
				
		/**
		 * Create the following contents under the USAddress complex type
		 * 
		 *   <xsd:complexType name="USAddress">
		 *     <xsd:sequence>
		 * 	      <xsd:element name="name" type="xsd:string" />
		 *        <xsd:element name="street" type="xsd:string" />
		 *   	  <xsd:element name="city" type="xsd:string" />
		 *   	  <xsd:element name="state" type="xsd:string" />
		 *  	  <xsd:element name="zip" type="xsd:decimal" />
		 *     </xsd:sequence>
		 *     <xsd:attribute name="country" type="xsd:NMTOKEN" fixed="US" />
		 *   </xsd:complexType>
		 */
		XSDParticle addressSequenceParticle = xsdFactory.createXSDParticle();
		XSDModelGroup addressSeqeuence = xsdFactory.createXSDModelGroup();
		addressSeqeuence.setCompositor(XSDCompositor.SEQUENCE_LITERAL);
		
		addressSequenceParticle.setContent(addressSeqeuence);
		usAddressType.setContent(addressSequenceParticle);
		
		//Create local element name="name" type="xsd:string"
		XSDElementDeclaration nameElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle nameParticle = xsdFactory.createXSDParticle();
		nameParticle.setContent(nameElement);
		
		nameElement.setName("name");
		nameElement.setTypeDefinition(stringType);
		addressSeqeuence.getContents().add(nameParticle);		
		
		//Create local name="street" type="xsd:string"
		XSDElementDeclaration streetElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle streetParticle = xsdFactory.createXSDParticle();
		streetParticle.setContent(streetElement);
		
		streetElement.setName("street");
		streetElement.setTypeDefinition(stringType);
		addressSeqeuence.getContents().add(streetParticle);
		
		//Create local element name="city" type="xsd:string"
		XSDElementDeclaration cityElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle cityParticle = xsdFactory.createXSDParticle();
		cityParticle.setContent(cityElement);
		
		cityElement.setName("city");
		cityElement.setTypeDefinition(stringType);
		addressSeqeuence.getContents().add(cityParticle);
		
		//Create local element name="state" type="xsd:string"
		XSDElementDeclaration stateElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle stateParticle = xsdFactory.createXSDParticle();
		stateParticle.setContent(stateElement);
		
		stateElement.setName("state");
		stateElement.setTypeDefinition(stringType);
		addressSeqeuence.getContents().add(stateParticle);	
		
		//Create local element name="zip" type="xsd:string"
		XSDElementDeclaration zipElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle zipParticle = xsdFactory.createXSDParticle();
		zipParticle.setContent(zipElement);
		
		zipElement.setName("zip");
		XSDSimpleTypeDefinition decimalType = schema.getSchemaForSchema().resolveSimpleTypeDefinition(XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001,"decimal");
		zipElement.setTypeDefinition(decimalType);
		addressSeqeuence.getContents().add(zipParticle);	
		
		//Create local attribute name="country" type="xsd:NMTOKEN" fixed="US"
		XSDAttributeDeclaration countryAttribute = xsdFactory.createXSDAttributeDeclaration();
		XSDAttributeUse countryUse = xsdFactory.createXSDAttributeUse();
		countryUse.setContent(countryAttribute);
		
		countryAttribute.setName("country");
		XSDSimpleTypeDefinition nmtokenType = schema.getSchemaForSchema().resolveSimpleTypeDefinition(XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001,"NMTOKEN");
		countryAttribute.setTypeDefinition(nmtokenType);
		
		countryAttribute.setConstraint(XSDConstraint.FIXED_LITERAL);
		countryAttribute.setLexicalValue("US");
		usAddressType.getAttributeContents().add(countryUse);
				
		/**
		 * Create the following contents under the Items complex type
		 *   <xsd:complexType name="Items">
		 *     <xsd:sequence>
		 *   	  <xsd:element name="item" minOccurs="0" maxOccurs="unbounded">
		 *  	    <xsd:complexType>
		 *  		  <xsd:sequence>
		 *  		    <xsd:element name="productName" type="xsd:string" />
		 * 			    <xsd:element name="quantity">
		 *      		  <xsd:simpleType>
		 *   			    <xsd:restriction base="xsd:positiveInteger">
		 *  				  <xsd:maxExclusive value="100" />
		 *   				</xsd:restriction>
		 *  			  </xsd:simpleType>
		 *  			</xsd:element>
		 *  			<xsd:element name="USPrice" type="xsd:decimal" />
		 *  			<xsd:element ref="comment" minOccurs="0" />
		 *  			<xsd:element name="shipDate" type="xsd:date" minOccurs="0" />
		 *  		  </xsd:sequence>
		 *  		  <xsd:attribute name="partNum" type="SKU" use="required" />
		 *  		</xsd:complexType>
		 *  	  </xsd:element>
		 *     </xsd:sequence>
		 *   </xsd:complexType>
		 */
		XSDParticle itemsSequenceParticle = xsdFactory.createXSDParticle();
		XSDModelGroup itemsSeqeuence = xsdFactory.createXSDModelGroup();
		itemsSeqeuence.setCompositor(XSDCompositor.SEQUENCE_LITERAL);
		
		itemsSequenceParticle.setContent(itemsSeqeuence);
		itemsType.setContent(itemsSequenceParticle);
	
		//Create local name="item" minOccurs="0" maxOccurs="unbounded"
		XSDElementDeclaration itemElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle itemParticle = xsdFactory.createXSDParticle();
		itemParticle.setContent(itemElement);
		
		itemElement.setName("item");
		itemParticle.setMinOccurs(0);
		itemParticle.setMaxOccurs(-1);

		itemsSeqeuence.getContents().add(itemParticle);	
		
		//Create anonymous complex type for the item local element		
		XSDComplexTypeDefinition itemAnonType = xsdFactory.createXSDComplexTypeDefinition();
		itemElement.setAnonymousTypeDefinition(itemAnonType);
		
		XSDParticle itemAnonTypeSequenceParticle = xsdFactory.createXSDParticle();
		XSDModelGroup itemAnonTypeSeqeuence = xsdFactory.createXSDModelGroup();
		itemAnonTypeSeqeuence.setCompositor(XSDCompositor.SEQUENCE_LITERAL);
		itemAnonTypeSequenceParticle.setContent(itemAnonTypeSeqeuence);
		
		itemAnonType.setContent(itemAnonTypeSequenceParticle);

		//Create local element name="productName" type="xsd:string"
		XSDElementDeclaration productNameElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle productNameParticle = xsdFactory.createXSDParticle();
		productNameParticle.setContent(productNameElement);
		
		productNameElement.setName("productName");
		productNameElement.setTypeDefinition(stringType);
		itemAnonTypeSeqeuence.getContents().add(productNameParticle);	
		
		//Create local element name="quantity" with anon simpleType with restriction="xsd:positiveInteger"
		//Create a maxExclusive facet on the anonymouse simple type with value="100" 
		XSDElementDeclaration quantityElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle quantityParticle = xsdFactory.createXSDParticle();
		quantityParticle.setContent(quantityElement);
		
		quantityElement.setName("quantity");
		XSDSimpleTypeDefinition anonSimpleType = xsdFactory.createXSDSimpleTypeDefinition();
		XSDSimpleTypeDefinition positiveIntegerType = schema.getSchemaForSchema().resolveSimpleTypeDefinition(XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001,"positiveInteger");
		anonSimpleType.setBaseTypeDefinition(positiveIntegerType);
		
		XSDMaxExclusiveFacet exclusiveFacet = xsdFactory.createXSDMaxExclusiveFacet();
		exclusiveFacet.setLexicalValue("100");
		anonSimpleType.getFacetContents().add(exclusiveFacet);
		
		quantityElement.setAnonymousTypeDefinition(anonSimpleType);
		
		itemAnonTypeSeqeuence.getContents().add(quantityParticle);	
		
		//Create local element name="USPrice" type="xsd:decimal
		XSDElementDeclaration usPriceElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle usPriceParticle = xsdFactory.createXSDParticle();
		usPriceParticle.setContent(usPriceElement);
		
		usPriceElement.setName("USPrice");
		usPriceElement.setTypeDefinition(decimalType);
		itemAnonTypeSeqeuence.getContents().add(usPriceParticle);	

		//Create element ref="comment" minOccurs="0"
		commentRef = xsdFactory.createXSDElementDeclaration();
		commentRefParticle = xsdFactory.createXSDParticle();
		commentRefParticle.setContent(commentRef);
		
		commentRef.setResolvedElementDeclaration(commentElement);
		commentRefParticle.setMinOccurs(0);
		itemAnonTypeSeqeuence.getContents().add(commentRefParticle);			
		
		//Create local element name="shipDate" type="xsd:date" minOccurs="0"
		XSDElementDeclaration shipDateElement = xsdFactory.createXSDElementDeclaration();
		XSDParticle shipDateParticle = xsdFactory.createXSDParticle();
		shipDateParticle.setContent(shipDateElement);
		
		shipDateElement.setName("shipDate");
		shipDateParticle.setMinOccurs(0);
		shipDateElement.setTypeDefinition(dateType);
		itemAnonTypeSeqeuence.getContents().add(shipDateParticle);
				
		//Create local attribute name="partNum" type="SKU" use="required" 
		XSDAttributeDeclaration partNum = xsdFactory.createXSDAttributeDeclaration();
		XSDAttributeUse partNumUse = xsdFactory.createXSDAttributeUse();
		partNumUse.setContent(partNum);
		
		partNum.setName("partNum");
		partNum.setTypeDefinition(skuType);	
		partNumUse.setUse(XSDAttributeUseCategory.REQUIRED_LITERAL);
		itemAnonType.getAttributeContents().add(partNumUse);			
				
		/**
		 * Create the following contents under the SKU simple type
		 *   <xsd:simpleType name="SKU">
		 *     <xsd:restriction base="xsd:string">
		 * 		  <xsd:pattern value="\d{3}-[A-Z]{2}" />
		 * 		</xsd:restriction>
		 *   </xsd:simpleType>
		 */
		skuType.setBaseTypeDefinition(stringType);
		
		//Create pattern facet value="\d{3}-[A-Z]{2}" 
		XSDPatternFacet pattern = xsdFactory.createXSDPatternFacet();
		pattern.setLexicalValue("\\d{3}-[A-Z]{2}");
		
		skuType.getFacetContents().add(pattern);
		
		
		// Save the contents of the resource to the file system.
		resource.save(Collections.EMPTY_MAP);
		
		return schema;
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	return null;
}
}
