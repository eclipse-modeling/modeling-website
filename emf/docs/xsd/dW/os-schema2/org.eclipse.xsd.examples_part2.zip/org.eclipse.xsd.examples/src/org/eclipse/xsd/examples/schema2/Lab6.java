package org.eclipse.xsd.examples.schema2;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */

import java.util.*;

import org.eclipse.core.resources.*;

import org.eclipse.xsd.*;
import org.eclipse.xsd.util.*;

/**
 * @author Dave Spriet
 * 
 * Lab6
 * Lab 6 builds from Lab 5
 * 
<?xml version="1.0"?>
<schema 
  targetNamespace="http://www.eclipse.org/xsd/examples/po"
  xmlns="http://www.w3.org/2001/XMLSchema" 
  xmlns:po="http://www.eclipse.org/xsd/examples/po">
  
    <simpleType name="USState">
        <restriction base="string">
            <enumeration value="AK"/>
            <enumeration value="AL"/>
            <enumeration value="AR"/>
        </restriction>
    </simpleType>
    
    <simpleType>
        <list itemType="po:USState"/>
    </simpleType>
    
    <complexType name="PurchaseOrderType">
        <sequence>
            <element minOccurs="0" name="state" type="po:USState"/>
            <element ref="po:notes"/>
        </sequence>
        <attribute name="color" type="string"/>
        <attribute ref="po:lang"/>
        <attributeGroup ref="po:shapeAttributes"/>
    </complexType>
    
    <element name="notes" type="string"/>
    
    <attributeGroup name="shapeAttributes">
        <attribute name="size" type="string" use="optional"/>
        <attribute name="length" type="int"/>
    </attributeGroup>
    
    <attribute name="lang" type="string"/>
    
</schema>


 */
public class Lab6 extends Object
{
/**
 * 
 */
public Lab6()
{
	super();
}

/**
 * Create the following schema
 * 
 * <?xml version="1.0"?>
 * <schema
 *   targetNamespace="http://www.eclipse.org/xsd/examples/po"
 *   xmlns="http://www.w3.org/2001/XMLSchema"
 *   xmlns:po="http://www.eclipse.org/xsd/examples/po">
 *
 *  <simpleType name="USState">
 *    <restriction base="string">
 *       <enumeration value="AK"/>
 *       <enumeration value="AL"/>
 *       <enumeration value="AR"/>
 *    </restriction>
 *  </simpleType>
 * 
 *  <simpleType>
 *     <list itemType="po:USState"/>
 *  </simpleType>
 * 
 *  <complexType name="PurchaseOrderType">
 *    <sequence>
 *        <element minOccurs="0" name="state" type="po:USState"/>
 *        <element ref="po:notes"/>
 *    </sequence>
 *    <attribute name="color" type="string"/>
 *    <attribute ref="po:lang"/>
 *    <attributeGroup ref="po:shapeAttributes"/>
 *  </complexType>
 * 
 *  <element name="notes" type="string"/>
 *
 *  <attributeGroup name="shapeAttributes">
 *     <attribute name="size" type="string" use="optional"/>
 *     <attribute name="length" type="int"/>
 *  </attributeGroup>
 * 
 *  <attribute name="lang" type="string"/>
 * 
 * </schema>
 * 
 * @param xsdFile
 * @return
 */
public XSDSchema createSchema(IFile xsdFile)
{
	try
	{
		//Lab 6 builds from Lab 5
		Lab5 lab5 = new Lab5();
		XSDSchema schema = lab5.createSchema(xsdFile);
		
		/**
		 * Create global attributeGroup with name="shapeAttributes" and has the following 
		 * attributes:
		 *   <attributeGroup name="shapeAttributes" />
		 *     <attribute name="size" type="string" use="required" />
		 *     <attribute name="length" type="int" use="optional" />
		 *   </attributeGroup>
		 */
		XSDAttributeGroupDefinition shapeAttributes = XSDFactory.eINSTANCE.createXSDAttributeGroupDefinition();
		
		//Set the name = "shapeAttributes"
		shapeAttributes.setName("shapeAttributes");
				
		/**
		 * Create local attribute size, which need XSDAttributeUse to store the usage
		 */
		XSDAttributeUse sizeAttrUse = XSDFactory.eINSTANCE.createXSDAttributeUse();
		
		//Set the use="required"
		sizeAttrUse.setUse(XSDAttributeUseCategory.REQUIRED_LITERAL);
		
		XSDAttributeDeclaration sizeAttr = XSDFactory.eINSTANCE.createXSDAttributeDeclaration();
		
		//Set the name="size"
		sizeAttr.setName("size");
		
		//Set the type="string"
		XSDSimpleTypeDefinition stringType = schema.getSchemaForSchema().resolveSimpleTypeDefinition(XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001,"string");
		sizeAttr.setTypeDefinition(stringType);
		
		//Add the sizeAttr to the sizeAttrUse
		sizeAttrUse.setContent(sizeAttr);
		
		//Add the sizeAttrUse to the global attribute group
		shapeAttributes.getContents().add(sizeAttrUse);

		/**
		 * Create local attribute length, which need XSDAttributeUse to store the usage
		 */
		XSDAttributeUse lengthAttrUse = XSDFactory.eINSTANCE.createXSDAttributeUse();
		
		//Set the use="optional"
		sizeAttrUse.setUse(XSDAttributeUseCategory.OPTIONAL_LITERAL);
		
		XSDAttributeDeclaration lengthAttr = XSDFactory.eINSTANCE.createXSDAttributeDeclaration();
		
		//Set the name="length"
		lengthAttr.setName("length");
		
		//Set the type="int"
		XSDSimpleTypeDefinition intType = schema.getSchemaForSchema().resolveSimpleTypeDefinition(XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001,"int");
		lengthAttr.setTypeDefinition(intType);
		
		//Add the lengthAttr to the lengthAttrUse
		lengthAttrUse.setContent(lengthAttr);
		
		//Add the lengthAttrUse to the global attribute group
		shapeAttributes.getContents().add(lengthAttrUse);	
		
		//Add the new attribute group to the root schema
		schema.getContents().add(shapeAttributes);
				
		/**
		 * Now lets create and add some attributes to the given complexType
		 * 
		 * <attribute name="lang" type="string" >  
		 * 
		 * <complexType name="PurchaseOrderType" >
		 *   <sequence>
		 *     <element name="state" type="po:USState" minOccurs="0" />
		 *     <element ref="po:notes" />
		 *   </sequence>
		 *   <attribute name="color" type="string" />
		 *   <attribute ref="po:lang" />
		 *   <attributeGroup ref="po:shapeAttributes" />
		 * </complexType> 
		 * 
		 * Create Global Attribute name="lang" and type="string"
		 * Create the local attribute color type="string"
		 * Create then attribute reference to global attribute po:lang
		 * Create attributeGroup reference to global attributeGroup po:shapeAttributes
		 */
		
		//Create Global Attribute name="lang" and type="string"
		XSDAttributeDeclaration langAttr = XSDFactory.eINSTANCE.createXSDAttributeDeclaration();
		
		//Set name="lang"
		langAttr.setName("lang");
		
		//Set type="string"
		langAttr.setTypeDefinition(stringType);
		
		//Add the global attribute to the given schema
		schema.getContents().add(langAttr);
		
		//Lets get the PurchaseOrderType complex type
		XSDComplexTypeDefinition purchaseOrderType = schema.resolveComplexTypeDefinition("PurchaseOrderType");

		//Create the local attribute color type="string"
		XSDAttributeUse colorAttrUse = XSDFactory.eINSTANCE.createXSDAttributeUse();
				
		XSDAttributeDeclaration colorAttr = XSDFactory.eINSTANCE.createXSDAttributeDeclaration();
		
		//Set the name="color"
		colorAttr.setName("color");
		
		//Set type="string"		
		colorAttr.setTypeDefinition(stringType);
		
		//Add the colorAttr to the colorAttrUse
		colorAttrUse.setContent(colorAttr);
		
		//Add the colorAttrUse to the complex type
		purchaseOrderType.getAttributeContents().add(colorAttrUse);

		//Create then attribute reference to global attribute po:lang
		XSDAttributeUse langRefAttrUse = XSDFactory.eINSTANCE.createXSDAttributeUse();
				
		XSDAttributeDeclaration langRefAttr = XSDFactory.eINSTANCE.createXSDAttributeDeclaration();
		
		//Set the reference="po:lang"
		langRefAttr.setResolvedAttributeDeclaration(langAttr);
				
		//Add the langRefAttr to the langRefAttrUse
		langRefAttrUse.setContent(langRefAttr);
		
		//Add the langRefAttrUse to the complex type
		purchaseOrderType.getAttributeContents().add(langRefAttrUse);	
		
		//Create attributeGroup reference to global attributeGroup po:shapeAttributes	
		XSDAttributeGroupDefinition shapeAttributesRef = XSDFactory.eINSTANCE.createXSDAttributeGroupDefinition();
				
		//Set the resolved attributeGroup
		shapeAttributesRef.setResolvedAttributeGroupDefinition(shapeAttributes);
		
		//Add the attribute group reference to the complex type
		purchaseOrderType.getAttributeContents().add(shapeAttributesRef);
		
		// Save the contents of the resource to the file system.
		schema.eResource().save(Collections.EMPTY_MAP);
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	return null;
}
}
