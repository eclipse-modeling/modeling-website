package org.eclipse.xsd.examples;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */
 
import org.eclipse.core.runtime.*;
import org.eclipse.emf.common.*;
import org.eclipse.emf.common.util.*;


/**
 * The <b>Plugin</b> for the model.
 * The XML Schema model needs to be able to run 
 * within an Eclipse workbench,
 * within a headless Eclipse workspace,
 * or just stand-alone as part of some other application.
 * To support this, all access is directed to the static methods,
 * which can redirect the service as appopriate to the runtime.
 * During stand-alone invocation no plugin initialization takes place.
 * In this case you will need the resources jar on the class path.
 * @see #getBaseURL
 */
public final class XSDExamplesPlugin extends EMFPlugin 
{ 
	/**
	 * The actual implementation of the Eclipse <b>Plugin</b>.
	 */
	public static class Implementation extends EclipsePlugin
	{
		/**
		 * Creates an instance.
		 * @param descriptor the description of the plugin.
		 */
		public Implementation(IPluginDescriptor descriptor)
		{
			super(descriptor);

			// Remember the static instance.
				plugin = this;
		}
	}
		
/**
 * The singleton instance of the plugin.
 */
public static final XSDExamplesPlugin INSTANCE = new XSDExamplesPlugin();

/**
 * The one instance of this class.
 */
private static Implementation plugin;

/**
 * Creates the singleton instance.
 */
private XSDExamplesPlugin()
{
	super(new ResourceLocator[] {});
}

/*
 * Javadoc copied from base class.
 */
public ResourceLocator getPluginResourceLocator()
{
	return plugin;
}

/**
 * Returns the singleton instance of the Eclipse plugin.
 * @return the singleton instance.
 */
public static Implementation getPlugin()
{
	return plugin;
}

}
