package org.eclipse.xsd.examples.schema2;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */

import java.util.*;

import org.eclipse.core.resources.*;
import org.eclipse.emf.common.util.*;
import org.eclipse.emf.ecore.resource.*;
import org.eclipse.emf.ecore.resource.impl.*;
import org.eclipse.xsd.*;
import org.eclipse.xsd.util.*;

/**
 * @author Dave Spriet
 * 
 * 
<?xml version="1.0"?>
<schema 
    targetNamespace="http://www.eclipse.org/xsd/examples/po"
    xmlns="http://www.w3.org/2001/XMLSchema" 
    xmlns:po="http://www.eclipse.org/xsd/examples/po"/>
 */
public class Lab1 extends Object
{
/**
 * 
 */
public Lab1()
{
	super();
}

/**
 * Create the following schema
 * 
 * <?xml version="1.0"?>
 * <schema
 *     targetNamespace="http://www.eclipse.org/xsd/examples/po"
 *     xmlns="http://www.w3.org/2001/XMLSchema"
 *     xmlns:po="http://www.eclipse.org/xsd/examples/po"/>
 * 
 * @param xsdFile
 * @return
 */
public XSDSchema createSchema(IFile xsdFile)
{
	try
	{
		//Get the URI of the model file.
		URI fileURI = URI.createPlatformResourceURI(xsdFile.getFullPath().toString());

		//Create a resource set to manage the different resources
		ResourceSet resourceSet = new ResourceSetImpl();
		
		//Create a resource for this file.	
		Resource resource = resourceSet.createResource(fileURI);

		//Create the root XSDSchema object
		XSDSchema schema = XSDFactory.eINSTANCE.createXSDSchema();

    	//Set the target namespace of the given schema document to 
		schema.setTargetNamespace("http://www.eclipse.org/xsd/examples/po");

		java.util.Map qNamePrefixToNamespaceMap = schema.getQNamePrefixToNamespaceMap();
		qNamePrefixToNamespaceMap.put(schema.getSchemaForSchemaQNamePrefix(), XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001);
		
		//put the following namespace in the root schema namespace map
		qNamePrefixToNamespaceMap.put("po", schema.getTargetNamespace());

		//We call updateElement to synchronize the MOF model with the underlying DOM model
		//This should only have to be done after creating a new model 
		schema.updateElement();

		//Add the root schema to the resource that was created above
		resource.getContents().add(schema);

		// Save the contents of the resource to the file system.
		resource.save(Collections.EMPTY_MAP);
		
		return schema;
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	return null;
}
}
