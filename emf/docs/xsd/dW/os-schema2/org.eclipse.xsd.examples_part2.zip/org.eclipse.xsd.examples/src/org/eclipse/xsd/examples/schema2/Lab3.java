package org.eclipse.xsd.examples.schema2;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */

import java.util.*;

import org.eclipse.core.resources.*;

import org.eclipse.xsd.*;

/**
 * @author Dave Spriet
 * 
 * Lab 3 builds from Lab 2
 * 
<?xml version="1.0"?>
<schema 
  targetNamespace="http://www.eclipse.org/xsd/examples/po"
  xmlns="http://www.w3.org/2001/XMLSchema" 
  xmlns:po="http://www.eclipse.org/xsd/examples/po">
  
    <simpleType name="USState">
        <restriction base="string">
            <enumeration value="AK"/>
            <enumeration value="AL"/>
            <enumeration value="AR"/>
        </restriction>
    </simpleType>
    
    <simpleType name="USStateList">
        <list itemType="po:USState"/>
    </simpleType>
    
</schema>


 */
public class Lab3 extends Object
{
/**
 * 
 */
public Lab3()
{
	super();
}

/**
 * Create the following schema
 * 
 * <?xml version="1.0"?>
 * <schema
 *   targetNamespace="http://www.eclipse.org/xsd/examples/po"
 *   xmlns="http://www.w3.org/2001/XMLSchema"
 *   xmlns:po="http://www.eclipse.org/xsd/examples/po">
 * 
 *   <simpleType name="USState">
 *     <restriction base="string">
 *        <enumeration value="AK"/>
 *        <enumeration value="AL"/>
 *        <enumeration value="AR"/>
 *     </restriction>
 *   </simpleType>
 * 
 *   <simpleType name="USStateList">
 *      <list itemType="po:USState"/>
 *   </simpleType>
 * </schema>
 * 
 * @param xsdFile
 * @return
 */
public XSDSchema createSchema(IFile xsdFile)
{
	try
	{
		//Lab 3 builds from Lab 2
		Lab2 lab2 = new Lab2();
		XSDSchema schema = lab2.createSchema(xsdFile);
		
		//USState
		XSDSimpleTypeDefinition usStateType = schema.resolveSimpleTypeDefinition("USState");
		
		//Create the list type
		XSDSimpleTypeDefinition listType = XSDFactory.eINSTANCE.createXSDSimpleTypeDefinition();
		
		//Set the name="USStateList"
		listType.setName("USStateList");
		
		//Set the itemType="po:USState"
		listType.setItemTypeDefinition(usStateType);
		
		//Add the listType to the root schema
		schema.getContents().add(listType);
		
		// Save the contents of the resource to the file system.
		schema.eResource().save(Collections.EMPTY_MAP);
		
		return schema;
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	return null;
}
}
