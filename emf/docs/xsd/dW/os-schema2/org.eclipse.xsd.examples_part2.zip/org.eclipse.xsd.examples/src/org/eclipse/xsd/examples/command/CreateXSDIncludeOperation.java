package org.eclipse.xsd.examples.command;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */

import java.util.*;

import org.eclipse.xsd.*;

/**
 * @author Dave Spriet
 */
public class CreateXSDIncludeOperation extends Object
{
/**
 * 
 */
public CreateXSDIncludeOperation()
{
	super();
}

public XSDInclude createXSDInclude(XSDSchema rootSchemaFile, String schemaLocation)
{
	try
	{
		//Create the root XSDInclude object
		XSDInclude xsdInclude = XSDFactory.eINSTANCE.createXSDInclude();
		
		//Set the schema location
		xsdInclude.setSchemaLocation(schemaLocation);
		
		//Add the xsd include
		rootSchemaFile.getContents().add(0,xsdInclude);

		// Save the contents of the resource to the file system.
		rootSchemaFile.eResource().save(Collections.EMPTY_MAP);
				
		return xsdInclude;
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	return null;
}
}
