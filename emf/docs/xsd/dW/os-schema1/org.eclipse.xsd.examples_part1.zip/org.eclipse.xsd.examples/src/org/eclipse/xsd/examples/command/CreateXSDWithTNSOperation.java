package org.eclipse.xsd.examples.command;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */

import java.util.*;

import org.eclipse.core.resources.*;
import org.eclipse.emf.common.util.*;
import org.eclipse.emf.ecore.resource.*;
import org.eclipse.emf.ecore.resource.impl.*;
import org.eclipse.xsd.*;
import org.eclipse.xsd.util.*;

/**
 * @author Dave Spriet
 */
public class CreateXSDWithTNSOperation extends Object
{
/**
 * 
 */
public CreateXSDWithTNSOperation()
{
	super();
}

public XSDSchema createXSDSchema(IFile xsdFile, String uri)
{
	try
	{
		//Get the URI of the model file.
		URI fileURI = URI.createPlatformResourceURI(xsdFile.getFullPath().toString());

		//Create a resource set to manage the different resources
		ResourceSet resourceSet = new ResourceSetImpl();
		
		//Create a resource for this file.	
		Resource resource = resourceSet.createResource(fileURI);

		//Create the root XSDSchema object
		XSDSchema xsdSchema = XSDFactory.eINSTANCE.createXSDSchema();

    	//Set the target namespace of the given schema document to 
    	//http://www.eclipse.org/xsd/examples/createxsd
		xsdSchema.setTargetNamespace("http://www.eclipse.org/xsd/examples/createxsd");

		java.util.Map qNamePrefixToNamespaceMap = xsdSchema.getQNamePrefixToNamespaceMap();
		qNamePrefixToNamespaceMap.put(xsdSchema.getSchemaForSchemaQNamePrefix(), XSDConstants.SCHEMA_FOR_SCHEMA_URI_2001);
		
		//put the following namespace in the root schema namespace map
		//createxsd:http://www.eclipse.org/xsd/examples/createxsd
		qNamePrefixToNamespaceMap.put("createxsd", xsdSchema.getTargetNamespace());

		//We call updateElement to synchronize the MOF model with the underlying DOM model
		//This should only have to be done after creating a new model 
		xsdSchema.updateElement();

		//Add the root schema to the resource that was created above
		resource.getContents().add(xsdSchema);

		// Save the contents of the resource to the file system.
		resource.save(Collections.EMPTY_MAP);
		
		return xsdSchema;
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	return null;
}
}
