package org.eclipse.xsd.examples.actions;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */
 
import org.eclipse.core.resources.*;
import org.eclipse.jface.action.*;
import org.eclipse.jface.viewers.*;
import org.eclipse.ui.*;
import org.eclipse.ui.actions.*;
import org.eclipse.xsd.*;
import org.eclipse.xsd.examples.command.*;

public class XSDResourceAction extends ActionDelegate implements IWorkbenchWindowActionDelegate
{
  protected IStructuredSelection fSelection;

  //Cache the xsd file 
  protected IFolder fGeneratedFolder;

/**
 * XSDResourceAction constructor comment.
 */
public XSDResourceAction() 
{
	super();
}

/** (non-Javadoc)
 * Method declared on IActionBar.
 */
public void run(IAction action)
{
	if (fGeneratedFolder != null)
	{
		try
		{
			//lets create the xml schema file createXSDWithTNS.xsd with target namespace 
			//http://www.eclipse.org/xsd/examples/createxsd
			IFile xsdWithTNSFile = fGeneratedFolder.getFile("createXSDWithTNS.xsd");
			CreateXSDWithTNSOperation createXSWithTNSDop = new CreateXSDWithTNSOperation();
			createXSWithTNSDop.createXSDSchema(xsdWithTNSFile,"http://www.eclipse.org/xsd/examples/createxsd");

			//lets create the xml schema file createXSDWithNoTNS.xsd with no target namespace 
			IFile xsdWithNoTNSFile = fGeneratedFolder.getFile("createXSDWithNoTNS.xsd");
			CreateXSDWithNoTNSOperation createXSDWithNoTNSop = new CreateXSDWithNoTNSOperation();
			createXSDWithNoTNSop.createXSDSchema(xsdWithNoTNSFile);

			//lets load the xml schema file createXSDWithTNS.xsd
			LoadXSDOperation loadXSDop = new LoadXSDOperation();
			XSDSchema schema = loadXSDop.loadXSDSchema(xsdWithTNSFile);		
						
			//lets create an xsd include from the createXSDWithTNS.xsd to createXSDWithNoTNS.xsd
			CreateXSDIncludeOperation op = new CreateXSDIncludeOperation();
			op.createXSDInclude(schema,"createXSDWithNoTNS.xsd");
			
			//lets create an address xml schema file so we can import it into createXSDWithTNS.xsd
			IFile addressFile = fGeneratedFolder.getFile("address.xsd");
			CreateXSDWithTNSOperation addressOP = new CreateXSDWithTNSOperation();
			addressOP.createXSDSchema(addressFile,"http://www.eclipse.org/xsd/examples/address");
			
			//lets create a xsd:import from createXSDWithTNS.xsd to address.xsd
			CreateXSDImportOperation xsdImportOp = new CreateXSDImportOperation();
			xsdImportOp.createXSDImport(schema,"address.xsd","http://www.eclipse.org/xsd/examples/address");
						
		}
		catch (Exception e)
		{}
	}
}

/** (Non-javadoc)
 * Method declared on IActionDelegate.
 */
public void selectionChanged(IAction action, ISelection selection) 
{
	fGeneratedFolder=null;
	if (selection instanceof IStructuredSelection) 
	{
		fSelection = (IStructuredSelection)selection;
	}

	Object element = fSelection.getFirstElement();
		
	if ((element != null) && (element instanceof IFolder))
	{
		fGeneratedFolder = (IFolder) element;
		action.setEnabled(true);
		return;
	}
	action.setEnabled(false);		
}	

/* (non-Javadoc)
 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#dispose()
 */
public void dispose()
{
	
}

/* (non-Javadoc)
 * @see org.eclipse.ui.IWorkbenchWindowActionDelegate#init(org.eclipse.ui.IWorkbenchWindow)
 */
public void init(IWorkbenchWindow window)
{

}

}
