package org.eclipse.xsd.examples.command;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */
 
import org.eclipse.core.resources.*;
import org.eclipse.emf.common.util.*;
import org.eclipse.emf.ecore.resource.*;
import org.eclipse.emf.ecore.resource.impl.*;
import org.eclipse.xsd.*;
import org.eclipse.xsd.util.*;

/**
 * @author Dave Spriet
 */
public class LoadXSDOperation extends Object
{


/**
 * 
 */
public LoadXSDOperation()
{
	super();
}

public XSDSchema loadXSDSchema(IFile xsdFile)
{
	try
	{
		//Create a resource set to manage the resources
		ResourceSet resourceSet = new ResourceSetImpl();
		
		//Let the resource set load the resource from the given uri
		XSDResourceImpl xsdResource = (XSDResourceImpl) resourceSet.getResource(URI.
				createURI("platform:/resource" + xsdFile.getFullPath()), true);
		
		//The contents of the resource is the root XSDSchema object
		XSDSchema xsdSchema = xsdResource.getSchema();		
		
		return xsdSchema;
	}
	catch (Exception e)
	{
		e.printStackTrace();		
	}
	
	return null;
}
}
