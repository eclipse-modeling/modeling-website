package org.eclipse.xsd.examples.command;
/* IBM Confidential
 *
 * OCO Source Materials
 *
 * 5724-E11
 * 5724-E26
 * (C) Copyright IBM Corp. 2002, 2003
 *
 * The source code for this program is not published or otherwise
 * divested of its trade secrets, irrespective of what has been deposited
 * with the U.S. Copyright office
 */

import java.util.*;

import org.eclipse.xsd.*;

/**
 * @author Dave Spriet
 */
public class CreateXSDImportOperation extends Object
{
/**
 * 
 */
public CreateXSDImportOperation()
{
	super();
}

/**
 * 
 * @param rootSchemaFile
 * @param schemaLocation
 * @return
 */
public XSDImport createXSDImport(XSDSchema rootSchemaFile, String schemaLocation,String namespace)
{
	try
	{
		//Create the root XSDImport object
		XSDImport xsdImport = XSDFactory.eINSTANCE.createXSDImport();
		
		//Set the schema location
		xsdImport.setSchemaLocation(schemaLocation);
		
		//set the namespace attribute and add it to the xmlns
		xsdImport.setNamespace(namespace);
		
		//lets create a prefix / namespace pair in the root schema document
		rootSchemaFile.getQNamePrefixToNamespaceMap().put("Q1",namespace);
		
		//Add the xsd include
		rootSchemaFile.getContents().add(0,xsdImport);
		
		// Save the contents of the resource to the file system.
		rootSchemaFile.eResource().save(Collections.EMPTY_MAP);
		
		return xsdImport;
	}
	catch (Exception exception)
	{
		exception.printStackTrace();
	}
	return null;
}
}
