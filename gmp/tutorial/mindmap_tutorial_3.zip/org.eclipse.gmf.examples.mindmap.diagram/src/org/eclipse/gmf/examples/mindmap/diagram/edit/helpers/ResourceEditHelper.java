package org.eclipse.gmf.examples.mindmap.diagram.edit.helpers;

/**
 * @generated
 */
public class ResourceEditHelper extends MindmapBaseEditHelper {
}