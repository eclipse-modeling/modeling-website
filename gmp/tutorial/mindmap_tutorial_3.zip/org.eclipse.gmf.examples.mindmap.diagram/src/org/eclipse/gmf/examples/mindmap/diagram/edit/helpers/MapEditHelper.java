package org.eclipse.gmf.examples.mindmap.diagram.edit.helpers;

/**
 * @generated
 */
public class MapEditHelper extends MindmapBaseEditHelper {
}