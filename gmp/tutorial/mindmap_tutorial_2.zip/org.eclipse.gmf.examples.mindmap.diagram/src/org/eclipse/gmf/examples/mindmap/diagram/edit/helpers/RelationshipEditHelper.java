package org.eclipse.gmf.examples.mindmap.diagram.edit.helpers;

/**
 * @generated
 */
public class RelationshipEditHelper extends MindmapBaseEditHelper {
}