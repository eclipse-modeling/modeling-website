package org.eclipse.gmf.examples.mindmap.diagram.edit.helpers;

/**
 * @generated
 */
public class ThreadEditHelper extends MindmapBaseEditHelper {
}