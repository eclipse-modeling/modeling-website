package org.eclipse.gmf.examples.mindmap.diagram.part;

import org.eclipse.gmf.runtime.diagram.ui.parts.DiagramActionBarContributor;

/**
 * @generated
 */
public class MindmapDiagramActionBarContributor extends
		DiagramActionBarContributor {

	/**
	 * @generated
	 */
	protected Class getEditorClass() {
		return MindmapDiagramEditor.class;
	}

	/**
	 * @generated
	 */
	protected String getEditorId() {
		return MindmapDiagramEditor.ID;
	}
}
