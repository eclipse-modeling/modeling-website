package org.eclipse.gmf.examples.mindmap.diagram.edit.helpers;

import org.eclipse.gmf.runtime.emf.type.core.edithelper.AbstractEditHelperAdvice;

/**
 * @generated
 */
public class TopicSubtopicsEditHelperAdvice extends AbstractEditHelperAdvice {
}