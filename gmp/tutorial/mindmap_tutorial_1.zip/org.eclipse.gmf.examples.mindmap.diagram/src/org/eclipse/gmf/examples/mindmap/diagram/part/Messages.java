package org.eclipse.gmf.examples.mindmap.diagram.part;

public class Messages extends org.eclipse.osgi.util.NLS {

	static {
		org.eclipse.osgi.util.NLS
				.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	private Messages() {
	}

	//TODO: put accessor fields manually	
}
